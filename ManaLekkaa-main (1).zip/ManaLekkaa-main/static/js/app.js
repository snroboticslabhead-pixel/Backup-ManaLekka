/* ============================================================
   ManaLekka — app.js
   Mobile UI logic for Home, Calendar, KhataBook, Add Entry,
   Reports, Monthly Bill, Profile and Settings.
   All data flows through the existing Flask JSON APIs.
   ============================================================ */
(() => {
'use strict';

/* ---------------- tiny helpers ---------------- */
const $ = id => document.getElementById(id);
const $$ = s => [...document.querySelectorAll(s)];
const pad = n => String(n).padStart(2, '0');
const dateKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const monthKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
const today = new Date(); today.setHours(0, 0, 0, 0);
const todayKey = dateKey(today);
const CUR = (window.APP && APP.currency) || '₹';

const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const cap = s => s ? s[0].toUpperCase() + s.slice(1) : '';
const ic = (n, cls) => `<svg class="ic ${cls || 'sm'}"><use href="#i-${n}"/></svg>`;
const inr = n => {
  n = Math.round(Number(n || 0) * 100) / 100;
  return CUR + n.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 });
};
const litres = ml => { const v = Math.round((ml / 1000) * 100) / 100; return v.toLocaleString('en-IN', { maximumFractionDigits: 2 }) + ' L'; };
const buzz = () => { try { navigator.vibrate && navigator.vibrate(12); } catch (_) { } };
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const niceDay = k => parseKey(k).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
const shortDay = k => parseKey(k).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const monthName = ym => { const [y, m] = ym.split('-').map(Number); return new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' }); };
const initialsOf = name => {
  const p = String(name || '').trim().split(/\s+/).filter(Boolean);
  if (!p.length) return 'U';
  return (p[0].charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase();
};
const notifOn = () => { try { return localStorage.getItem('mm_notif') !== '0'; } catch (_) { return true; } };

/* ---------------- overlays (sheets / modals) ---------------- */
const backdrop = $('backdrop');
const ovStack = [];
function openOv(el) {
  if (!el || ovStack.includes(el)) return;
  ovStack.push(el);
  el.classList.add('show');
  backdrop.classList.add('show');
  document.body.classList.add('ov-lock');
}
function closeOv(el) {
  if (!el) return;
  el.classList.remove('show');
  const i = ovStack.indexOf(el);
  if (i > -1) ovStack.splice(i, 1);
  if (!ovStack.length) {
    backdrop.classList.remove('show');
    document.body.classList.remove('ov-lock');
  }
}
if (backdrop) backdrop.addEventListener('click', () => { [...ovStack].forEach(closeOv); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { [...ovStack].forEach(closeOv); const lb = $('lightbox'); if (lb) lb.classList.remove('show'); } });
document.addEventListener('click', e => {
  const btn = e.target.closest('[data-close]');
  if (btn) closeOv($(btn.dataset.close));
});

let cfResolve = null;
function confirmBox(title, msg, okLabel) {
  return new Promise(res => {
    if (!$('modalConfirm')) return res(window.confirm(msg || title));
    $('cfTitle').textContent = title || 'Are you sure?';
    $('cfMsg').textContent = msg || 'This action cannot be undone.';
    $('cfOk').textContent = okLabel || 'Confirm';
    cfResolve = res;
    openOv($('modalConfirm'));
  });
}
function cfDone(v) {
  closeOv($('modalConfirm'));
  if (cfResolve) { cfResolve(v); cfResolve = null; }
}

/* ---------------- state & api ---------------- */
const CAT_DEFAULTS = (window.APP && APP.categories) ? [...APP.categories] : ['Other'];
const defaults = () => ({
  name: 'User', email: '', phone: '', vendor: '', address: '', quantity: 500, photo: '',
  prices: [{ from: '2000-01-01', price: 60 }], records: {}, payments: [],
  expenses: [], vendors: [], expense_categories: [...CAT_DEFAULTS], shopping: [], interest: []
});
let state = defaults();
let refreshHook = null;
const setRefresh = fn => { refreshHook = fn; };

/* avatar renderer — shows the profile photo when one is saved, initials otherwise */
function setAvatar(el, name, photoOverride) {
  if (!el) return;
  const ph = photoOverride !== undefined ? photoOverride : state.photo;
  if (ph) el.innerHTML = '<img class="ava-img" alt="" src="' + ph + '">';
  else el.textContent = initialsOf(name || state.name);
}
/* paint every chrome avatar (mobile header #hbAvatar + desktop sidebar #sbAvatar)
   from the saved state, so a photo changed on one device appears everywhere */
function paintChrome() {
  setAvatar($('hbAvatar'), state.name);
  setAvatar($('sbAvatar'), state.name);
}
/* shrink any picked image to a square data URL (cover-cropped) so it fits in the saved state */
function resizeToDataUrl(file, size, cb) {
  const fr = new FileReader();
  fr.onload = () => {
    const im = new Image();
    im.onload = () => {
      const c = document.createElement('canvas');
      c.width = size; c.height = size;
      const g = c.getContext('2d');
      const s = Math.min(im.width, im.height);
      g.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, size, size);
      cb(c.toDataURL('image/jpeg', .85));
    };
    im.onerror = () => notify('Could not read that image.');
    im.src = String(fr.result);
  };
  fr.onerror = () => notify('Could not read that image.');
  fr.readAsDataURL(file);
}

/* empty-state builder — light-theme vector art (see the #ill-* symbols in
   base.html) with a friendly title + hint, used wherever a list or chart
   has no data to show */
function emptyState(art, title, sub, compact) {
  return '<div class="empty' + (compact ? ' empty-chart' : '') + '">' +
    '<span class="empty-fig"><svg class="empty-svg" aria-hidden="true"><use href="#' + art + '"/></svg></span>' +
    (title ? '<strong>' + title + '</strong>' : '') +
    (sub ? '<span class="empty-sub">' + sub + '</span>' : '') +
    '</div>';
}

function notify(msg) {
  if (!notifOn()) return;
  const el = $('toast'); if (!el) return;
  el.textContent = msg; el.classList.add('show');
  clearTimeout(notify.t); notify.t = setTimeout(() => el.classList.remove('show'), 2600);
}

async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let j = {}; try { j = await r.json(); } catch (_) { }
  if (!r.ok) {
    if (r.status === 401) { window.location.href = '/login'; throw new Error('Please sign in again.'); }
    throw new Error(j.error || 'Request failed (' + r.status + ')');
  }
  return j;
}
async function act(method, url, body, okMsg) {
  try {
    const j = await api(url, method, body);
    if (j.state) { state = Object.assign(defaults(), j.state); paintChrome(); }
    if (okMsg) { notify(okMsg); buzz(); }
    return j;
  } catch (e) {
    notify(e.message === 'Failed to fetch' ? 'Server unreachable. Nothing saved.' : e.message);
    return null;
  }
}
const getSummary = m => api('/api/summary/' + m);
const monthNow = () => monthKey(new Date());

/* Payment status for a month summary: label, css class and % paid.
   Used by Home, Bill, Reports, Khata and Profile so every page says the same thing. */
function payStatus(sm) {
  const amt = Number(sm.amount) || 0, paid = Number(sm.paid) || 0, bal = Number(sm.balance) || 0;
  if (amt <= 0) return { label: 'No bill yet', cls: 'none', pct: 0, txt: 'Nothing billed yet' };
  const pct = Math.max(0, Math.min(100, Math.round(paid / amt * 100)));
  if (bal <= 0.009) return { label: 'Paid', cls: 'ok', pct: 100, txt: 'Fully paid · ' + inr(paid) };
  if (paid > 0) return { label: 'Part paid', cls: 'part', pct, txt: pct + '% paid · ' + inr(bal) + ' left' };
  return { label: 'Unpaid', cls: 'due', pct: 0, txt: 'Not paid yet · ' + inr(bal) + ' to pay' };
}
/* Fills <prefix>PayPill / <prefix>Prog / <prefix>ProgTxt when those elements exist on the page */
function paintPay(sm, prefix) {
  const st = payStatus(sm);
  const pill = document.getElementById(prefix + 'PayPill'), bar = document.getElementById(prefix + 'Prog'), txt = document.getElementById(prefix + 'ProgTxt');
  if (pill) { pill.textContent = st.label; pill.className = 'pay-pill ' + st.cls; }
  if (bar) { bar.style.width = st.pct + '%'; bar.parentElement.className = 'pay-prog ' + st.cls; }
  if (txt) txt.textContent = st.txt;
  return st;
}
async function load() {
  /* first call on a page reuses the request base.html already started */
  let pre = null;
  if (window.__stP) { try { pre = await window.__stP; } catch (_) { pre = null; } window.__stP = null; }
  try { state = Object.assign(defaults(), pre || await api('/api/state')); } catch (e) { notify('Server unreachable.'); }
  paintChrome();
}
function priceOn(k) {
  let p = null;
  [...(state.prices || [])].sort((a, b) => a.from.localeCompare(b.from)).forEach(x => { if (p === null || x.from <= k) p = Number(x.price); });
  return p === null ? 60 : p;
}
const currentPrice = () => priceOn(todayKey);

/* ---------------- category visuals ---------------- */
const CAT_STYLE = [
  [/milk|dairy/i, 'milk', 'green'],
  [/grocer/i, 'basket', 'pink'],
  [/vegetable|fruit|greens/i, 'leaf', 'green'],
  [/feed|fodder|cattle/i, 'wheat', 'amber'],
  [/household/i, 'home', 'red'],
  [/transport|fuel|travel/i, 'truck', 'orange'],
  [/utilit|power|electric|bill/i, 'zap', 'amber'],
  [/health|medical/i, 'heart', 'red'],
  [/labor|labour|wage/i, 'rupee', 'purple'],
  [/educat|school/i, 'edu', 'purple'],
  [/shop/i, 'bag', 'pink'],
  [/suppl/i, 'store', 'teal'],
];
const COLOR_VARS = {
  green: ['var(--green-soft)', 'var(--green-deep)'],
  pink: ['var(--pink-soft)', 'var(--pink)'],
  amber: ['var(--amber-soft)', 'var(--amber)'],
  red: ['var(--red-soft)', 'var(--red)'],
  orange: ['var(--orange-soft)', 'var(--orange-ink)'],
  blue: ['var(--blue-soft)', 'var(--blue)'],
  purple: ['var(--purple-soft)', 'var(--purple)'],
  teal: ['var(--teal-soft)', 'var(--teal)'],
};
function catMeta(name) {
  for (const [re, icon, color] of CAT_STYLE) if (re.test(String(name || ''))) return { icon, color };
  return { icon: 'tag', color: 'green' };
}
const catChip = name => {
  const m = catMeta(name);
  const [bg, fg] = COLOR_VARS[m.color];
  return `<span class="tx-ico" style="background:${bg};color:${fg}">${ic(m.icon)}</span>`;
};
const TYPE_META = (window.APP && APP.types) || [
  { key: 'debit', label: 'Expense' }, { key: 'purchase', label: 'Purchase' }, { key: 'credit', label: 'Credit' }
];
const typeLabel = k => { const t = TYPE_META.find(t => t.key === k); return t ? t.label : cap(k || ''); };
const TYPE_ICON = { debit: 'basket', purchase: 'store', credit: 'download' };

/* ---------------- uploads (shared by bill photos, invoices, signatures) ---------------- */
const MAX_UPLOAD_BYTES = ((window.APP && APP.max_upload_mb) || 4) * 1024 * 1024;
/* phone photos are often 5-10 MB: shrink them first so they fit the host's request limit */
async function shrinkImage(file) {
  if (!/^image\/(jpeg|png|webp)$/i.test(file.type || '') || file.size < 700 * 1024) return file;
  try {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(bmp.width * sc)); c.height = Math.max(1, Math.round(bmp.height * sc));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(res => c.toBlob(res, 'image/jpeg', 0.82));
    if (blob && blob.size < file.size) return new File([blob], (file.name || 'photo').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
  } catch (_) { }
  return file;
}
async function uploadFile(file, name) {
  if (file.size > MAX_UPLOAD_BYTES) throw new Error('File is too large. Max ' + Math.round(MAX_UPLOAD_BYTES / 1048576) + ' MB.');
  const fd = new FormData(); fd.append('file', file, name || file.name);
  let r;
  try { r = await fetch('/api/upload', { method: 'POST', body: fd, credentials: 'same-origin' }); }
  catch (_) { throw new Error('Upload failed — check your network.'); }
  let j = {}; try { j = await r.json(); } catch (_) { }
  if (r.status === 401) { window.location.href = '/login'; throw new Error('Please sign in again.'); }
  if (!r.ok) throw new Error(j.error || (r.status === 413 ? 'File is too large. Max ' + Math.round(MAX_UPLOAD_BYTES / 1048576) + ' MB.' : 'Upload failed (' + r.status + ')'));
  return j.attachment;
}

/* ---------------- attachments ---------------- */
const kindOf = a => (a.format === 'pdf' || a.resource_type === 'raw') ? 'pdf' : 'img';
const cldThumb = (url, w) => url && url.includes('/upload/') ? url.replace('/upload/', `/upload/w_${w},h_${w},c_fill,q_auto,f_auto/`) : url;
function openLightbox(url, name, kind) {
  if (!$('lightbox')) return;
  $('lightboxName').textContent = name || 'Attachment';
  $('lightboxOpen').href = url;
  $('lightboxBody').innerHTML = kind === 'pdf'
    ? `<iframe src="${esc(url)}" title="${esc(name)}"></iframe>`
    : `<img src="${esc(cldThumb(url, 1200))}" alt="${esc(name)}" onerror="this.src='${esc(url)}'">`;
  $('lightbox').classList.add('show');
}
function attachWidget(listEl, inputEl, opts) {
  opts = opts || {};
  const maxFiles = opts.max || (window.APP && APP.max_attachments) || 6;
  const fmtSize = b => { b = Number(b) || 0; return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : b > 1024 ? Math.round(b / 1024) + ' KB' : b + ' B'; };
  let files = [];
  const render = () => {
    if (!listEl) return;
    listEl.innerHTML = files.length ? files.map((f, i) => `
      <div class="attach-chip">
        ${(kindOf(f) === 'pdf' || !f.url) ? `<span class="file-ico">${ic('file')}</span>` : `<img src="${esc(cldThumb(f.url, 120))}" alt="" onerror="this.onerror=null;this.src='${esc(f.url)}'">`}
        <span class="attach-name">${esc(f.name || 'file')}<small>${f.uploading ? 'Uploading…' : fmtSize(f.bytes)}</small></span>
        <button type="button" class="attach-remove" data-i="${i}" aria-label="Remove attachment">${ic('x')}</button>
      </div>`).join('') : '';
    listEl.querySelectorAll('.attach-remove').forEach(btn => btn.onclick = async () => {
      const idx = Number(btn.dataset.i), f = files[idx];
      files = files.filter((_, j) => j !== idx);
      render();
      if (f && f.public_id && !f.keepServer) {
        try { await api('/api/upload', 'DELETE', { public_id: f.public_id, resource_type: f.resource_type }); } catch (_) { }
      }
    });
  };
  if (inputEl) inputEl.onchange = async () => {
    const list = [...(inputEl.files || [])];
    inputEl.value = '';
    for (const file of list) {
      if (files.length >= maxFiles) { notify('Up to ' + maxFiles + ' file' + (maxFiles > 1 ? 's' : '') + ' allowed here.'); break; }
      const tmp = { name: file.name, bytes: file.size, kind: /pdf/i.test(file.type || file.name) ? 'pdf' : 'img', uploading: true };
      files.push(tmp); render();
      try {
        const att = await uploadFile(await shrinkImage(file));
        Object.assign(tmp, att, { uploading: false });
      } catch (e) {
        files = files.filter(x => x !== tmp);
        notify(e.message);
      }
      render();
    }
  };
  return {
    set: arr => { files = (arr || []).map(f => Object.assign({}, f, { keepServer: true })); render(); },
    get: () => files.filter(f => f.public_id && !f.uploading).map(f => ({ url: f.url, public_id: f.public_id, resource_type: f.resource_type || 'image', format: f.format || '', name: f.name || '', bytes: f.bytes || 0 })),
    clear: () => { files = []; render(); },
    busy: () => files.some(f => f.uploading)
  };
}

/* ---------------- ledger entry shared UI ---------------- */
const decorate = e => {
  const amount = Math.round(Number(e.amount || 0) * 100) / 100;
  const paid = Math.round((e.payments || []).reduce((a, p) => a + Number(p.amount || 0), 0) * 100) / 100;
  const due = Math.round(Math.max(0, amount - paid) * 100) / 100;
  const status = e.type === 'credit' ? 'received' : (due <= 0.009 ? 'paid' : (paid > 0 ? 'partial' : 'unpaid'));
  return Object.assign({}, e, { amount, paid, due, status, payments: e.payments || [], attachments: e.attachments || [] });
};
const findExp = id => {
  const e = (state.expenses || []).find(x => String(x.id) === String(id));
  return e ? decorate(e) : null;
};
const statusChipHtml = e => {
  const map = { paid: 'paid', partial: 'partial', unpaid: 'unpaid', received: 'received' };
  const label = { paid: 'Paid', partial: 'Part paid', unpaid: 'Udhar', received: 'Received' };
  return `<span class="tx-chip ${map[e.status]}">${label[e.status]}</span>`;
};

function openEntrySheet(id) {
  const e = findExp(id);
  if (!e || !$('sheetEntry')) return notify('Entry not found. Refresh page.');
  const isUdhar = e.type === 'debit' || e.type === 'purchase';
  const meta = catMeta(e.category);
  const [bg, fg] = COLOR_VARS[meta.color];
  $('veIcon').style.background = bg; $('veIcon').style.color = fg;
  $('veIcon').innerHTML = ic(meta.icon, 'lg');
  $('veMain').textContent = (e.category || 'Entry') + (e.bill_number ? ' · #' + e.bill_number : '');
  $('veSub').textContent = e.description || (e.vendor ? 'Via ' + e.vendor : 'No description added');
  $('veStatus').textContent = cap(e.status);
  $('veStatus').className = 'tx-chip ' + e.status;
  $('veAmount').textContent = (e.type === 'credit' ? '+' : '') + inr(e.amount);
  $('vePaidLabel').textContent = e.type === 'credit' ? 'Received' : 'Paid';
  $('vePaid').textContent = inr(e.paid);
  $('veDueLabel').textContent = 'Due';
  $('veDue').textContent = isUdhar ? inr(e.due) : '—';
  const pct = e.amount > 0 ? Math.min(100, Math.round(e.paid / e.amount * 100)) : 0;
  $('veProg').hidden = !(isUdhar && e.amount > 0);
  $('veProgBar').style.width = pct + '%';
  $('veProgPct').textContent = pct + '%';
  $('veType').textContent = typeLabel(e.type);
  $('veDate').textContent = shortDay(e.date);
  $('veCat').textContent = e.category || '—';
  $('veVendorRow').style.display = e.vendor ? '' : 'none';
  $('veVendor').textContent = e.vendor || '—';
  $('veBillRow').style.display = e.bill_number ? '' : 'none';
  $('veBill').textContent = e.bill_number || '—';
  $('veMethodRow').style.display = (e.method && e.method !== 'Other') || e.method ? '' : 'none';
  $('veMethod').textContent = e.method === 'Other' ? (e.custom_method || 'Other') : (e.method || '—');
  $('veNoteRow').style.display = e.note ? '' : 'none';
  $('veNote').textContent = e.note || '—';

  /* richer invoice details (optional fields) */
  const hasQty = !!(e.quantity || e.unit_price);
  $('veQtyRow').style.display = hasQty ? '' : 'none';
  $('veQty').textContent = [e.quantity, e.unit_price ? inr(e.unit_price) + ' / unit' : ''].filter(Boolean).join(' · ') || '—';
  const hasBreak = Number(e.tax) > 0 || Number(e.discount) > 0;
  $('veBreakRow').style.display = hasBreak ? '' : 'none';
  $('veBreak').textContent = hasBreak
    ? `${inr(Math.round((e.amount - e.tax + e.discount) * 100) / 100)}${e.tax ? ' + tax ' + inr(e.tax) : ''}${e.discount ? ' − disc ' + inr(e.discount) : ''}`
    : '—';
  $('veDueDateRow').style.display = e.due_date ? '' : 'none';
  $('veDueDate').textContent = e.due_date ? shortDay(e.due_date) + (e.due > 0.009 ? ' · pending' : ' · cleared') : '—';

  /* invoice document chip (single, optional) */
  const inv = e.invoice && e.invoice.url ? [e.invoice] : [];
  $('veInvSection').hidden = !inv.length;
  $('veInvGallery').innerHTML = inv.map(a => {
    const kind = kindOf(a);
    return `<button class="attach-chip inv-chip" data-vinv data-url="${esc(a.url)}" data-name="${esc(a.name || 'Invoice')}" data-kind="${kind}" type="button">
      ${kind === 'pdf' ? `<span class="file-ico">${ic('file')}</span>` : `<img src="${esc(cldThumb(a.url, 160))}" alt="" onerror="this.onerror=null;this.src='${esc(a.url)}'">`}
      <span class="attach-name">${esc(a.name || 'Invoice')}<small>Invoice</small></span>
    </button>`;
  }).join('');
  $('veInvGallery').querySelectorAll('[data-vinv]').forEach(b => b.onclick = () => openLightbox(b.dataset.url, b.dataset.name, b.dataset.kind));

  const atts = e.attachments || [];
  $('veAttSection').hidden = !atts.length;
  $('veAttCount').textContent = atts.length;
  $('veGallery').innerHTML = atts.map(a => {
    const kind = kindOf(a);
    return `<button class="attach-chip" data-vg data-url="${esc(a.url)}" data-name="${esc(a.name || 'Attachment')}" data-kind="${kind}" type="button">
      ${kind === 'pdf' ? `<span class="file-ico">${ic('file')}</span>` : `<img src="${esc(cldThumb(a.url, 160))}" alt="" onerror="this.onerror=null;this.src='${esc(a.url)}'">`}
      <span class="attach-name">${esc(a.name || 'file')}</span>
    </button>`;
  }).join('');
  $('veGallery').querySelectorAll('[data-vg]').forEach(b => b.onclick = () => openLightbox(b.dataset.url, b.dataset.name, b.dataset.kind));

  const pays = e.payments || [];
  $('vePaysSection').hidden = !pays.length;
  $('vePaysLabel').textContent = e.type === 'credit' ? 'Receipts' : 'Payments';
  $('vePays').innerHTML = pays.map(p => `
    <div class="pay-item">
      <span class="stat-ico green">${ic('wallet')}</span>
      <div class="pi-main"><div style="font-weight:700;font-size:13px">${inr(p.amount)} · ${esc(p.method || '')}</div>
      <div style="font-size:11.5px;color:var(--faint)">${esc(p.date || '')}${p.note ? ' · ' + esc(p.note) : ''}</div></div>
      ${e.type !== 'credit' ? `
        <button class="icon-btn plain" data-vpedit="${p.id}" aria-label="Edit payment">${ic('edit', 'sm')}</button>
        <button class="icon-btn plain danger" data-vpdel="${p.id}" aria-label="Delete payment">${ic('trash', 'sm')}</button>` : ''}
    </div>`).join('');
  $('vePays').querySelectorAll('[data-vpdel]').forEach(b => b.onclick = async () => {
    if (!(await confirmBox('Delete payment?', 'This payment record will be removed.', 'Delete'))) return;
    const j = await act('DELETE', `/api/expense/${e.id}/payment/${b.dataset.vpdel}`, null, 'Payment removed');
    if (j) { openEntrySheet(e.id); refreshHook && refreshHook(); }
  });
  $('vePays').querySelectorAll('[data-vpedit]').forEach(b => b.onclick = () => {
    const p = (e.payments || []).find(x => String(x.id) === b.dataset.vpedit);
    if (!p || !$('modalExpPayEdit')) return;
    $('epeEid').value = e.id;
    $('epePid').value = p.id;
    $('epeAmount').value = p.amount;
    $('epeAmount').max = Number(p.amount) + Number(e.due || 0);
    $('epeDate').value = p.date || todayKey;
    $('epeNote').value = p.note || '';
    const known = ((window.APP && APP.methods) || []).filter(m => m !== 'Other');
    if (known.includes(p.method)) { $('epeMethod').value = p.method; $('epeMethodOther').style.display = 'none'; }
    else { $('epeMethod').value = 'Other'; $('epeMethodOther').style.display = 'block'; $('epeMethodOther').value = p.method || ''; }
    openOv($('modalExpPayEdit'));
  });

  $('vePayBtn').style.display = (isUdhar && e.due > 0.009) ? '' : 'none';
  $('veDelBtn').onclick = async () => {
    if (!(await confirmBox('Delete entry?', 'Bill attachments will also be removed.', 'Delete'))) return;
    const j = await act('DELETE', '/api/expense/' + e.id, null, 'Entry deleted');
    if (j) { closeOv($('sheetEntry')); refreshHook && refreshHook(); }
  };
  $('veEditBtn').onclick = () => { closeOv($('sheetEntry')); openExpEdit(e); };
  $('vePayBtn').onclick = () => { closeOv($('sheetEntry')); openExpPay(e); };
  openOv($('sheetEntry'));
}

function openExpPay(e) {
  if (!$('sheetExpPay')) return;
  $('expPayEid') && ($('expPayEid').value = e.id);
  $('sheetExpPay').dataset.eid = e.id;
  $('expPayWho').textContent = (e.vendor || e.category || 'Entry') + (e.description ? ' · ' + e.description : '');
  $('expPayDue').textContent = inr(e.due);
  $('expPayAmount').max = e.due;
  $('expPayAmount').value = e.due > 0 ? e.due : '';
  $('expPayDate').value = todayKey;
  $('expPayNote').value = '';
  $('expPayMethod').value = 'Cash';
  $('expPayMethodOther').value = '';
  $('expPayMethodOtherWrap').hidden = true;
  openOv($('sheetExpPay'));
}
function openVendorSettle(name, due) {
  if (!$('sheetVendorSettle')) return;
  $('vsName').textContent = name;
  $('sheetVendorSettle').dataset.vendor = name;
  $('vsDue').textContent = inr(due);
  $('vsAmount').max = due;
  $('vsAmount').value = due;
  $('vsDate').value = todayKey;
  $('vsNote').value = '';
  $('vsMethod').selectedIndex = 0;
  $('vsMethodOther').value = '';
  $('vsMethodOtherWrap').hidden = true;
  openOv($('sheetVendorSettle'));
}
function openExpEdit(e) {
  if (!$('modalExpEdit')) return;
  $('editExpId').value = e.id;
  $('editExpDate').value = e.date;
  $('editExpDate').max = todayKey;
  $('editExpType').value = e.type || 'debit';
  const cats = [...new Set([...(state.expense_categories || []), e.category].filter(Boolean))];
  $('editExpCategory').innerHTML = cats.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('') + '<option value="__new__">+ Add new category…</option>';
  $('editExpCategory').value = e.category;
  $('editExpCategoryOther').style.display = 'none';
  $('editExpCategoryOther').value = '';
  $('editExpVendor').value = e.vendor || '';
  $('editExpBill').value = e.bill_number || '';
  $('editExpDesc').value = e.description || '';
  $('editExpQty').value = e.quantity || '';
  $('editExpUnit').value = e.unit_price || '';
  $('editExpTax').value = e.tax || '';
  $('editExpDisc').value = e.discount || '';
  $('editExpDue').value = e.due_date || '';
  $('editExpAmount').value = e.amount;
  updateEditTotal();
  $('editExpNote').value = e.note || '';
  const knownMethods = ((window.APP && APP.methods) || []).filter(m => m !== 'Other');
  if (knownMethods.includes(e.method)) {
    $('editExpMethod').value = e.method;
    $('editExpMethodOther').style.display = 'none';
    $('editExpMethodOther').value = '';
  } else {
    $('editExpMethod').value = 'Other';
    $('editExpMethodOther').style.display = 'block';
    $('editExpMethodOther').value = e.method || '';
  }
  if (editCtl) editCtl.set(e.attachments);
  if (editInvCtl) editInvCtl.set(e.invoice ? [e.invoice] : []);
  openOv($('modalExpEdit'));
}

let editCtl = null;
let editInvCtl = null;
function editGrandTotal() {
  if (!$('editExpTotal')) return;
  const base = Number($('editExpAmount').value) || 0;
  const tax = Number($('editExpTax').value) || 0;
  const disc = Number($('editExpDisc').value) || 0;
  const grand = Math.round((base + tax - disc) * 100) / 100;
  const needs = tax || disc;
  $('editExpTotal').hidden = !needs;
  if (needs) $('editExpTotalVal').textContent = (grand < 0 ? '−' : '') + inr(Math.abs(grand)) + (grand < 0 ? ' (invalid)' : '');
}
function updateEditTotal() { try { editGrandTotal(); } catch (_) { } }
function bindGlobal() {
  if (bindGlobal.done) return; bindGlobal.done = true;

  if ($('lightboxClose')) $('lightboxClose').onclick = () => $('lightbox').classList.remove('show');

  /* ledger payment sheet */
  if ($('sheetExpPay')) {
    $('expPayMethod').onchange = () => { $('expPayMethodOtherWrap').hidden = $('expPayMethod').value !== 'Other'; };
    $('saveExpPay').onclick = async () => {
      const eid = $('sheetExpPay').dataset.eid;
      if (!eid) return;
      const met = $('expPayMethod').value;
      const customMet = $('expPayMethodOther').value.trim();
      const j = await act('POST', `/api/expense/${eid}/payment`, {
        date: $('expPayDate').value, amount: $('expPayAmount').value,
        method: met, custom_method: customMet, note: $('expPayNote').value
      }, 'Payment recorded');
      if (j) { closeOv($('sheetExpPay')); refreshHook && refreshHook(); }
    };
  }

  /* edit entry modal */
  if ($('modalExpEdit')) {
    editCtl = attachWidget($('editAttachList'), $('editAttachInput'), { max: (window.APP && APP.max_images) || 5 });
    editInvCtl = attachWidget($('editInvList'), $('editInvInput'), { max: 1 });
    $('editAttachDrop').onclick = () => $('editAttachInput').click();
    $('editInvDrop').onclick = () => $('editInvInput').click();
    $('editExpCategory').onchange = () => { $('editExpCategoryOther').style.display = $('editExpCategory').value === '__new__' ? 'block' : 'none'; };
    $('editExpMethod').onchange = () => { $('editExpMethodOther').style.display = $('editExpMethod').value === 'Other' ? 'block' : 'none'; };
    ['editExpAmount', 'editExpTax', 'editExpDisc'].forEach(id => { const el = $(id); if (el) el.addEventListener('input', updateEditTotal); });
    $('saveExpEdit').onclick = async () => {
      const eid = $('editExpId').value;
      let cat = $('editExpCategory').value;
      let customCat = '';
      if (cat === '__new__') {
        cat = ''; customCat = $('editExpCategoryOther').value.trim();
        if (customCat.length < 2) return notify('Type the new category name.');
      }
      if (editCtl.busy()) return notify('Please wait for the bill upload to finish.');
      if (editInvCtl.busy()) return notify('Please wait for the invoice upload to finish.');
      const met = $('editExpMethod').value;
      const customMet = $('editExpMethodOther').value.trim();
      const j = await act('PUT', '/api/expense/' + eid, {
        date: $('editExpDate').value,
        type: $('editExpType').value,
        category: cat, custom_category: customCat,
        vendor: $('editExpVendor').value,
        bill_number: $('editExpBill').value,
        description: $('editExpDesc').value,
        quantity: $('editExpQty').value.trim(),
        unit_price: $('editExpUnit').value,
        tax: $('editExpTax').value,
        discount: $('editExpDisc').value,
        due_date: $('editExpDue').value,
        amount: $('editExpAmount').value,
        method: met, custom_method: customMet,
        note: $('editExpNote').value,
        attachments: editCtl.get(),
        invoice: editInvCtl.get()
      }, ((window.APP && APP.ledger) || 'Ledger') + ' entry updated');
      if (j) { closeOv($('modalExpEdit')); refreshHook && refreshHook(); }
    };
  }

  /* edit entry payment modal */
  if ($('modalExpPayEdit')) {
    $('epeMethod').onchange = () => { $('epeMethodOther').style.display = $('epeMethod').value === 'Other' ? 'block' : 'none'; };
    $('saveEpeEdit').onclick = async () => {
      const eid = $('epeEid').value, pid = $('epePid').value;
      if (!eid || !pid) return;
      const met = $('epeMethod').value;
      const j = await act('PUT', `/api/expense/${eid}/payment/${pid}`, {
        amount: $('epeAmount').value, date: $('epeDate').value,
        method: met, custom_method: $('epeMethodOther').value.trim(), note: $('epeNote').value
      }, 'Payment updated');
      if (j) { closeOv($('modalExpPayEdit')); refreshHook && refreshHook(); }
    };
  }

  /* vendor settle sheet */
  if ($('sheetVendorSettle')) {
    $('vsMethod').onchange = () => { $('vsMethodOtherWrap').hidden = $('vsMethod').value !== 'Other'; };
    $('saveVendorSettle').onclick = async () => {
      const j = await act('POST', '/api/vendors/settle', {
        vendor: $('sheetVendorSettle').dataset.vendor, amount: $('vsAmount').value, date: $('vsDate').value,
        method: $('vsMethod').value, custom_method: $('vsMethodOther').value.trim(), note: $('vsNote').value
      }, 'Settlement recorded');
      if (j) { closeOv($('sheetVendorSettle')); refreshHook && refreshHook(); }
    };
  }

  /* milk payment edit modal */
  if ($('modalPayEdit')) {
    $('editPayMethod').onchange = () => { $('editPayMethodOther').style.display = $('editPayMethod').value === 'Other' ? 'block' : 'none'; };
    $('savePayEdit').onclick = async () => {
      const pid = $('editPayId').value;
      const met = $('editPayMethod').value;
      const customMet = $('editPayMethodOther') ? $('editPayMethodOther').value.trim() : '';
      const j = await act('PUT', '/api/payment/' + pid, {
        amount: $('editPayAmount').value, date: $('editPayDate').value,
        month: $('editPayMonth').value, method: met, custom_method: customMet,
        note: $('editPayNote').value
      }, 'Payment updated');
      if (j) { closeOv($('modalPayEdit')); refreshHook && refreshHook(); }
    };
  }

  if ($('cfOk')) $('cfOk').onclick = () => cfDone(true);
  if ($('cfCancel')) $('cfCancel').onclick = () => cfDone(false);
}

/* ---------------- qty chip helper ---------------- */
const PRESET_QTY = [250, 500, 750, 1000, 1500, 2000];
function bindQtyChips(container, customInput, onChange, customWrap) {
  let sel = 0, custom = false;
  const chips = () => container.querySelectorAll('.qty-chip');
  const paint = () => {
    chips().forEach(b => b.classList.toggle('on', b.dataset.custom ? custom : (!custom && Number(b.dataset.qty) === sel)));
    if (customWrap) customWrap.hidden = !custom;
    onChange && onChange(sel);
  };
  chips().forEach(b => b.onclick = () => {
    if (b.dataset.custom) {
      custom = true; sel = Math.max(0, Number(customInput && customInput.value) || 0);
      paint(); customInput && customInput.focus();
    } else {
      custom = false; sel = Number(b.dataset.qty); if (customInput) customInput.value = ''; paint();
    }
  });
  if (customInput) customInput.addEventListener('input', () => {
    sel = Math.max(0, Number(customInput.value) || 0);
    onChange && onChange(sel);
  });
  return {
    set(v, fromChip) {
      sel = Number(v) || 0;
      const nonPreset = !PRESET_QTY.includes(sel) && sel > 0;
      custom = !!customWrap && nonPreset;
      if (customInput) customInput.value = (customWrap ? custom : nonPreset && !fromChip) ? sel : '';
      paint();
    },
    get: () => sel,
    paint
  };
}

/* ============================================================
   PAGE: HOME
   ============================================================ */
const pages = {};
pages.home = () => start(async () => {
  $('greetingDate').textContent = today.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  await load();

  /* mark-delivery form */
  let status = 'delivered';
  const dateInput = $('deliveryDate');
  dateInput.value = todayKey; dateInput.max = todayKey;
  const qty = bindQtyChips($('qtyOptions'), $('customQty'), updatePreview, $('customQtyWrap'));
  qty.set(state.quantity || 500);

  const setStatus = s => {
    status = s;
    $('deliveredChoice').classList.toggle('on', s === 'delivered');
    $('skippedChoice').classList.toggle('on', s === 'skipped');
    $('qtyOptions').style.opacity = s === 'skipped' ? .45 : 1;
    $('customQtyWrap').style.opacity = s === 'skipped' ? .45 : 1;
    updatePreview();
  };
  $('deliveredChoice').onclick = () => setStatus('delivered');
  $('skippedChoice').onclick = () => setStatus('skipped');

  function updatePreview() {
    const k = dateInput.value || todayKey;
    const amt = status === 'delivered' ? Math.round((qty.get() || 0) / 1000 * priceOn(k) * 100) / 100 : 0;
    $('previewAmount').textContent = inr(amt);
  }
  dateInput.addEventListener('change', () => { fillForm(); updatePreview(); });

  function recordFor(k) { return (state.records || {})[k]; }
  /* save button label: long text on desktop, short text on phone screens (CSS swaps them) */
  function setSaveLabel(full, short) {
    $('saveBtnLabel').innerHTML = '<span class="lbl-full">' + full + '</span><span class="lbl-short">' + short + '</span>';
  }
  function fillForm() {
    const k = dateInput.value || todayKey;
    const r = recordFor(k);
    if (r) {
      setStatus(r.status);
      if (r.status === 'delivered') qty.set(r.quantity || 500);
      setSaveLabel('Update Delivery', 'Update');
    } else {
      setStatus('delivered');
      setSaveLabel('Save Delivery', 'Save');
    }
    paintPill();
  }
  function paintPill() {
    const k = dateInput.value || todayKey;
    const r = recordFor(k);
    const pill = $('markStatusPill');
    if (!r) { pill.textContent = 'Not marked'; pill.className = 'tx-chip partial'; }
    else if (r.status === 'delivered') { pill.textContent = 'Delivered'; pill.className = 'tx-chip paid'; }
    else { pill.textContent = 'Skipped'; pill.className = 'tx-chip unpaid'; }
  }

  $('saveBtn').onclick = async () => {
    const k = dateInput.value;
    if (!k) return notify('Pick a date first.');
    const useQty = status === 'delivered' ? qty.get() : 0;
    if (status === 'delivered' && (!useQty || useQty < 50)) return notify('Choose or type a quantity.');
    const j = await act('PUT', '/api/record', { date: k, status, quantity: useQty }, 'Delivery saved');
    if (j) { fillForm(); loadSummary(); }
  };

  /* header search: filters the app's pages, Enter opens the first match */
  const sBtn = $('searchBtn'), sPanel = $('searchPanel'), sInput = $('searchInput');
  const sItems = () => Array.from(document.querySelectorAll('#searchResults .sr-item'));
  const sFilter = () => {
    const q = sInput.value.trim().toLowerCase();
    let n = 0;
    sItems().forEach(a => {
      const hit = !q || (a.textContent + ' ' + (a.dataset.kw || '')).toLowerCase().includes(q);
      a.hidden = !hit; if (hit) n++;
    });
    $('searchEmpty').hidden = n > 0;
  };
  sBtn.onclick = () => {
    const open = sPanel.hidden;
    sPanel.hidden = !open; sBtn.setAttribute('aria-expanded', String(open)); sBtn.classList.toggle('on', open);
    if (open) { sInput.value = ''; sFilter(); sInput.focus(); }
  };
  sInput.addEventListener('input', sFilter);
  sInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') { const a = sItems().find(x => !x.hidden); if (a) location.href = a.href; }
    if (e.key === 'Escape') sBtn.onclick();
  });
  $('bellBtn').onclick = () => { location.href = '/notifications'; };
  /* red dot on the bell only while something unread is waiting */
  buildNotifs().then(list => {
    $('bellBtn').classList.toggle('has-dot', notifOn() && list.some(n => !n.read));
  }).catch(() => { });
  if (state.name) $('greetingName').textContent = state.name.split(' ')[0] || state.name;
  setAvatar($('hbAvatar'), state.name);
  { const h = new Date().getHours(); $('greetingWord').textContent = (h < 12 ? 'Good Morning,' : h < 17 ? 'Good Afternoon,' : 'Good Evening,'); }

  /* Recent deliveries: the latest 5 marked days */
  function renderRecent() {
    const box = $('recentList'); if (!box) return;
    const rows = Object.entries(state.records || {}).filter(([, r]) => r && r.status).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 5);
    if (!rows.length) { box.innerHTML = '<div class="recent-empty">No deliveries marked yet.</div>'; return; }
    box.innerHTML = rows.map(([k, r]) => {
      const d = new Date(k + 'T00:00:00'), ok = r.status === 'delivered';
      const q = Number(r.quantity) || 0;
      const amt = ok ? Math.round(q / 1000 * priceOn(k) * 100) / 100 : 0;
      return '<div class="rc-row"><span class="rc-ava ico ' + (ok ? 'milk' : 'skip') + '">' + ic(ok ? 'milk' : 'x', '') + '</span>' +
        '<span class="rc-main"><b>' + (ok ? 'Milk delivered' : 'Delivery skipped') + '</b><small>' + (ok ? q + ' ml' : 'No milk') + '</small></span>' +
        '<span class="rc-end"><small>' + d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) + '</small><b class="' + (ok ? 'amt' : 'none') + '">' + (ok ? inr(amt) : '—') + '</b></span></div>';
    }).join('');
  }
  renderRecent();

  /* ---- summary card: dropdown decides what is shown (milk / all / purchases / expenses / credit) ---- */
  let homeSm = null, homeItems = [];
  const sel = $('homeView');
  try { const saved = localStorage.getItem('mm_home_view'); if (saved && [...sel.options].some(o => o.value === saved)) sel.value = saved; } catch (_) { }
  const sumItems = list => list.reduce((a, i) => ({ total: a.total + (Number(i.amount) || 0), paid: a.paid + (Number(i.paid) || 0), due: a.due + (Number(i.due) || 0), n: a.n + 1 }), { total: 0, paid: 0, due: 0, n: 0 });
  function paintHome() {
    if (!homeSm) return;
    const sm = homeSm, v = sel.value, mon = today.toLocaleDateString('en-IN', { month: 'long' });
    const milk = { total: Number(sm.amount) || 0, paid: Number(sm.paid) || 0, due: Math.max(0, Number(sm.balance) || 0) };
    const pick = t => sumItems(homeItems.filter(i => t === 'other' ? i.type !== 'credit' : i.type === t));
    let big, label, rows, st, payHref = '/payment', more = ['Full bill ›', '/bill'], showPay = true;
    if (v === 'milk') {
      st = payStatus(sm); big = milk.due; label = 'Milk to pay · ' + mon;
      rows = [['Milk bill', inr(milk.total)], ['Paid', inr(milk.paid), 'ok'], ['Milk', litres(sm.ml)]];
    } else if (v === 'credit') {
      const c = pick('credit'), last = homeItems.filter(i => i.type === 'credit').map(i => i.date).sort().pop();
      big = c.total; label = 'Credit received · ' + mon; showPay = false; more = ['KhataBook ›', '/khata'];
      st = c.n ? { label: 'Received', cls: 'ok', pct: 100, txt: c.n + (c.n === 1 ? ' entry' : ' entries') + ' received' } : { label: 'No entries', cls: 'none', pct: 0, txt: 'No credit added this month' };
      rows = [['Received', inr(c.total), 'ok'], ['Entries', String(c.n)], ['Latest', last ? shortDay(last).replace(/ \d{4}$/, '') : '—']];
    } else {
      let t, nm;
      if (v === 'all') { const o = pick('other'); t = { total: milk.total + o.total, paid: milk.paid + o.paid, due: milk.due + o.due, n: o.n }; nm = 'All payments';
        rows = [['Milk due', inr(milk.due)], ['Other due', inr(o.due)], ['Paid', inr(t.paid), 'ok']]; more = ['Reports ›', '/reports']; }
      else { t = pick(v); nm = v === 'purchase' ? 'Purchases' : 'Expenses'; payHref = '/payment?cat=' + v; more = ['KhataBook ›', '/khata'];
        rows = [['Total', inr(t.total)], ['Paid', inr(t.paid), 'ok'], ['Entries', String(t.n)]]; }
      big = t.due; label = nm + ' to pay · ' + mon;
      st = (v !== 'all' && !t.n) ? { label: 'No entries', cls: 'none', pct: 0, txt: 'Nothing added this month' } : payStatus({ amount: t.total, paid: t.paid, balance: t.due });
    }
    $('balBig').textContent = inr(big);
    $('homeSumLabel').textContent = label;
    ['balL1', 'balL2', 'balL3'].forEach((id, i) => { $(id).textContent = rows[i][0]; const b = $('balV' + (i + 1)); b.textContent = rows[i][1]; b.className = rows[i][2] || ''; });
    const pill = $('homePayPill'); pill.textContent = st.label; pill.className = 'pay-pill ' + st.cls;
    $('homeProg').style.width = st.pct + '%'; $('homeProg').parentElement.className = 'pay-prog ' + st.cls;
    $('homeProgTxt').textContent = st.txt;
    const pb = $('homePayBtn'); pb.hidden = !showPay || big <= 0.009; pb.href = payHref;
    const ml = $('homeMoreLink'); ml.textContent = more[0]; ml.href = more[1];
  }
  sel.onchange = () => { try { localStorage.setItem('mm_home_view', sel.value); } catch (_) { } paintHome(); };

  async function loadSummary() {
    renderRecent();
    try {
      const itemsReq = api('/api/expenses?month=' + monthNow()).catch(() => null); /* runs in parallel with the summary */
      const sm = await getSummary(monthNow());
      $('homeDelivered').textContent = sm.delivered;
      $('homeSkipped').textContent = sm.skipped;
      $('homePending').textContent = sm.pending;
      $('homeLitres').textContent = litres(sm.ml);
      homeSm = sm;
      { const x = await itemsReq; homeItems = (x && x.items) || homeItems || []; }
      paintHome();
    } catch (e) { /* toast already surfaced by api() */ }
  }
  fillForm();
  loadSummary();
});

/* ============================================================
   PAGE: CALENDAR
   ============================================================ */
pages.calendar = () => start(async () => {
  let view = new Date(); view.setDate(1);
  let sum = null;

  async function loadMonth() {
    const ym = monthKey(view);
    $('calMonth').textContent = monthName(ym);
    try {
      sum = await getSummary(ym);
      $('calBill').textContent = inr(sum.amount);
      $('calPaid').textContent = inr(sum.paid);
      $('calBalance').textContent = inr(Math.max(0, sum.balance));
      $('calRate').textContent = CUR + sum.rate + ' / L';
    } catch (e) { sum = null; }
    render();
  }

  function render() {
    const grid = $('calGrid');
    grid.innerHTML = '';
    const y = view.getFullYear(), m = view.getMonth();
    const first = new Date(y, m, 1);
    const daysIn = new Date(y, m + 1, 0).getDate();
    const lead = first.getDay();
    const trail = (7 - ((lead + daysIn) % 7)) % 7;
    const prevDays = new Date(y, m, 0).getDate();
    const dayMap = {};
    if (sum && sum.days) sum.days.forEach(d => { dayMap[Number(d.date.slice(-2))] = d; });

    const addCell = (label, cls, k) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cal-day ' + cls;
      const rec = k ? dayMap[Number(k.slice(-2))] : null;
      let icon = '', tip = '';
      if (rec) {
        const del = rec.status === 'delivered';
        b.classList.add(del ? 'delivered' : 'skipped');
        icon = ic(del ? 'check' : 'x');
        tip = del
          ? `Delivered · ${litres(rec.quantity)} · ${inr(rec.amount)}${rec.note ? ' · ' + rec.note : ''}`
          : `Skipped${rec.note ? ' · ' + rec.note : ''}`;
      } else if (k && parseKey(k) <= today) {
        b.classList.add('unmarked');
        icon = ic('clock');
        tip = 'Not marked yet';
      }
      b.innerHTML = `<b>${label}</b>${icon ? `<span class="cd-st">${icon}</span>` : ''}`;
      if (k && tip) b.title = niceDay(k) + ' — ' + tip;
      if (k && k === todayKey) b.classList.add('sel');
      if (k && parseKey(k) <= today) b.onclick = () => openMark(k);
      grid.appendChild(b);
    };
    for (let i = lead - 1; i >= 0; i--) { const c = document.createElement('span'); c.className = 'cal-day dim'; c.textContent = prevDays - i; grid.appendChild(c); }
    for (let d = 1; d <= daysIn; d++) {
      const k = `${y}-${pad(m + 1)}-${pad(d)}`;
      addCell(d, parseKey(k) > today ? 'future' : '', k);
    }
    for (let i = 1; i <= trail; i++) { const c = document.createElement('span'); c.className = 'cal-day dim'; c.textContent = i; grid.appendChild(c); }
  }

  /* mark-day sheet */
  let markKey = todayKey;
  let markStatus = 'delivered';
  const mQty = bindQtyChips($('mQtyChips'), $('mCustomQty'), updateMPreview);
  const setMStatus = s => {
    markStatus = s;
    $('mDelivered').classList.toggle('on', s === 'delivered');
    $('mSkipped').classList.toggle('on', s === 'skipped');
    $('mQtyChips').style.opacity = s === 'skipped' ? .45 : 1;
    $('mCustomQty').style.opacity = s === 'skipped' ? .45 : 1;
    updateMPreview();
  };
  $('mDelivered').onclick = () => setMStatus('delivered');
  $('mSkipped').onclick = () => setMStatus('skipped');
  function updateMPreview() {
    const amt = markStatus === 'delivered' ? Math.round((mQty.get() || 0) / 1000 * priceOn(markKey) * 100) / 100 : 0;
    $('mPreview').textContent = inr(amt);
  }
  function openMark(k) {
    markKey = k;
    $('markDayTitle').textContent = 'Mark · ' + niceDay(k);
    const rec = sum && sum.days ? sum.days.find(d => d.date === k) : null;
    if (rec) {
      setMStatus(rec.status);
      if (rec.status === 'delivered') mQty.set(rec.quantity || 500);
      $('mNote').value = rec.note || '';
    } else {
      setMStatus('delivered');
      mQty.set(state.quantity || 500);
      $('mNote').value = '';
    }
    openOv($('sheetMark'));
  }
  $('mSave').onclick = async () => {
    const useQty = markStatus === 'delivered' ? mQty.get() : 0;
    if (markStatus === 'delivered' && (!useQty || useQty < 50)) return notify('Choose or type a quantity.');
    const j = await act('PUT', '/api/record', { date: markKey, status: markStatus, quantity: useQty, note: $('mNote').value.trim() }, 'Delivery saved');
    if (j) { closeOv($('sheetMark')); loadMonth(); }
  };
  $('mClear').onclick = async () => {
    if (!(await confirmBox('Clear this day?', 'The record will be removed.', 'Clear'))) return;
    const j = await act('DELETE', '/api/record/' + markKey, null, 'Day cleared');
    if (j) { closeOv($('sheetMark')); loadMonth(); }
  };

  $('calPrev').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); loadMonth(); };
  $('calNext').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); loadMonth(); };

  await load();
  mQty.set(state.quantity || 500);
  await loadMonth();
});

/* ============================================================
   PAGE: KHATABOOK
   ============================================================ */
pages.khata = () => start(async () => {
  let milk = [];      // delivered days as +lines
  let items = [];     // expense entries
  let filter = 'all';
  let query = { text: '', month: '', status: '', category: '', vendor: '' };
  let showAll = false;
  let period = 'month';
  const PAGE = 12;
  const curYm = monthNow();
  const inPeriod = d => period === 'all' || String(d || '').startsWith(curYm);

  await load();
  async function fetchData() {
    try {
      const [h, x] = await Promise.all([api('/api/history'), api('/api/expenses')]);
      milk = (h.rows || []).filter(r => r.status === 'delivered' && r.amount > 0)
        .map(r => ({ kind: 'milk', id: 'm' + r.date, date: r.date, amount: r.amount, qty: r.quantity }));
      items = (x.items || []);
    } catch (e) { milk = []; items = []; }
    fillDropdowns();
    render();
  }

  function matchQuery(it) {
    if (query.month && !(it.date || '').startsWith(query.month)) return false;
    if (query.status && it.status !== query.status) return false;
    if (query.category && String(it.category).toLowerCase() !== query.category.toLowerCase()) return false;
    if (query.vendor && String(it.vendor || '').toLowerCase() !== query.vendor.toLowerCase()) return false;
    if (query.text) {
      const hay = [it.vendor, it.description, it.category, it.note, it.bill_number, it.title].filter(Boolean).join(' ').toLowerCase();
      if (!hay.includes(query.text.toLowerCase())) return false;
    }
    return true;
  }

  function currentList() {
    let list;
    if (filter === 'all') list = [...milk, ...items];
    else if (filter === 'milk') list = [...milk];
    else list = items.filter(x => x.type === filter);
    list = list.filter(matchQuery).filter(x => inPeriod(x.date));
    list.sort((a, b) => String(b.date).localeCompare(String(a.date)));
    return list;
  }

  function rowHtml(it) {
    if (it.kind === 'milk') {
      return `<div class="tx-row" data-milk="${esc(it.date)}">
        <span class="tx-ico" style="background:var(--red-soft);color:var(--red)">${ic('milk')}</span>
        <div class="tx-main"><div class="tx-title">Milk delivery</div><div class="tx-sub">${litres(it.qty)} · billed to milk account</div></div>
        <span class="tx-amt-wrap"><span class="tx-amt neg">−${inr(it.amount)}</span><small class="tx-st muted">Milk bill</small></span>
      </div>`;
    }
    const meta = catMeta(it.category);
    const [bg, fg] = COLOR_VARS[meta.color];
    const credit = it.type === 'credit';
    const sub = esc(it.vendor || it.description || (credit ? 'Credit' : it.type === 'purchase' ? 'Purchase' : 'Expense'));
    let st;
    if (credit) st = '<small class="tx-st ok">Received</small>';
    else if (Number(it.due) <= 0.009) st = '<small class="tx-st ok">Paid</small>';
    else if (Number(it.paid) > 0) st = `<small class="tx-st part">Paid ${inr(it.paid)} · Due ${inr(it.due)}</small>`;
    else st = `<small class="tx-st due">Due ${inr(it.due)}</small>`;
    return `<div class="tx-row" data-eid="${esc(it.id)}">
      <span class="tx-ico" style="background:${bg};color:${fg}">${ic(meta.icon)}</span>
      <div class="tx-main"><div class="tx-title">${esc(it.category)}${it.bill_number ? ' · #' + esc(it.bill_number) : ''}</div>
      <div class="tx-sub">${sub}</div></div>
      <span class="tx-amt-wrap"><span class="tx-amt ${credit ? 'pos' : 'neg'}">${credit ? '+' : '−'}${inr(it.amount)}</span>${st}</span>
    </div>`;
  }

  /* "Today" / "Yesterday" / "12 Oct" headers so the ledger reads like a passbook */
  const yestKey = dateKey(new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1));
  function dayLabel(k) {
    if (k === todayKey) return 'Today';
    if (k === yestKey) return 'Yesterday';
    const d = new Date(k + 'T00:00:00');
    return d.toLocaleDateString('en-IN', d.getFullYear() === today.getFullYear() ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' });
  }
  function groupedHtml(list) {
    const groups = [];
    list.forEach(it => {
      let g = groups[groups.length - 1];
      if (!g || g.date !== it.date) { g = { date: it.date, rows: [] }; groups.push(g); }
      g.rows.push(it);
    });
    return groups.map(g => {
      const spent = g.rows.reduce((a, x) => a + (x.type === 'credit' ? 0 : Number(x.amount) || 0), 0);
      return '<div class="day-head"><span>' + esc(dayLabel(g.date)) + '</span>' + (spent > 0 ? '<b>−' + inr(spent) + '</b>' : '') + '</div>' + g.rows.map(rowHtml).join('');
    }).join('');
  }

  function render() {
    const list = currentList();
    const visible = showAll ? list : list.slice(0, PAGE);
    const box = $('txList');
    if (!list.length) {
      const hasQ = !!(query.text || query.month || query.status || query.category || query.vendor);
      box.innerHTML = hasQ
        ? emptyState('ill-search', 'No matches found', 'Nothing fits these filters right now. Try a different keyword or clear them.')
        : emptyState('ill-ledger', 'No transactions here', `Tap <b>+ Add</b> to record your first ${filter === 'all' ? 'entry' : filter + ' entry'}.`);
    } else {
      box.innerHTML = groupedHtml(visible);
      box.querySelectorAll('[data-eid]').forEach(row => row.onclick = () => openEntrySheet(row.dataset.eid));
      box.querySelectorAll('[data-milk]').forEach(row => row.onclick = () => { window.location.href = '/bill?day=' + row.dataset.milk; });
    }
    $('viewAllBtn').hidden = list.length <= PAGE;
    $('viewAllBtn').innerHTML = showAll
      ? 'Show less <span class="nav-arrow" style="transform:rotate(90deg);display:inline-block">→</span>'
      : `View All Transactions <span class="nav-arrow">→</span>`;

    /* ---------- My spending: milk + purchases + expenses, what is paid and what is left ---------- */
    const mRows = milk.filter(x => inPeriod(x.date));
    const milkBilled = mRows.reduce((a, x) => a + Number(x.amount || 0), 0);
    const milkPaid = (state.payments || []).filter(p => period === 'all' || p.month === curYm).reduce((a, p) => a + Number(p.amount || 0), 0);
    const milkDue = Math.max(0, Math.round((milkBilled - milkPaid) * 100) / 100);
    const sumBy = rows => rows.reduce((a, x) => ({ n: a.n + 1, total: a.total + Number(x.amount || 0), paid: a.paid + Number(x.paid || 0), due: a.due + Number(x.due || 0) }), { n: 0, total: 0, paid: 0, due: 0 });
    const scoped = items.filter(x => inPeriod(x.date));
    const buy = sumBy(scoped.filter(x => x.type === 'purchase'));
    const exp = sumBy(scoped.filter(x => x.type === 'debit'));
    const recv = scoped.filter(x => x.type === 'credit').reduce((a, x) => a + Number(x.amount || 0), 0);
    const spent = milkBilled + buy.total + exp.total;
    const paidAll = Math.min(milkPaid, milkBilled) + buy.paid + exp.paid;
    const dueAll = milkDue + buy.due + exp.due;
    const st = payStatus({ amount: spent, paid: paidAll, balance: dueAll });
    const mon = today.toLocaleDateString('en-IN', { month: 'long' });
    $('spLabel').textContent = 'Total spent · ' + (period === 'all' ? 'all time' : mon);
    $('spTotal').textContent = inr(spent);
    $('spPill').textContent = st.label; $('spPill').className = 'pay-pill ' + st.cls;
    $('spProg').style.width = st.pct + '%'; $('spProg').parentElement.className = 'pay-prog ' + st.cls;
    $('spProgTxt').textContent = spent > 0 ? st.pct + '% paid · ' + inr(paidAll) + ' of ' + inr(spent) : 'Nothing spent yet';
    $('spPaid').textContent = inr(paidAll);
    $('spDue').textContent = inr(dueAll);
    $('spRecv').textContent = inr(recv);
    const line = (p, d) => 'Paid ' + inr(p) + ' · Due ' + inr(d);
    $('spMilk').textContent = inr(milkBilled); $('spMilkSub').textContent = mRows.length + (mRows.length === 1 ? ' day' : ' days') + ' · ' + line(Math.min(milkPaid, milkBilled), milkDue);
    $('spBuy').textContent = inr(buy.total);   $('spBuySub').textContent = buy.n + (buy.n === 1 ? ' entry' : ' entries') + ' · ' + line(buy.paid, buy.due);
    $('spExp').textContent = inr(exp.total);   $('spExpSub').textContent = exp.n + (exp.n === 1 ? ' entry' : ' entries') + ' · ' + line(exp.paid, exp.due);
    $('khataCount').textContent = `${list.length} transactions · ${period === 'all' ? 'all time' : mon}`;
    $('listChip').textContent = list.length;
  }

  function fillDropdowns() {
    const cats = [...new Set(items.map(x => x.category).filter(Boolean))].sort();
    const vends = [...new Set(items.map(x => x.vendor).filter(Boolean))].sort();
    $('fCategory').innerHTML = '<option value="">All categories</option>' + cats.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
    $('fVendor').innerHTML = '<option value="">All vendors</option>' + vends.map(v => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
  }

  $$('.chips .chip-f').forEach(ch => ch.onclick = () => {
    $$('.chips .chip-f').forEach(c => c.classList.remove('on'));
    ch.classList.add('on');
    filter = ch.dataset.filter;
    showAll = false;
    render();
  });
  $$('.kb-tabs .kb-tab[data-period]').forEach(b => b.onclick = () => {
    period = b.dataset.period; showAll = false;
    $$('.kb-tabs .kb-tab[data-period]').forEach(x => x.classList.toggle('on', x === b));
    render();
  });
  $('viewAllBtn').onclick = () => { showAll = !showAll; render(); window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }); };

  $('searchBtn').onclick = () => openOv($('sheetSearch'));
  $('fApply').onclick = () => {
    query = {
      text: $('fText').value.trim(), month: $('fMonth').value,
      status: $('fStatus').value, category: $('fCategory').value, vendor: $('fVendor').value
    };
    closeOv($('sheetSearch'));
    showAll = true;
    render();
  };
  $('fClear').onclick = () => {
    $('fText').value = ''; $('fMonth').value = ''; $('fStatus').value = ''; $('fCategory').value = ''; $('fVendor').value = '';
    query = { text: '', month: '', status: '', category: '', vendor: '' };
    showAll = false;
    render();
  };

  setRefresh(() => fetchData());
  await fetchData();
});

/* ============================================================
   PAGE: ADD NEW ENTRY
   ============================================================ */
pages.entry = () => start(async () => {
  await load();
  let etype = 'debit';
  const dateInput = $('expDate');
  dateInput.value = todayKey; dateInput.max = todayKey;

  /* two separate uploads: 1 invoice document + up to 5 bill photos */
  const attach = attachWidget($('expAttachList'), $('expAttachInput'), { max: (window.APP && APP.max_images) || 5 });
  $('expAttachDrop').onclick = () => $('expAttachInput').click();
  const invoiceCtl = attachWidget($('expInvList'), $('expInvInput'), { max: 1 });
  $('expInvDrop').onclick = () => $('expInvInput').click();

  /* live grand total = amount + tax − discount */
  function updateGrand() {
    const base = Number($('expAmount').value) || 0;
    const tax = Number($('expTax').value) || 0;
    const disc = Number($('expDisc').value) || 0;
    const grand = Math.round((base + tax - disc) * 100) / 100;
    const needs = tax || disc;
    $('expTotal').hidden = !needs;
    if (needs) $('expTotalVal').textContent = (grand < 0 ? '−' : '') + inr(Math.abs(grand)) + (grand < 0 ? ' (invalid)' : '');
  }
  ['expAmount', 'expTax', 'expDisc'].forEach(id => $(id).addEventListener('input', updateGrand));

  $$('.type-chip').forEach(ch => ch.onclick = () => {
    $$('.type-chip').forEach(c => c.classList.remove('on'));
    ch.classList.add('on');
    etype = ch.dataset.type;
    $('expPaidWrap').style.display = etype === 'credit' ? 'none' : '';
  });
  $('expCategory').onchange = () => { $('expCategoryOther').hidden = $('expCategory').value !== '__new__'; };
  $('expVendor').onchange = () => { $('expVendorOther').hidden = $('expVendor').value !== '__new__'; };
  $('expMethod').onchange = () => { $('expMethodOther').hidden = $('expMethod').value !== 'Other'; };
  const moreToggle = $('moreToggle'), moreBox = $('moreBox'), moreChev = $('moreChev');
  const flipMore = () => {
    moreBox.hidden = !moreBox.hidden;
    moreChev.style.transform = moreBox.hidden ? 'rotate(90deg)' : 'rotate(270deg)';
    moreToggle.setAttribute('aria-expanded', String(!moreBox.hidden));
  };
  moreToggle.onclick = flipMore;
  moreToggle.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flipMore(); } };

  $('expSaveBtn').onclick = async () => {
    const amount = Number($('expAmount').value);
    if (!amount || amount <= 0) return notify('Enter a valid amount.');
    if (!dateInput.value) return notify('Pick a date.');
    const tax = Number($('expTax').value) || 0;
    const disc = Number($('expDisc').value) || 0;
    if (Math.round((amount + tax - disc) * 100) / 100 < 0) return notify('Discount cannot be more than amount + tax.');
    let category = $('expCategory').value;
    let customCategory = '';
    if (category === '__new__') {
      customCategory = $('expCategoryOther').value.trim();
      if (customCategory.length < 2) return notify('Type the new category name.');
      category = '';
    }
    let vendor = $('expVendor').value;
    let customVendor = '';
    if (vendor === '__new__') {
      customVendor = $('expVendorOther').value.trim();
      if (customVendor.length < 2) return notify('Type the vendor / shop name.');
      vendor = '';
    }
    if (attach.busy()) return notify('Please wait for the bill photos to finish uploading.');
    if (invoiceCtl.busy()) return notify('Please wait for the invoice to finish uploading.');
    const method = $('expMethod').value;
    const customMethod = $('expMethodOther').value.trim();
    const paidNow = etype === 'credit' ? 0 : Number($('expPaidNow').value || 0);
    if (paidNow > amount + 0.009) return notify('Paid amount cannot exceed the total amount.');

    const j = await act('POST', '/api/expense', {
      date: dateInput.value, type: etype,
      category, custom_category: customCategory,
      vendor, custom_vendor: customVendor,
      bill_number: $('expBillNumber').value.trim(),
      description: $('expDesc').value.trim(),
      quantity: $('expQty').value.trim(),
      unit_price: $('expUnit').value,
      tax: $('expTax').value,
      discount: $('expDisc').value,
      due_date: $('expDueDate').value,
      amount, method, custom_method: customMethod,
      paid: paidNow || undefined,
      note: $('expNote').value.trim(),
      attachments: attach.get(),
      invoice: invoiceCtl.get()
    }, 'Entry saved to KhataBook');
    if (j) setTimeout(() => { window.location.href = '/khata'; }, 450);
  };
});

/* ============================================================
   PAGE: REPORTS
   ============================================================ */
pages.reports = () => start(async () => {
  let view = new Date(); view.setDate(1);
  let lastSm = null, lastExp = null, lastYm = '';
  const trendCache = {};

  async function loadRep() {
    const ym = monthKey(view);
    $('repMonthName').textContent = monthName(ym);
    let sm;
    try { sm = await getSummary(ym); } catch (e) { return; }
    const exp = Object.assign({ spent: 0, paid: 0, due: 0, purchases_total: 0, received: 0, debit_count: 0, purchase_count: 0, credit_count: 0, top_categories: [] }, sm.expenses || {});
    const milk = Number(sm.amount) || 0, milkPaid = Number(sm.paid) || 0, milkDue = Math.max(0, Number(sm.balance) || 0);
    const buy = Number(exp.purchases_total) || 0, other = Math.max(0, (Number(exp.spent) || 0) - buy);
    const total = milk + (Number(exp.spent) || 0), paid = milkPaid + (Number(exp.paid) || 0), due = milkDue + Math.max(0, Number(exp.due) || 0);
    const n = (c, w) => c + (c === 1 ? ' ' + w : ' ' + w + 's');

    /* overview card */
    $('repTotal').textContent = inr(total);
    const st = payStatus({ amount: total, paid, balance: due });
    $('repPayPill').textContent = st.label; $('repPayPill').className = 'pay-pill ' + st.cls;
    $('repPaidAll').textContent = inr(paid);
    $('repDueAll').textContent = inr(due);
    $('repRecv').textContent = inr(exp.received || 0);
    /* all-time totals: everything spent on milk + purchases + expenses, and how much of it is paid */
    const ov = sm.overall || {};
    $('atSpent').textContent = inr((Number(ov.billed) || 0) + (Number(ov.exp_spent) || 0));
    $('atPaid').textContent = inr((Number(ov.paid) || 0) + (Number(ov.exp_paid) || 0));
    $('atDue').textContent = inr(Math.max(0, Number(ov.due) || 0) + Math.max(0, Number(ov.exp_due) || 0));
    const parts = [['m', 'Milk', milk], ['p', 'Purchases', buy], ['e', 'Expenses', other]];
    $('splitBar').innerHTML = total > 0
      ? parts.filter(p => p[2] > 0).map(p => '<i class="seg-' + p[0] + '" style="flex:' + p[2] + '"></i>').join('')
      : '<i class="seg-0" style="flex:1"></i>';
    $('splitLegend').innerHTML = parts.map(p => '<span><i class="lgd seg-' + p[0] + '"></i>' + p[1] + ' ' + inr(p[2]) + '</span>').join('');

    /* milk */
    $('repLitres').textContent = litres(sm.ml);
    $('repAmount').textContent = inr(milk);
    $('repAvg').textContent = sm.delivered ? litres(sm.avg_ml || 0) : '—';
    $('sumDelivered').textContent = sm.delivered;
    $('sumSkipped').textContent = sm.skipped;
    $('sumPending').textContent = sm.pending;

    /* money breakdown */
    $('brkMilk').textContent = inr(milk);
    $('brkMilkSub').textContent = 'Paid ' + inr(milkPaid) + ' · Due ' + inr(milkDue);
    $('brkBuy').textContent = inr(buy);
    $('brkBuySub').textContent = n(exp.purchase_count || 0, 'entry').replace('entrys', 'entries');
    $('brkExp').textContent = inr(other);
    $('brkExpSub').textContent = n(Math.max(0, (exp.debit_count || 0) - (exp.purchase_count || 0)), 'entry').replace('entrys', 'entries');
    $('brkGot').textContent = inr(exp.received || 0);
    $('brkGotSub').textContent = n(exp.credit_count || 0, 'entry').replace('entrys', 'entries');
    $('brkOtherDue').textContent = inr(Math.max(0, exp.due || 0));

    /* top categories */
    const cats = exp.top_categories || [], max = Math.max(1, ...cats.map(c => c.amount));
    $('catCard').hidden = !cats.length;
    $('catRows').innerHTML = cats.map(c => '<div class="cat-row"><span>' + esc(c.category) + '</span><div class="cat-bar"><i style="width:' + Math.max(6, Math.round(c.amount / max * 100)) + '%"></i></div><b>' + inr(c.amount) + '</b></div>').join('');
    lastSm = sm; lastExp = exp; lastYm = ym;
    drawChart(sm);
    drawGfx();
  }

  function drawChart(sm) {
    /* nothing marked this month → friendly vector empty state instead of flat bars */
    const chartBars = $('chartBars');
    if (!((sm.delivered || 0) + (sm.skipped || 0))) {
      $('chartY').innerHTML = '<span>0</span><span>0</span><span>0</span><span>0</span>';
      chartBars.classList.add('is-empty');
      chartBars.innerHTML = emptyState('ill-milk', 'No deliveries marked', 'Mark a day — the weekly litres chart appears here.', true);
      $('chartNote').textContent = 'per week';
      return;
    }
    chartBars.classList.remove('is-empty');
    const weeks = sm.weeks || [];
    /* litres per week from day rows (backend groups: w*7 < day <= (w+1)*7) */
    const litresW = weeks.map((_, i) => (sm.days || [])
      .filter(d => d.status === 'delivered' && i * 7 < Number(d.date.slice(-2)) && Number(d.date.slice(-2)) <= (i + 1) * 7)
      .reduce((a, d) => a + (d.quantity || 0), 0) / 1000);
    const max = Math.max(...litresW, 1);
    const niceMax = Math.ceil(max * 2) / 2; // half-litre steps
    const yLabels = $('chartY');
    const step = niceMax / 3;
    yLabels.innerHTML = [3, 2, 1, 0].map(i => `<span>${(Math.round(step * i * 10) / 10).toLocaleString('en-IN', { maximumFractionDigits: 1 })}</span>`).join('');
    const PLOT = 128; // px of drawable chart height
    $('chartBars').innerHTML = litresW.map((v, i) => `
      <div class="bar-col">
        <div class="bar ${v <= 0 ? 'zero' : ''}" style="height:${v > 0 ? Math.max(6, Math.round(v / niceMax * PLOT)) : 6}px"></div>
        <span class="bar-x">W${i + 1}</span>
      </div>`).join('');
    $('chartNote').textContent = `peak ${Math.round(max * 100) / 100} L`;
  }


  /* ---------- graphs card (dropdown-driven, inline SVG) ---------- */
  const NS = v => Math.round(v * 100) / 100;
  const fmtN = v => NS(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const empty = msg => '<div class="gfx-empty">' + msg + '</div>';
  function barSvg(items, o) {
    /* items: [{label, value, cls}] — vertical bars with grid + value labels */
    const W = 320, H = 190, L = 30, B = 24, T = 16, R = 6, ph = H - B - T, pw = W - L - R;
    const max = Math.max(...items.map(i => i.value), o.min || 1);
    const nice = o.nice ? o.nice(max) : Math.ceil(max);
    const bw = Math.min(26, pw / items.length * 0.62), gap = pw / items.length;
    let g = '';
    for (let k = 0; k <= 3; k++) {
      const y = T + ph - ph * k / 3;
      g += '<line class="gfx-grid" x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '"/><text x="' + (L - 5) + '" y="' + (y + 3) + '" text-anchor="end">' + fmtN(nice * k / 3) + '</text>';
    }
    const every = items.length > 12 ? 5 : 1;
    items.forEach((it, i) => {
      const h = it.value > 0 ? Math.max(3, it.value / nice * ph) : 3, x = L + gap * i + (gap - bw) / 2, y = T + ph - h;
      g += '<rect class="gfx-bar ' + (it.value > 0 ? (it.cls || '') : 'zero') + '" x="' + x + '" y="' + y + '" width="' + bw + '" height="' + h + '" rx="4"/>';
      if (items.length <= 8 && it.value > 0) g += '<text class="gfx-val" x="' + (x + bw / 2) + '" y="' + (y - 4) + '" text-anchor="middle">' + (o.fmt ? o.fmt(it.value) : fmtN(it.value)) + '</text>';
      if (i % every === 0) g += '<text x="' + (x + bw / 2) + '" y="' + (H - 8) + '" text-anchor="middle">' + it.label + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + (o.aria || 'chart') + '">' + g + '</svg>';
  }
  function donut(parts, centerTop, centerSub) {
    const tot = parts.reduce((a, p) => a + p.value, 0);
    if (tot <= 0) return null;
    const r = 52, C = 2 * Math.PI * r; let off = 0, arcs = '';
    parts.filter(p => p.value > 0).forEach(p => {
      const len = p.value / tot * C;
      arcs += '<circle cx="70" cy="70" r="' + r + '" fill="none" stroke="' + p.color + '" stroke-width="20" stroke-dasharray="' + len + ' ' + (C - len) + '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 70 70)"/>';
      off += len;
    });
    const leg = parts.map(p => '<div><i style="background:' + p.color + '"></i>' + p.label + '<b>' + p.text + '</b></div>').join('');
    return '<div class="gfx-donut"><svg viewBox="0 0 140 140" role="img"><circle cx="70" cy="70" r="' + r + '" fill="none" stroke="var(--line-2)" stroke-width="20"/>' + arcs +
      '<text class="gfx-center" x="70" y="72">' + centerTop + '</text><text class="gfx-center-sub" x="70" y="86">' + centerSub + '</text></svg><div class="gfx-leg">' + leg + '</div></div>';
  }
  async function drawGfx() {
    const sm = lastSm, exp = lastExp, body = $('gfxBody'), note = $('gfxNote'), kind = $('gfxSelect').value;
    if (!sm) return;
    const ym = lastYm, milk = Number(sm.amount) || 0, milkPaid = Number(sm.paid) || 0, milkDue = Math.max(0, Number(sm.balance) || 0);
    const buy = Number(exp.purchases_total) || 0, other = Math.max(0, (Number(exp.spent) || 0) - buy);
    const nDays = new Date(Number(ym.slice(0, 4)), Number(ym.slice(5, 7)), 0).getDate();
    if (kind === 'daily') {
      const byDay = {}; (sm.days || []).forEach(d => { if (d.status === 'delivered') byDay[Number(d.date.slice(-2))] = (d.quantity || 0) / 1000; });
      const items = Array.from({ length: nDays }, (_, i) => ({ label: String(i + 1), value: byDay[i + 1] || 0 }));
      note.textContent = 'Litres delivered on each day of ' + monthName(ym);
      body.innerHTML = Object.keys(byDay).length ? barSvg(items, { nice: m => Math.ceil(m * 2) / 2 || 1, min: 0.5, aria: 'Daily litres' }) : empty('No deliveries marked this month.');
    } else if (kind === 'status') {
      note.textContent = 'How the days of the month were marked';
      const del = sm.delivered || 0, sk = sm.skipped || 0, pe = sm.pending || 0;
      body.innerHTML = donut([
        { label: 'Delivered', value: del, color: 'var(--ok)', text: del }, { label: 'Skipped', value: sk, color: 'var(--red)', text: sk }, { label: 'Not marked', value: pe, color: '#e0a526', text: pe }
      ], del + sk + pe, 'days') || empty('No days to show yet.');
    } else if (kind === 'money') {
      note.textContent = 'Where this month\u2019s money goes';
      const tot = milk + buy + other;
      body.innerHTML = donut([
        { label: 'Milk', value: milk, color: 'var(--btn)', text: inr(milk) }, { label: 'Purchases', value: buy, color: '#e0a526', text: inr(buy) }, { label: 'Expenses', value: other, color: '#6b7a99', text: inr(other) }
      ], inr(tot), 'total') || empty('Nothing billed this month.');
    } else if (kind === 'paid') {
      note.textContent = 'Paid and pending amounts for this month';
      const eDue = Math.max(0, Number(exp.due) || 0), ePaid = Number(exp.paid) || 0;
      const items = [{ label: 'Milk paid', value: milkPaid, cls: 'ok' }, { label: 'Milk due', value: milkDue, cls: 'no' }, { label: 'Other paid', value: ePaid, cls: 'ok' }, { label: 'Other due', value: eDue, cls: 'no' }];
      body.innerHTML = items.some(i => i.value > 0) ? barSvg(items, { nice: m => { const p = Math.pow(10, Math.max(0, String(Math.ceil(m)).length - 1)); return Math.ceil(m / p) * p || 1; }, fmt: v => inr(v), aria: 'Paid vs due' }) : empty('No amounts for this month.');
    } else if (kind === 'cats') {
      note.textContent = 'Biggest spending categories this month';
      const cats = exp.top_categories || [], mx = Math.max(1, ...cats.map(c => c.amount));
      body.innerHTML = cats.length ? cats.map(c => '<div class="cat-row"><span>' + esc(c.category) + '</span><div class="cat-bar"><i style="width:' + Math.max(6, Math.round(c.amount / mx * 100)) + '%"></i></div><b>' + inr(c.amount) + '</b></div>').join('') : empty('No categorised spending this month.');
    } else if (kind === 'trend') {
      note.textContent = 'Milk bill for the last 6 months';
      body.innerHTML = empty('Loading…');
      const [y, m] = ym.split('-').map(Number), keys = [];
      for (let i = 5; i >= 0; i--) keys.push(monthKey(new Date(y, m - 1 - i, 1)));
      const rows = await Promise.all(keys.map(async k => { if (!(k in trendCache)) { try { trendCache[k] = Number((await getSummary(k)).amount) || 0; } catch (e) { trendCache[k] = 0; } } return { label: monthName(k).slice(0, 3), value: trendCache[k], cls: k === ym ? '' : 'alt' }; }));
      if ($('gfxSelect').value !== 'trend' || lastYm !== ym) return;
      body.innerHTML = rows.some(r => r.value > 0) ? barSvg(rows, { nice: mx => { const p = Math.pow(10, Math.max(0, String(Math.ceil(mx)).length - 1)); return Math.ceil(mx / p) * p || 1; }, fmt: v => inr(v), aria: 'Monthly milk bill' }) : empty('No bills in the last 6 months.');
    }
  }
  $('gfxSelect').onchange = drawGfx;

  $('repPrev').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); loadRep(); };
  $('repNext').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); loadRep(); };

  await load();
  await loadRep();
});

/* ============================================================
   PAGE: MONTHLY MILK BILL
   ============================================================ */
pages.bill = () => start(async () => {
  let view = new Date(); view.setDate(1);
  let curSum = null;

  async function loadBill() {
    const ym = monthKey(view);
    $('billMonthName').textContent = monthName(ym);
    let sm;
    try { sm = await getSummary(ym); } catch (e) { return; }
    curSum = sm;
    $('billLitres').textContent = litres(sm.ml);
    $('billTotal').textContent = inr(sm.amount);
    $('billPaid').textContent = inr(sm.paid);
    $('billBalance').textContent = inr(Math.max(0, sm.balance));
    $('billRate').textContent = CUR + sm.rate + ' / L';
    $('billHeroAmt').textContent = inr(Math.max(0, sm.balance));
    paintPay(sm, 'bill');
    /* every "pay" entry point carries the month being viewed to the Payments page */
    ['abPay', 'billPayLink', 'billAddLink', 'billHeroPay'].forEach(id => { const a = $(id); if (a) a.href = '/payment?month=' + ym; });
    /* outstanding split: milk vs other payments (all months) */
    if ($('billDueMilk')) {
      const ov = sm.overall || { due: Math.max(0, sm.balance), exp_due: 0 };
      $('billDueMilk').textContent = inr(Math.max(0, ov.due || 0));
      $('billDueKhata').textContent = inr(Math.max(0, ov.exp_due || 0));
    }

    /* bill details — every elapsed day of the month, marked or not */
    const dayMap = {};
    (sm.days || []).forEach(d => { dayMap[d.date] = d; });
    const [yy, mm] = ym.split('-').map(Number);
    const dim = new Date(yy, mm, 0).getDate();
    const lastDay = (yy === today.getFullYear() && mm === today.getMonth() + 1) ? today.getDate() : ((new Date(yy, mm, 1) <= today) ? dim : 0);
    const rows = [];
    for (let d = 1; d <= lastDay; d++) {
      const k = `${yy}-${pad(mm)}-${pad(d)}`;
      const rec = dayMap[k];
      const dot = rec ? (rec.status === 'delivered' ? 'g' : 'r') : 'o';
      const qty = rec ? (rec.status === 'delivered' ? litres(rec.quantity) : 'Skipped') : '—';
      const amt = rec && rec.status === 'delivered' ? inr(rec.amount) : '—';
      rows.push(`<div class="bill-row" data-day="${k}" role="button" tabindex="0">
        <span class="dot ${dot}"></span>
        <span class="br-date">${shortDay(k)}</span>
        <span class="br-qty">${qty}</span>
        <span class="br-amt">${amt}</span>
      </div>`);
    }
    const billed = (sm.days || []).filter(d => d.status === 'delivered');
    $('billDays').innerHTML = rows.join('') || emptyState('ill-milk', 'No days recorded', 'Deliveries you mark this month will appear here.');
    $('billDaysChip').textContent = billed.length + ' days';
    $('billDaysTotal').textContent = inr(billed.reduce((a, d) => a + d.amount, 0));
    /* every day row opens the edit/clear day sheet (full CRUD on records) */
    if ($('sheetDay')) {
      $('billDays').querySelectorAll('[data-day]').forEach(r => {
        r.onclick = () => openDay(r.dataset.day);
        r.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDay(r.dataset.day); } };
      });
    }

    /* payments */
    const pays = sm.payments || [];
    $('paymentList').innerHTML = pays.length ? pays.map(p => `
      <div class="pay-item">
        <span class="stat-ico green">${ic('wallet')}</span>
        <div class="pi-main">
          <div style="font-weight:700;font-size:13.5px">${inr(p.amount)} · ${esc(p.method || 'Cash')}</div>
          <div style="font-size:11.5px;color:var(--faint)">${esc(p.date || '')}${p.note ? ' · ' + esc(p.note) : ''}</div>
        </div>
        <button class="icon-btn plain" data-pedit="${esc(p.id)}" aria-label="Edit payment">${ic('edit', 'sm')}</button>
        <button class="icon-btn plain danger" data-pdel="${esc(p.id)}" aria-label="Delete payment">${ic('trash', 'sm')}</button>
      </div>`).join('') : emptyState('ill-wallet', 'No payments yet', 'Payments you record for this month will appear here.');
    $('paymentList').querySelectorAll('[data-pdel]').forEach(b => b.onclick = async () => {
      if (!(await confirmBox('Delete payment?', 'This payment will be removed.', 'Delete'))) return;
      const j = await act('DELETE', '/api/payment/' + b.dataset.pdel, null, 'Payment deleted');
      if (j) loadBill();
    });
    $('paymentList').querySelectorAll('[data-pedit]').forEach(b => b.onclick = () => {
      const p = pays.find(x => String(x.id) === b.dataset.pedit);
      if (!p) return;
      $('editPayId').value = p.id;
      $('editPayMonth').value = ym;
      $('editPayAmount').value = p.amount;
      $('editPayDate').value = p.date;
      $('editPayNote').value = p.note || '';
      const known = ['Cash', 'UPI', 'Bank transfer'];
      if (known.includes(p.method)) { $('editPayMethod').value = p.method; $('editPayMethodOther').style.display = 'none'; }
      else { $('editPayMethod').value = 'Other'; $('editPayMethodOther').style.display = 'block'; $('editPayMethodOther').value = p.method || ''; }
      openOv($('modalPayEdit'));
    });
  }

  $('quickPriceBtn').onclick = async () => {
    const v = Number($('quickPrice').value);
    if (!v || v <= 0) return notify('Enter a valid rate per litre.');
    const j = await act('PUT', '/api/price', { price: v, from: todayKey }, 'Milk price updated');
    if (j) { $('quickPrice').value = ''; loadBill(); }
  };

  $('billPrev').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); loadBill(); };
  $('billNext').onclick = () => { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); loadBill(); };

  /* ---------- edit / clear a single day (sheet on the bill page) ---------- */
  let dayKey = todayKey;
  let dayStatus = 'delivered';
  const dQty = bindQtyChips($('bQtyChips'), $('bCustomQty'), updateDPreview);
  const setDStatus = s => {
    dayStatus = s;
    $('bDelivered').classList.toggle('on', s === 'delivered');
    $('bSkipped').classList.toggle('on', s === 'skipped');
    $('bQtyChips').style.opacity = s === 'skipped' ? .45 : 1;
    $('bCustomQty').style.opacity = s === 'skipped' ? .45 : 1;
    updateDPreview();
  };
  $('bDelivered').onclick = () => setDStatus('delivered');
  $('bSkipped').onclick = () => setDStatus('skipped');
  function updateDPreview() {
    const amt = dayStatus === 'delivered' ? Math.round((dQty.get() || 0) / 1000 * priceOn(dayKey) * 100) / 100 : 0;
    $('bPreview').textContent = inr(amt);
  }
  function openDay(k) {
    if (!$('sheetDay')) return;
    dayKey = k;
    $('dayTitle').textContent = 'Edit · ' + niceDay(k);
    const rec = curSum && curSum.days ? curSum.days.find(d => d.date === k) : null;
    if (rec) {
      setDStatus(rec.status);
      if (rec.status === 'delivered') dQty.set(rec.quantity || 500);
      $('bNote').value = rec.note || '';
    } else {
      setDStatus('delivered');
      dQty.set(state.quantity || 500);
      $('bNote').value = '';
    }
    openOv($('sheetDay'));
  }
  $('bSave').onclick = async () => {
    const useQty = dayStatus === 'delivered' ? dQty.get() : 0;
    if (dayStatus === 'delivered' && (!useQty || useQty < 50)) return notify('Choose or type a quantity.');
    const j = await act('PUT', '/api/record', { date: dayKey, status: dayStatus, quantity: useQty, note: $('bNote').value.trim() }, 'Day updated');
    if (j) { closeOv($('sheetDay')); loadBill(); }
  };

  await loadBill();

  /* deep link: /bill?day=YYYY-MM-DD (e.g. a milk row tapped in KhataBook) */
  const wantDay = new URLSearchParams(location.search).get('day') || '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(wantDay)) {
    const p = wantDay.split('-').map(Number);
    view = new Date(p[0], p[1] - 1, 1);
    await loadBill();
    openDay(wantDay);
  }
});


/* ============================================================
   PAGE: PAYMENTS  (month + category + status filters over milk, expenses, purchases, credit)
   ============================================================ */
pages.payment = () => start(async () => {
  await load();
  const qp = new URLSearchParams(location.search);
  const qm = qp.get('month');
  let ym = /^\d{4}-(0[1-9]|1[0-2])$/.test(qm || '') && qm <= monthNow() ? qm : monthNow();
  /* categories: Milk bill, Expenses (debit), Purchases, Credit — filter by status: all / paid / due */
  const CATS = {
    milk: { label: 'Milk', who: 'Milk', empty: 'No milk transactions' },
    debit: { label: 'Expenses', who: 'Expense', empty: 'No expense entries' },
    purchase: { label: 'Purchases', who: 'Purchase', empty: 'No purchase entries' },
    credit: { label: 'Credit', who: 'Credit', empty: 'No credit entries' }
  };
  const qc = qp.get('cat') || (qp.get('tab') === 'khata' ? 'debit' : 'milk');
  let cat = CATS[qc] ? qc : 'milk', stf = 'all';
  let sm = null, exItems = [], paid = true, kpEntry = null, kpIsPaid = true;
  const balance = () => Math.max(0, Number(sm && sm.balance) || 0);

  $('kpDate').value = todayKey; $('kpDate').max = todayKey;

  /* ---------- month / year selector (current month by default) ---------- */
  const nowYm = monthNow();
  const shiftYm = (k, d) => { const [y, m] = k.split('-').map(Number); return monthKey(new Date(y, m - 1 + d, 1)); };
  function paintMonth() {
    $('payMonth').textContent = monthName(ym);
    $('pmName').textContent = monthName(ym);
    $('pmNext').disabled = ym >= nowYm;
    $('pmPicker').value = ym; $('pmPicker').max = nowYm;
    $('allPaidTitle').textContent = 'All paid for ' + (ym === nowYm ? 'this month' : monthName(ym));
    /* payment date must fall inside the viewed month (and not in the future) */
    const [y, m] = ym.split('-').map(Number);
    const first = `${ym}-01`, last = dateKey(new Date(y, m, 0));
    const hi = last < todayKey ? last : todayKey;
    $('payDate').min = first; $('payDate').max = hi; $('payDate').value = hi;
  }
  function syncUrl() {
    const a = [];
    if (ym !== nowYm) a.push('month=' + ym);
    if (cat !== 'milk') a.push('cat=' + cat);
    try { history.replaceState(null, '', '/payment' + (a.length ? '?' + a.join('&') : '')); } catch (_) { }
  }
  async function setMonth(k) {
    if (!k || k > nowYm || k === ym) return;
    ym = k; paintMonth(); syncUrl();
    $('payInput').value = ''; $$('#payAmtChips .qty-chip').forEach(x => x.classList.remove('on'));
    await refresh();
  }
  $('pmPrev').onclick = () => setMonth(shiftYm(ym, -1));
  $('pmNext').onclick = () => setMonth(shiftYm(ym, 1));
  $('pmLabel').onclick = e => { if (e.target === $('pmPicker')) return; try { $('pmPicker').showPicker(); } catch (_) { $('pmPicker').focus(); } };
  $('pmPicker').onchange = () => setMonth($('pmPicker').value);
  paintMonth();

  /* ---------- pay-via tiles (drive the hidden method select) ---------- */
  $$('#payVia .pm-tile').forEach(b => b.onclick = () => {
    $('payMethod').value = b.dataset.m;
    $$('#payVia .pm-tile').forEach(x => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-checked', on ? 'true' : 'false'); });
  });
  $('pmQuickPay').onclick = () => {
    setCat('milk'); setStatus('all');
    const c = $('markCard'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (balance() > 0.009) $('payInput').focus({ preventScroll: true });
  };

  /* ---------- category + status filters ---------- */
  function setCat(c) {
    if (!CATS[c]) return;
    cat = c;
    $$('#pmCats .pm-tab').forEach(b => { const on = b.dataset.cat === c; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
    syncUrl(); paintAll();
  }
  function setStatus(v) {
    stf = v;
    $$('#pmStatus .chip-f').forEach(b => b.classList.toggle('on', b.dataset.st === v));
    paintAll();
  }
  $$('#pmCats .pm-tab').forEach(b => b.onclick = () => setCat(b.dataset.cat));
  $$('#pmStatus .chip-f').forEach(b => b.onclick = () => setStatus(b.dataset.st));

  /* ---------- transactions for the selected month + category ---------- */
  /* Every row: { id, date, who, purpose, amount, paid, due, st: paid|partial|unpaid|received, pay } */
  function milkRows() {
    if (!sm) return [];
    const vendor = state.vendor || 'Milk vendor';
    const out = (sm.payments || []).map(p => ({
      id: 'p' + p.id, date: p.date, who: vendor,
      purpose: 'Milk bill payment · ' + (p.method || 'Cash') + (p.note ? ' · ' + p.note : ''),
      amount: Number(p.amount) || 0, paid: Number(p.amount) || 0, due: 0, st: 'paid'
    }));
    const bal = balance();
    if (bal > 0.009) {
      const lastDel = (sm.days || []).filter(d => d.status === 'delivered').map(d => d.date).sort().pop();
      const [y, m] = ym.split('-').map(Number);
      const monthEnd = dateKey(new Date(y, m, 0));
      out.push({
        id: 'due', date: lastDel || (monthEnd < todayKey ? monthEnd : todayKey), who: vendor,
        purpose: 'Milk bill balance · ' + litres(sm.ml) + ' delivered',
        amount: bal, paid: 0, due: bal, st: 'unpaid'
      });
    }
    return out;
  }
  function ledgerRows(type) {
    return exItems.filter(it => it.type === type).map(it => {
      const amount = Number(it.amount) || 0;
      const isCr = type === 'credit';
      return {
        id: it.id, date: it.date, who: it.vendor || it.category || 'Entry',
        purpose: it.description || it.category || it.note || '—',
        amount, paid: isCr ? amount : (Number(it.paid) || 0), due: isCr ? 0 : (Number(it.due) || 0),
        st: isCr ? 'received' : it.status, pay: !isCr && Number(it.due) > 0.009
      };
    });
  }
  const catRows = () => (cat === 'milk' ? milkRows() : ledgerRows(cat))
    .sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id)));
  /* paid = fully settled (or received); due = anything with a balance left */
  const matches = r => stf === 'all' || (stf === 'paid' ? r.due <= 0.009 : r.due > 0.009);

  const CHIP = { paid: ['paid', 'Paid'], received: ['received', 'Received'], partial: ['partial', 'Part paid'], unpaid: ['unpaid', 'Due'] };
  function paintList(rows) {
    const c = CATS[cat], mn = monthName(ym);
    $('payListTitle').textContent = c.label + ' · ' + mn;
    $('khCount').textContent = rows.length;
    if (!rows.length) {
      const t = stf === 'all' ? c.empty : (stf === 'paid' ? 'No paid ' : 'Nothing due in ') + c.label.toLowerCase();
      $('payList').innerHTML = emptyState('ill-wallet', t, 'Nothing to show for ' + mn + (stf === 'all' ? '' : ' with this filter') + '.', true);
      return;
    }
    $('payList').innerHTML = rows.map(r => {
      const ch = CHIP[r.st] || CHIP.unpaid;
      const ava = r.st === 'received' ? 'in' : r.st === 'partial' ? 'part' : r.due > 0.009 ? 'no' : 'ok';
      return '<div class="rc-row pm-tx"><span class="rc-ava ' + ava + '">' + esc(String(r.who || '?')[0].toUpperCase()) + '</span>' +
        '<span class="rc-main"><b>' + esc(r.who) + '</b><small>' + esc(r.purpose) + '</small><small>' + esc(shortDay(r.date)) + '</small></span>' +
        '<span class="rc-end"><b>' + inr(r.amount) + '</b>' +
        (r.st === 'partial' ? '<small class="pm-left">' + inr(r.due) + ' left</small>' : '') +
        '<span class="tx-chip ' + ch[0] + '">' + ch[1] + '</span>' +
        (r.pay ? '<button class="btn sm" type="button" data-kpay="' + esc(r.id) + '" style="margin-top:6px;padding:5px 14px;min-height:0">Pay</button>' : '') +
        '</span></div>';
    }).join('');
    $('payList').querySelectorAll('[data-kpay]').forEach(b => b.onclick = () => openKhPay(b.dataset.kpay));
  }

  /* ---------- hero: Total / Paid / Due follow the filters ---------- */
  function paintTop(rows) {
    const t = rows.reduce((a, r) => ({ total: a.total + r.amount, paid: a.paid + r.paid, due: a.due + r.due }), { total: 0, paid: 0, due: 0 });
    const cr = cat === 'credit';
    $('payBalLabel').textContent = cr ? 'Credit pending' : CATS[cat].label + ' due';
    $('payBalAmt').textContent = inr(Math.max(0, t.due));
    $('payBill').textContent = ' ' + inr(t.total);
    $('payPaidLbl').firstChild.nodeValue = cr ? 'Received' : 'Paid';
    $('payPaid').textContent = ' ' + inr(t.paid);
  }

  function paintAll() {
    if (!sm) return;
    const rows = catRows().filter(matches);
    paintTop(rows); paintList(rows);
    /* the milk payment form only belongs to the Milk category */
    $('markCard').hidden = cat !== 'milk';
    paintForm();
  }

  /* ---------- milk: paid / not paid form ---------- */
  function setPaid(v) {
    paid = v;
    $('choicePaid').classList.toggle('on', v);
    $('choiceNotPaid').classList.toggle('on', !v);
    paintForm();
  }
  $('choicePaid').onclick = () => setPaid(true);
  $('choiceNotPaid').onclick = () => setPaid(false);

  function paintForm() {
    paintPay(sm, 'pay');
    const bal = balance(), none = bal <= 0.009;
    $('allPaidBox').hidden = !none;
    $('paidForm').hidden = none || !paid;
    $('notPaidBox').hidden = none || paid;
    $('choicePaid').parentElement.hidden = none;
    $('npText').textContent = 'Balance of ' + inr(bal) + ' stays unpaid.';
    $('chipFull').textContent = 'Full ' + inr(bal);
    previewAmt(); paintBar();
  }
  function previewAmt() { $('payAmtPreview').textContent = inr(Number($('payInput').value) || 0); paintBar(); }
  /* fixed bottom bar: shows what will be submitted; only on the Milk category and when something is left to pay */
  function paintBar() {
    const bar = $('payBar'); if (!bar || !sm) return;
    const none = balance() <= 0.009;
    bar.hidden = cat !== 'milk' || none;
    if (paid) {
      $('payBarLabel').textContent = 'Paying now';
      $('payBarAmt').textContent = inr(Number($('payInput').value) || 0);
      $('paySubmitLbl').textContent = 'Submit payment';
    } else {
      $('payBarLabel').textContent = 'Still to pay';
      $('payBarAmt').textContent = inr(balance());
      $('paySubmitLbl').textContent = 'Keep as unpaid';
    }
  }
  $('payInput').addEventListener('input', () => {
    previewAmt(); $$('#payAmtChips .qty-chip').forEach(c => c.classList.remove('on'));
  });
  $$('#payAmtChips .qty-chip').forEach(c => c.onclick = () => {
    $$('#payAmtChips .qty-chip').forEach(x => x.classList.toggle('on', x === c));
    const pct = Number(c.dataset.pct);
    if (pct > 0) $('payInput').value = Math.round(balance() * pct) / 100 || '';
    else { $('payInput').value = ''; $('payInput').focus(); }
    previewAmt();
  });

  $('paySubmit').onclick = async () => {
    if (!paid) return notify('Kept as unpaid · balance ' + inr(balance()));
    const amount = Number($('payInput').value);
    if (!amount || amount <= 0) return notify('Enter the amount you paid.');
    if (amount > balance() + 0.009) return notify('Amount is more than the balance (' + inr(balance()) + ').');
    const j = await act('POST', '/api/payment', {
      month: ym, amount, date: $('payDate').value || todayKey,
      method: $('payMethod').value, note: $('payNote').value.trim()
    }, 'Payment saved — marked as paid');
    if (j) { $('payInput').value = ''; $('payNote').value = ''; $$('#payAmtChips .qty-chip').forEach(x => x.classList.remove('on')); await refresh(); }
  };

  /* ---------- ledger entry: record a payment against a due entry ---------- */
  function setKpPaid(v) {
    kpIsPaid = v;
    $('kpPaid').classList.toggle('on', v); $('kpNot').classList.toggle('on', !v);
    $('kpForm').hidden = !v; $('kpNotBox').hidden = v;
    $('kpSubmit').innerHTML = v ? '<svg class="ic sm"><use href="#i-check"/></svg>Submit payment' : 'Keep as unpaid';
  }
  $('kpPaid').onclick = () => setKpPaid(true);
  $('kpNot').onclick = () => setKpPaid(false);
  function openKhPay(id) {
    kpEntry = exItems.find(x => String(x.id) === String(id)); if (!kpEntry) return;
    $('kpWho').textContent = (kpEntry.vendor || kpEntry.description || kpEntry.category) + ' · ' + shortDay(kpEntry.date);
    $('kpDue').textContent = inr(kpEntry.due);
    $('kpAmount').value = kpEntry.due; $('kpNote').value = '';
    setKpPaid(true); openOv($('sheetKhPay'));
  }
  $('kpSubmit').onclick = async () => {
    if (!kpEntry) return;
    if (!kpIsPaid) { closeOv($('sheetKhPay')); return notify('Kept as unpaid'); }
    const amount = Number($('kpAmount').value);
    if (!amount || amount <= 0) return notify('Enter the amount you paid.');
    if (amount > kpEntry.due + 0.009) return notify('Amount is more than the due (' + inr(kpEntry.due) + ').');
    const j = await act('POST', '/api/expense/' + encodeURIComponent(kpEntry.id) + '/payment', {
      amount, date: $('kpDate').value || todayKey, method: $('kpMethod').value, note: $('kpNote').value.trim()
    }, 'Payment saved');
    if (j) { closeOv($('sheetKhPay')); await refresh(); }
  };

  async function refresh() {
    /* load milk and ledger separately so one failing call never blanks the whole page */
    const [s, x] = await Promise.all([
      getSummary(ym).catch(() => null),
      api('/api/expenses?month=' + ym).catch(() => null)
    ]);
    sm = s; exItems = x ? (x.items || []) : [];
    if (!sm) { notify('Could not load payments. Pull to refresh.'); return; }
    paintAll();
  }
  setCat(cat);
  await refresh();
});

/* ============================================================
   PAGE: PROFILE
   ============================================================ */
pages.profile = () => start(async () => {
  await load();
  let rate = currentPrice();

  const paint = () => {
    const nm = state.name || 'User';
    setAvatar($('pfAvatar'), nm);
    $('pfName').textContent = nm;
    $('pfRowPhone').textContent = state.phone || 'Photo, name, phone & address';
    $('pfRowPrice').textContent = CUR + rate + ' / L';
    $('priceCurrent').textContent = CUR + rate + ' / L';
    if (!$('setName').value) $('setName').value = state.name || '';
    if (!$('setPhone').value) $('setPhone').value = state.phone || '';
    if (!$('setVendor').value) $('setVendor').value = state.vendor || '';
    if (!$('setAddress').value) $('setAddress').value = state.address || '';
    if (!$('setQty').value) $('setQty').value = state.quantity || 500;
  };

  /* --- profile photo: pick → auto-crop to a square data URL → saved with the profile --- */
  let pendingPhoto = null;   // null = unchanged, '' = removed, data-url = new photo
  const paintPhotoUI = () => {
    setAvatar($('pfPickAvatar'), state.name, pendingPhoto !== null ? pendingPhoto : state.photo);
    $('pfPhotoRemove').hidden = !(state.photo || pendingPhoto);
  };
  const openProfileSheet = () => { pendingPhoto = null; paintPhotoUI(); openOv($('sheetProfile')); };
  $('pfPhotoBtn').onclick = () => $('pfPhotoInput').click();
  $('pfPhotoInput').onchange = () => {
    const f = $('pfPhotoInput').files && $('pfPhotoInput').files[0];
    $('pfPhotoInput').value = '';
    if (!f) return;
    if (!/^image\//.test(f.type || '')) return notify('Please choose an image file.');
    resizeToDataUrl(f, 256, url => { pendingPhoto = url; paintPhotoUI(); notify('Photo ready — press Save profile.'); });
  };
  $('pfPhotoRemove').onclick = () => { pendingPhoto = ''; paintPhotoUI(); };

  $('pfEditBtn').onclick = openProfileSheet;
  $('rowAccount').onclick = openProfileSheet;
  $('rowPrice').onclick = () => { renderPriceHistory(); openOv($('sheetPrice')); };

  $('saveProfileBtn').onclick = async () => {
    const body = {
      name: $('setName').value.trim(),
      phone: $('setPhone').value.trim(),
      vendor: $('setVendor').value.trim(),
      address: $('setAddress').value.trim(),
      quantity: $('setQty').value || 500
    };
    if (pendingPhoto !== null) body.photo = pendingPhoto;
    const j = await act('PUT', '/api/profile', body, 'Profile saved');
    if (j) { pendingPhoto = null; closeOv($('sheetProfile')); paint(); paintPhotoUI(); }
  };

  $('savePriceBtn').onclick = async () => {
    const v = Number($('setPrice').value);
    if (!v || v <= 0) return notify('Enter a valid price per litre.');
    const frm = $('setFrom').value || todayKey;
    const j = await act('PUT', '/api/price', { price: v, from: frm }, 'Milk price updated');
    if (j) {
      $('setPrice').value = '';
      if (frm <= todayKey) rate = v;
      paint(); renderPriceHistory();
    }
  };

  function renderPriceHistory() {
    const list = [...(state.prices || [])].sort((a, b) => b.from.localeCompare(a.from));
    $('priceHistory').innerHTML = list.length ? list.map(p => `
      <div class="pay-item">
        <span class="stat-ico amber">${ic('tag')}</span>
        <div class="pi-main">
          <div style="font-weight:700;font-size:13.5px">${CUR}${p.price} / L</div>
          <div style="font-size:11.5px;color:var(--faint)">from ${shortDay(p.from)}</div>
        </div>
        ${list.length > 1 ? `<button class="icon-btn plain danger" data-pdel="${esc(p.from)}" aria-label="Delete price">${ic('trash', 'sm')}</button>` : ''}
      </div>`).join('') : emptyState('ill-tag', 'No price changes yet', 'When you update the milk rate, its history appears here.');
    $('priceHistory').querySelectorAll('[data-pdel]').forEach(b => b.onclick = async () => {
      if (!(await confirmBox('Delete price entry?', 'Deliveries on those dates will fall back to the previous rate.', 'Delete'))) return;
      const j = await act('DELETE', '/api/price/' + b.dataset.pdel, null, 'Price removed');
      if (j) { rate = currentPrice(); paint(); renderPriceHistory(); }
    });
  }

  paint();
  paintPhotoUI();
  /* settings rows (preferences, ledger, backup, help, logout) live on this same page now */
  await settingsBody();
});

/* ============================================================
   PAGE: SETTINGS
   ============================================================ */
const settingsBody = async () => {
  await load();
  getSummary(monthNow()).then(sm => {
    const el = $('stPayTxt'), st = payStatus(sm);
    if (el) el.textContent = st.cls === 'none' ? 'Payments' : (st.cls === 'ok' ? 'Paid' : inr(Math.max(0, sm.balance)) + ' due');
  }).catch(() => { });

  /* --- preferences --- */
  const tglNotif = $('tglNotif');
  try { tglNotif.checked = localStorage.getItem('mm_notif') !== '0'; } catch (_) { }
  tglNotif.onchange = () => {
    try { localStorage.setItem('mm_notif', tglNotif.checked ? '1' : '0'); } catch (_) { }
    notify(tglNotif.checked ? 'Notifications on' : 'Notifications off');
  };

  /* --- language --- */
  const LANGS = [['English', 'English'], ['हिन्दी', 'Hindi'], ['తెలుగు', 'Telugu']];
  let lang = 'English';
  try { lang = localStorage.getItem('mm_lang') || 'English'; } catch (_) { }
  $('langValue').textContent = lang;
  function renderLangs() {
    $('langList').innerHTML = LANGS.map(([label, key]) => `
      <button class="list-row" type="button" data-lang="${key}" style="border-radius:14px">
        <span class="lr-ico" style="background:var(--teal-soft);color:var(--teal)">${ic('globe')}</span>
        <span class="lr-main"><span class="lr-title">${label}</span></span>
        ${lang === key ? `<span class="lr-end" style="color:var(--green-deep)">${ic('check')}</span>` : ''}
      </button>`).join('');
    $('langList').querySelectorAll('[data-lang]').forEach(b => b.onclick = () => {
      lang = b.dataset.lang;
      try { localStorage.setItem('mm_lang', lang); } catch (_) { }
      $('langValue').textContent = lang;
      renderLangs();
      notify(lang === 'English' ? 'Language: English' : 'Preference saved — more translations coming soon.');
    });
  }
  $('rowLang').onclick = () => { renderLangs(); openOv($('sheetLang')); };

  /* --- categories --- */
  $('catCount').textContent = (state.expense_categories || []).length + ' saved';
  function renderCats() {
    const cats = state.expense_categories || [];
    $('catList').innerHTML = cats.length ? cats.map(c => {
      const protectedCat = (window.APP.protected_categories || ['Other']).some(p => p.toLowerCase() === String(c).toLowerCase());
      const meta = catMeta(c);
      const [bg, fg] = COLOR_VARS[meta.color];
      return `<div class="pay-item">
        <span class="stat-ico" style="background:${bg};color:${fg}">${ic(meta.icon)}</span>
        <div class="pi-main"><div style="font-weight:700;font-size:13.5px">${esc(c)}</div>
        ${protectedCat ? '<div style="font-size:11px;color:var(--faint)">Built-in</div>' : ''}</div>
        ${protectedCat ? '' : `<button class="icon-btn plain" data-cren="${esc(c)}" aria-label="Rename">${ic('edit', 'sm')}</button>
        <button class="icon-btn plain danger" data-cdel="${esc(c)}" aria-label="Delete">${ic('trash', 'sm')}</button>`}
      </div>`;
    }).join('') : emptyState('ill-box', 'No categories yet', 'Tap <b>Add category</b> to create your first one.');
    $('catCount').textContent = cats.length + ' saved';
    $('catList').querySelectorAll('[data-cdel]').forEach(b => b.onclick = async () => {
      if (!(await confirmBox('Delete category?', '"' + b.dataset.cdel + '" will be removed from your list.', 'Delete'))) return;
      const j = await act('DELETE', '/api/expense-categories/' + encodeURIComponent(b.dataset.cdel), null, 'Category removed');
      if (j) renderCats();
    });
    $('catList').querySelectorAll('[data-cren]').forEach(b => b.onclick = async () => {
      const nv = prompt('Rename category', b.dataset.cren);
      if (!nv || nv.trim().length < 2 || nv.trim() === b.dataset.cren) return;
      const j = await act('POST', '/api/expense-categories/rename', { old: b.dataset.cren, new: nv.trim() }, 'Category renamed');
      if (j) renderCats();
    });
  }
  $('rowCats').onclick = () => { renderCats(); openOv($('sheetCats')); };
  $('catSaveBtn').onclick = async () => {
    const name = $('catName').value.trim();
    if (name.length < 2) return notify('Category name must be at least 2 characters.');
    const j = await act('POST', '/api/expense-categories', { name }, 'Category added');
    if (j) { $('catName').value = ''; renderCats(); }
  };
  $('catName').addEventListener('keydown', e => { if (e.key === 'Enter') $('catSaveBtn').click(); });

  /* --- vendors --- */
  $('vendorCount').textContent = (state.vendors || []).length + ' saved';
  api('/api/expenses').then(x => {
    const hasVendor = (x.items || []).some(it => it.vendor);
    if (hasVendor) {
      const dues = (x.items || []).reduce((a, it) => a + (it.type === 'credit' ? 0 : Number(it.due || 0)), 0);
      $('vendorCount').textContent = dues > 0 ? inr(dues) + ' udhar pending' : 'all settled';
    }
  }).catch(() => { });
  function renderVendors(items) {
    const stats = {};
    (items || []).forEach(x => {
      if (x.type === 'credit' || !x.vendor) return;
      const v = stats[x.vendor] = stats[x.vendor] || { total: 0, due: 0 };
      v.total += Number(x.amount || 0);
      v.due += Number(x.due || 0);
    });
    const saved = state.vendors || [];
    const all = [...new Set([...saved, ...Object.keys(stats)])];
    $('vendorList').innerHTML = all.length ? all.map(v => {
      const s = stats[v] || { total: 0, due: 0 };
      const due = Math.round(s.due * 100) / 100;
      return `<div class="pay-item">
        <span class="stat-ico teal">${ic('store')}</span>
        <div class="pi-main">
          <div style="font-weight:700;font-size:13.5px">${esc(v)}</div>
          <div style="font-size:11.5px;color:var(--faint)">${inr(s.total)} lifetime ${due > 0 ? ' · <b style="color:var(--red)">' + inr(due) + ' due</b>' : ' · settled'}</div>
        </div>
        ${due > 0.009 ? `<button class="btn sm soft" data-vsettle="${esc(v)}" data-due="${due}">Settle</button>` : ''}
        <button class="icon-btn plain" data-vren="${esc(v)}" aria-label="Rename vendor">${ic('edit', 'sm')}</button>
        ${saved.some(x => x.toLowerCase() === v.toLowerCase()) ? `<button class="icon-btn plain danger" data-vdel="${esc(v)}" aria-label="Remove vendor">${ic('trash', 'sm')}</button>` : ''}
      </div>`;
    }).join('') : emptyState('ill-box', 'No vendors yet', 'They are saved automatically from your entries.');
    const totalDue = Object.values(stats).reduce((a, s) => a + s.due, 0);
    $('vendorDueTotal').textContent = inr(totalDue);
    $('vendorCount').textContent = all.length + ' vendors · ' + (totalDue > 0 ? inr(totalDue) + ' due' : 'all settled');
    $('vendorList').querySelectorAll('[data-vsettle]').forEach(b => b.onclick = () => openVendorSettle(b.dataset.vsettle, Number(b.dataset.due)));
    $('vendorList').querySelectorAll('[data-vren]').forEach(b => b.onclick = async () => {
      const nv = prompt('Rename vendor', b.dataset.vren);
      if (!nv || nv.trim().length < 2 || nv.trim() === b.dataset.vren) return;
      const j = await act('POST', '/api/vendors/rename', { old: b.dataset.vren, new: nv.trim() }, 'Vendor renamed');
      if (j) {
        api('/api/expenses').then(x => renderVendors(x.items || [])).catch(() => { });
      }
    });
    $('vendorList').querySelectorAll('[data-vdel]').forEach(b => b.onclick = async () => {
      if (!(await confirmBox('Remove vendor?', '"' + b.dataset.vdel + '" will be removed from your saved list.', 'Remove'))) return;
      const j = await act('POST', '/api/vendors/delete', { name: b.dataset.vdel }, 'Vendor removed');
      if (j) renderVendors(items);
    });
  }
  $('rowVendors').onclick = () => {
    api('/api/expenses').then(x => { renderVendors(x.items || []); }).catch(() => renderVendors([]));
    openOv($('sheetVendors'));
  };
  $('vendorSaveBtn').onclick = async () => {
    const name = $('vendorName').value.trim();
    if (name.length < 2) return notify('Vendor name must be at least 2 characters.');
    const j = await act('POST', '/api/vendors', { name }, 'Vendor saved');
    if (j) {
      $('vendorName').value = '';
      api('/api/expenses').then(x => renderVendors(x.items || [])).catch(() => { });
    }
  };
  $('vendorName').addEventListener('keydown', e => { if (e.key === 'Enter') $('vendorSaveBtn').click(); });

  /* --- data / backup --- */
  $('syncEmail').textContent = state.email || '—';
  $('syncRecords').textContent = Object.keys(state.records || {}).length;
  $('syncEntries').textContent = (state.expenses || []).length;
  $('rowBackup').onclick = () => openOv($('sheetData'));
  $('resetBtn').onclick = async () => {
    if (!(await confirmBox('Reset all data?', 'Every delivery record, payment and khata entry will be wiped. This cannot be undone.', 'Reset everything'))) return;
    const j = await act('POST', '/api/reset', null, 'All data has been reset');
    if (j) {
      $('syncRecords').textContent = Object.keys(state.records || {}).length;
      $('syncEntries').textContent = (state.expenses || []).length;
      closeOv($('sheetData'));
    }
  };

  { const sc = $('shopCount'), left = (state.shopping || []).filter(x => !x.done).length;
    if (sc) sc.textContent = left ? left + ' item' + (left > 1 ? 's' : '') + ' to buy' : 'Things to buy'; }

  $('rowHelp').onclick = () => openOv($('sheetHelp'));
  $('rowTerms').onclick = () => openOv($('sheetTerms'));

  $('logoutBtn').onclick = async () => {
    if (!(await confirmBox('Log out?', 'You can sign back in anytime.', 'Logout'))) return;
    window.location.href = '/logout';
  };
};
pages.settings = () => start(settingsBody);

/* ============================================================
   NOTIFICATIONS — worked out from your own data (no extra storage):
   deliveries not marked, unpaid milk bill, KhataBook dues, shopping list.
   "Read" and "dismissed" are remembered on this device.
   ============================================================ */
const NF_READ = 'mm_nf_read', NF_HIDE = 'mm_nf_hide';
const nfGet = k => { try { const v = JSON.parse(localStorage.getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch (_) { return []; } };
const nfSet = (k, a) => { try { localStorage.setItem(k, JSON.stringify(a.slice(-300))); } catch (_) { } };
const daysFromToday = k => Math.round((parseKey(k) - today) / 86400000);

async function buildNotifs() {
  const list = [];
  const ym = monthNow();
  const pm = monthKey(new Date(today.getFullYear(), today.getMonth() - 1, 1));
  const [cur, prev, ex] = await Promise.all([
    getSummary(ym).catch(() => null),
    getSummary(pm).catch(() => null),
    api('/api/expenses').catch(() => null)
  ]);

  /* 1 · deliveries not marked */
  const todayUnmarked = !(state.records || {})[todayKey];
  if (todayUnmarked) list.push({ id: 'today-' + todayKey, level: 1, icon: 'milk', color: 'blue', href: '/',
    title: "Today's milk isn't marked yet", body: 'Tell the app whether the milk came today.', when: 'Today' });
  if (cur) {
    const missed = Math.max(0, (cur.pending || 0) - (todayUnmarked ? 1 : 0));
    if (missed > 0) list.push({ id: 'missed-' + ym + '-' + missed, level: 1, icon: 'cal', color: 'amber', href: '/calendar',
      title: missed + ' earlier day' + (missed > 1 ? 's' : '') + ' not marked', body: 'Fill them in so your ' + monthName(ym) + ' bill is correct.', when: 'This month' });
  }

  /* 2 · milk bill */
  if (prev && prev.amount > 0 && prev.balance > 0.009) list.push({ id: 'pay-' + pm + '-' + prev.balance, level: 0, icon: 'wallet', color: 'red', href: '/payment',
    title: monthName(pm) + ' milk bill is unpaid', body: inr(prev.balance) + ' is still left to pay.', when: 'Overdue' });
  if (cur && cur.amount > 0 && cur.balance > 0.009) {
    const left = (cur.total_days || 30) - today.getDate();
    if (left <= 3) list.push({ id: 'paycur-' + ym + '-' + cur.balance, level: 1, icon: 'receipt', color: 'amber', href: '/bill',
      title: left === 0 ? 'Last day of the month' : 'Month ends in ' + left + ' day' + (left > 1 ? 's' : ''),
      body: inr(cur.balance) + ' of your milk bill is left to pay.', when: 'Milk bill' });
  }

  /* 3 · KhataBook dues */
  if (ex && Array.isArray(ex.items)) {
    let undated = 0, undatedN = 0, dated = 0;
    ex.items.forEach(it => {
      if (it.type === 'credit' || !(it.due > 0.009)) return;
      const who = it.vendor || it.description || it.category || 'Entry';
      if (it.due_date) {
        const d = daysFromToday(it.due_date);
        if (d > 3 || dated >= 6) return;
        dated++;
        list.push({ id: 'khata-' + it.id + '-' + it.due, level: d < 0 ? 0 : 1, icon: 'book', color: d < 0 ? 'red' : 'pink', href: '/khata',
          title: d < 0 ? 'Overdue: ' + who : d === 0 ? 'Due today: ' + who : 'Due in ' + d + ' day' + (d > 1 ? 's' : '') + ': ' + who,
          body: inr(it.due) + (d < 0 ? ' was due ' : ' is due ') + shortDay(it.due_date) + '.', when: d < 0 ? 'Overdue' : 'KhataBook' });
      } else { undated += it.due; undatedN++; }
    });
    if (undatedN) list.push({ id: 'udhar-' + Math.round(undated) + '-' + undatedN, level: 2, icon: 'store', color: 'purple', href: '/khata',
      title: 'Udhar pending: ' + inr(undated), body: 'Across ' + undatedN + ' unpaid KhataBook entr' + (undatedN > 1 ? 'ies' : 'y') + '.', when: 'KhataBook' });
  }

  /* 4 · shopping list */
  const todo = (state.shopping || []).filter(x => !x.done);
  if (todo.length) {
    const names = todo.slice(0, 3).map(x => x.name).join(', ') + (todo.length > 3 ? ' +' + (todo.length - 3) + ' more' : '');
    const est = todo.reduce((a, x) => a + Number(x.price || 0), 0);
    list.push({ id: 'shop-' + todo.length + '-' + todo[todo.length - 1].id, level: 2, icon: 'cart', color: 'green', href: '/shopping',
      title: todo.length + ' item' + (todo.length > 1 ? 's' : '') + ' on your shopping list',
      body: names + (est > 0 ? ' · about ' + inr(est) : ''), when: 'Shopping' });
  }

  const read = new Set(nfGet(NF_READ)), hide = new Set(nfGet(NF_HIDE));
  return list.filter(n => !hide.has(n.id)).map(n => Object.assign(n, { read: read.has(n.id) })).sort((a, b) => a.level - b.level);
}

pages.notifications = () => start(async () => {
  await load();
  let items = [], filter = 'all';
  $('nfMuted').hidden = notifOn();

  const render = () => {
    const unread = items.filter(n => !n.read).length;
    $('nfSub').textContent = unread ? unread + ' new alert' + (unread > 1 ? 's' : '') : 'All caught up';
    $('nfAllN').textContent = items.length;
    $('nfUnreadN').textContent = unread;
    $('nfReadAll').hidden = !unread;
    const show = filter === 'unread' ? items.filter(n => !n.read) : items;
    if (!show.length) {
      $('nfList').innerHTML = emptyState('ill-bell', filter === 'unread' ? 'Nothing unread' : "You're all caught up",
        filter === 'unread' ? 'Every alert has been read.' : 'Reminders about deliveries, bills and your shopping list will show up here.');
      return;
    }
    const row = n => {
      const [bg, fg] = COLOR_VARS[n.color] || COLOR_VARS.green;
      return `<a class="nf-item ${n.read ? '' : 'unread'}" href="${n.href}" data-id="${esc(n.id)}">
        <span class="nf-ico" style="background:${bg};color:${fg}">${ic(n.icon, '')}</span>
        <span class="nf-main">
          <span class="nf-title">${esc(n.title)}${n.read ? '' : '<i class="nf-dot" aria-label="Unread"></i>'}</span>
          <span class="nf-body">${esc(n.body)}</span>
          <span class="nf-when">${esc(n.when)}</span>
        </span>
        <button class="icon-btn plain nf-x" type="button" data-dismiss="${esc(n.id)}" aria-label="Dismiss">${ic('x')}</button>
      </a>`;
    };
    const fresh = show.filter(n => !n.read), old = show.filter(n => n.read);
    $('nfList').innerHTML =
      (fresh.length ? `<div class="group-label">New</div><div class="nf-stack anim-in">${fresh.map(row).join('')}</div>` : '') +
      (old.length ? `<div class="group-label">Earlier</div><div class="nf-stack anim-in">${old.map(row).join('')}</div>` : '');
  };

  $('nfList').addEventListener('click', e => {
    const x = e.target.closest('[data-dismiss]');
    if (x) {
      e.preventDefault(); e.stopPropagation();
      nfSet(NF_HIDE, [...nfGet(NF_HIDE), x.dataset.dismiss]);
      items = items.filter(n => n.id !== x.dataset.dismiss);
      return render();
    }
    const a = e.target.closest('.nf-item');
    if (a) nfSet(NF_READ, [...nfGet(NF_READ), a.dataset.id]);
  });
  $('nfReadAll').onclick = () => {
    nfSet(NF_READ, [...nfGet(NF_READ), ...items.map(n => n.id)]);
    items.forEach(n => { n.read = true; });
    render();
  };
  $$('[data-nf]').forEach(b => b.onclick = () => {
    filter = b.dataset.nf;
    $$('[data-nf]').forEach(t => { t.classList.toggle('on', t === b); t.setAttribute('aria-selected', t === b ? 'true' : 'false'); });
    render();
  });

  try { items = await buildNotifs(); } catch (_) { items = []; }
  render();
});

/* ============================================================
   PAGE: SHOPPING LIST — what to buy before going to the shop
   ============================================================ */
pages.shopping = () => start(async () => {
  await load();
  const SUGGEST = ['Rice', 'Atta', 'Sugar', 'Salt', 'Dal', 'Cooking oil'];
  let editId = null, view = 'add', seq = 0;
  const newDraft = (name) => ({ k: 'd' + (++seq), name: name || '', qty: '', price: '' });
  let drafts = [newDraft()];
  const all = () => state.shopping || [];
  const sub = x => [x.qty, Number(x.price) > 0 ? '≈ ' + inr(x.price) : ''].filter(Boolean).join(' · ');
  const filled = () => drafts.filter(d => d.name.trim());

  /* ---------- Add view: one card per item ---------- */
  const draftRow = (d, i) => `<div class="sh-line ${drafts.length > 1 ? 'has-rm' : ''}" data-k="${d.k}">
      <textarea class="input sh-name" data-f="name" rows="1" maxlength="60" autocomplete="off" placeholder="Item to buy" aria-label="Item ${i + 1} name">${esc(d.name)}</textarea>
      <input class="input sh-sm" data-f="qty" maxlength="20" autocomplete="off" placeholder="Qty" aria-label="Quantity" value="${esc(d.qty)}">
      <input class="input sh-sm" data-f="price" type="number" min="0" step="0.5" inputmode="decimal" placeholder="₹ Price" aria-label="Estimated price (optional)" value="${esc(d.price)}">
      ${drafts.length > 1 ? `<button class="icon-btn plain danger sh-rm" type="button" data-rm="${d.k}" aria-label="Remove item ${i + 1}">${ic('trash', 'sm')}</button>` : ''}
    </div>`;

  /* the name box grows downward as the name gets longer */
  const fit = el => { el.style.height = 'auto'; el.style.height = (el.scrollHeight + 2) + 'px'; };

  function paintDrafts(focusKey) {
    /* one card: every item as a single line, and ONE "Add more" button after the last item */
    $('shDrafts').innerHTML = '<div class="sh-draft">' + drafts.map(draftRow).join('') +
      '<button class="sh-more" type="button" data-more="1">' + ic('plus', 'sm') + 'Add more</button></div>';
    $$('.sh-name').forEach(fit);
    if (focusKey) {
      const el = document.querySelector('.sh-line[data-k="' + focusKey + '"] [data-f="name"]');
      if (el) { el.focus({ preventScroll: true }); el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    }
    paintBar(); paintChips();
  }

  function paintBar() {
    const f = filled(), est = f.reduce((a, d) => a + Number(d.price || 0), 0);
    $('shBarCount').textContent = f.length + (f.length === 1 ? ' item' : ' items');
    $('shBarLabel').textContent = 'Added so far' + (est > 0 ? ' · ≈ ' + inr(est) : '');
  }

  function paintChips() {
    const have = new Set([...all().filter(x => !x.done).map(x => x.name.toLowerCase()), ...filled().map(d => d.name.trim().toLowerCase())]);
    const left = SUGGEST.filter(s => !have.has(s.toLowerCase()));
    $('shChips').innerHTML = left.map(s => `<button class="chip-f" type="button" data-chip="${esc(s)}">${ic('plus')}${esc(s)}</button>`).join('')
      || '<span class="hint">All quick-add items are on your list.</span>';
  }

  /* ---------- List view: ledger-style history ---------- */
  let flt = 'all';
  const dayKey = x => x.added || todayKey;
  const yKey = dateKey(new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1));
  function dayName(k) {
    if (k === todayKey) return 'Today';
    if (k === yKey) return 'Yesterday';
    const d = new Date(k + 'T00:00:00');
    return d.toLocaleDateString('en-IN', d.getFullYear() === today.getFullYear() ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' });
  }
  const row = x => {
    const [bg, fg] = x.done ? ['var(--ok-soft)', 'var(--ok)'] : ['var(--green-soft)', 'var(--green-deep)'];
    return `<div class="tx-row sh-tx ${x.done ? 'done' : ''}" data-edit="${esc(x.id)}">
      <button class="tx-ico sh-ico" type="button" data-tog="${esc(x.id)}" style="background:${bg};color:${fg}" aria-pressed="${x.done ? 'true' : 'false'}" aria-label="${x.done ? 'Mark as not bought' : 'Mark as bought'}">${ic(x.done ? 'check' : 'cart')}</button>
      <div class="tx-main"><div class="tx-title">${esc(x.name)}</div><div class="tx-sub">${esc(x.qty || 'No quantity')}</div></div>
      <span class="tx-amt-wrap"><span class="tx-amt">${Number(x.price) > 0 ? inr(x.price) : '—'}</span><small class="tx-st ${x.done ? 'ok' : 'due'}">${x.done ? 'Bought' : 'To buy'}</small></span>
    </div>`;
  };

  function paintList() {
    const todo = all().filter(x => !x.done), done = all().filter(x => x.done);
    const est = todo.reduce((a, x) => a + Number(x.price || 0), 0);
    $('shSumCol').hidden = !all().length;
    $('shLeft').textContent = todo.length;
    $('shBought').textContent = done.length;
    $('shEst').textContent = est > 0 ? inr(est) : '—';
    $$('[data-shf]').forEach(c => {
      const n = c.dataset.shf === 'all' ? all().length : c.dataset.shf === 'todo' ? todo.length : done.length;
      c.textContent = ({ all: 'All', todo: 'To buy', done: 'Bought' })[c.dataset.shf] + (all().length ? ' · ' + n : '');
      c.classList.toggle('on', c.dataset.shf === flt);
    });
    const list = (flt === 'todo' ? todo : flt === 'done' ? done : all()).slice().reverse();
    $('shListChip').textContent = list.length;
    $('shClear').hidden = !done.length;
    if (!list.length) {
      $('shHist').innerHTML = emptyState('ill-cart',
        !all().length ? 'Your list is empty' : flt === 'done' ? 'Nothing bought yet' : 'Everything is bought 🎉',
        !all().length ? 'Items you add will show up here.' : flt === 'done' ? 'Tick items as you buy them.' : 'Clear the bought items or add more.') +
        (flt === 'done' && all().length ? '' : '<div class="empty-cta"><button class="btn sm" type="button" data-goadd="1">' + ic('plus', 'sm') + 'Add items</button></div>');
      return;
    }
    const groups = [];
    list.forEach(x => {
      const k = dayKey(x); let g = groups[groups.length - 1];
      if (!g || g.k !== k) { g = { k, rows: [] }; groups.push(g); }
      g.rows.push(x);
    });
    $('shHist').innerHTML = groups.map(g => {
      const t = g.rows.reduce((a, x) => a + (x.done ? 0 : Number(x.price || 0)), 0);
      return '<div class="day-head"><span>' + esc(dayName(g.k)) + '</span>' + (t > 0 ? '<b>≈ ' + inr(t) + '</b>' : '') + '</div>' + g.rows.map(row).join('');
    }).join('');
  }

  function paintHead() {
    const todo = all().filter(x => !x.done).length, done = all().length - todo;
    $('shSub').textContent = all().length ? todo + ' to buy · ' + done + ' bought' : 'Nothing on your list yet';
    $('shCount').textContent = all().length;
  }

  function paint() { paintHead(); paintList(); paintChips(); }

  function setView(v) {
    view = v;
    $('shPage').dataset.view = v;
    $('shAddView').hidden = v !== 'add';
    $('shListView').hidden = v !== 'list';
    $('shBar').hidden = v !== 'add';
    $('shPage').classList.toggle('has-bar', v === 'add');
    document.body.classList.toggle('has-bar', v === 'add');
    $$('[data-view]').forEach(t => { if (t.classList.contains('pg-tab')) { t.classList.toggle('on', t.dataset.view === v); t.setAttribute('aria-selected', t.dataset.view === v ? 'true' : 'false'); } });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ---------- events ---------- */
  $$('.pg-tab[data-view]').forEach(b => b.onclick = () => setView(b.dataset.view));
  $$('[data-shf]').forEach(c => c.onclick = () => { flt = c.dataset.shf; paintList(); });

  /* typing updates state only (no re-render, so the keyboard/focus stays put) */
  $('shDrafts').addEventListener('input', e => {
    const f = e.target.dataset.f, card = e.target.closest('.sh-line');
    if (!f || !card) return;
    const d = drafts.find(x => x.k === card.dataset.k); if (!d) return;
    d[f] = e.target.value;
    if (f === 'name') fit(e.target);
    paintBar();
    if (f === 'name') paintChips();
  });
  const addMore = () => {
    const last = drafts[drafts.length - 1];
    if (!last.name.trim()) {
      notify('Enter the item name first.');
      const el = document.querySelector('.sh-line[data-k="' + last.k + '"] [data-f="name"]'); if (el) el.focus();
      return;
    }
    const d = newDraft(); drafts.push(d); paintDrafts(d.k);
  };
  $('shDrafts').addEventListener('keydown', e => {
    if (e.key !== 'Enter' || !e.target.dataset.f) return;
    e.preventDefault();
    const card = e.target.closest('.sh-line'); if (!card) return;
    const i = drafts.findIndex(x => x.k === card.dataset.k);
    if (i === drafts.length - 1) addMore();
    else { const n = document.querySelector('.sh-line[data-k="' + drafts[i + 1].k + '"] [data-f="name"]'); if (n) n.focus(); }
  });
  $('shDrafts').addEventListener('click', e => {
    if (e.target.closest('[data-more]')) return addMore();
    const rm = e.target.closest('[data-rm]');
    if (rm) {
      drafts = drafts.filter(x => x.k !== rm.dataset.rm);
      if (!drafts.length) drafts = [newDraft()];
      paintDrafts();
    }
  });

  $('shChips').addEventListener('click', e => {
    const c = e.target.closest('[data-chip]'); if (!c) return;
    const empty = drafts.find(d => !d.name.trim());
    if (empty) { empty.name = c.dataset.chip; paintDrafts(); }
    else { const d = newDraft(c.dataset.chip); drafts.push(d); paintDrafts(); }
    buzz();
  });

  $('shSave').onclick = async () => {
    const todo = filled();
    if (!todo.length) { notify('Enter at least one item name.'); const el = document.querySelector('.sh-line [data-f="name"]'); if (el) el.focus(); return; }
    $('shSave').disabled = true;
    let ok = 0, bad = [], lastErr = '';
    for (const d of todo) {
      try {
        const j = await api('/api/shopping', 'POST', { name: d.name.trim(), qty: d.qty.trim(), price: d.price || 0 });
        if (j.state) { state = Object.assign(defaults(), j.state); }
        ok++; drafts = drafts.filter(x => x.k !== d.k);
      } catch (err) { bad.push(d); lastErr = err.message === 'Failed to fetch' ? 'Server unreachable.' : err.message; }
    }
    $('shSave').disabled = false;
    if (!drafts.length) drafts = [newDraft()];
    paint(); paintDrafts();
    if (ok) buzz();
    if (!bad.length) { notify(ok + (ok === 1 ? ' item' : ' items') + ' added to your list'); setView('list'); }
    else notify((ok ? ok + ' saved. ' : '') + bad.length + ' not added: ' + lastErr);
  };

  document.querySelector('.shop-page').addEventListener('click', async e => {
    const t = e.target.closest('[data-tog]'), d = e.target.closest('[data-del]'), ed = e.target.closest('[data-edit]'), g = e.target.closest('[data-goadd]');
    if (g) { setView('add'); return; }
    if (t) {
      const it = all().find(x => x.id === t.dataset.tog); if (!it) return;
      buzz();
      if (await act('PUT', '/api/shopping/' + it.id, { done: !it.done })) paint();
    } else if (d) {
      if (await act('DELETE', '/api/shopping/' + d.dataset.del)) paint();
    } else if (ed) {
      const it = all().find(x => x.id === ed.dataset.edit); if (!it) return;
      editId = it.id;
      $('esName').value = it.name; $('esQty').value = it.qty || ''; $('esPrice').value = Number(it.price) > 0 ? it.price : '';
      $('esToggleLbl').textContent = it.done ? 'Mark as not bought' : 'Mark as bought';
      openOv($('sheetShop'));
    }
  });

  $('esSave').onclick = async () => {
    if (!editId) return;
    const j = await act('PUT', '/api/shopping/' + editId, { name: $('esName').value, qty: $('esQty').value, price: $('esPrice').value || 0 }, 'Item updated');
    if (j) { closeOv($('sheetShop')); paint(); }
  };
  $('esToggle').onclick = async () => {
    const it = all().find(x => x.id === editId); if (!it) return;
    if (await act('PUT', '/api/shopping/' + editId, { done: !it.done }, it.done ? 'Moved back to To buy' : 'Marked as bought')) { closeOv($('sheetShop')); paint(); }
  };
  $('esDelete').onclick = async () => {
    if (!editId) return;
    if (await act('DELETE', '/api/shopping/' + editId, null, 'Item removed')) { closeOv($('sheetShop')); paint(); }
  };

  $('shClear').onclick = async () => {
    if (!(await confirmBox('Clear bought items?', 'Items you ticked as bought will be removed from the list.', 'Clear'))) return;
    if (await act('POST', '/api/shopping/clear-done', null, 'Bought items cleared')) paint();
  };

  $('shShare').onclick = async () => {
    const todo = all().filter(x => !x.done);
    if (!todo.length) return notify('Add something to share first.');
    const text = '🛒 Shopping list\n' + todo.map(x => '• ' + x.name + (x.qty ? ' – ' + x.qty : '')).join('\n');
    try {
      if (navigator.share) { await navigator.share({ title: 'Shopping list', text }); return; }
    } catch (e) { if (e && e.name === 'AbortError') return; }
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
  };

  paint(); paintDrafts();
  /* a list that already has items opens on "My list" only when asked: #list */
  if (location.hash === '#list') setView('list');
});

/* ============================================================
   PAGE: INTEREST — money given / taken, with interest
   All the maths lives on the server (interest.py); the browser only
   shows what it returns, so every screen always agrees.
   ============================================================ */
const iapi = (method, url, body) => api(url + (url.includes('?') ? '&' : '?') + 'today=' + todayKey, method, body);
const fmt12 = t => {
  if (!/^\d{2}:\d{2}$/.test(t || '')) return '';
  let [h, m] = t.split(':').map(Number); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
  return h + ':' + pad(m) + ' ' + ap;
};
const nowTime = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
const whenText = o => shortDay(o.date) + (o.time ? ' · ' + fmt12(o.time) : '');
const trimNum = n => String(Math.round(Number(n || 0) * 100) / 100);
const rateLine = i => trimNum(i.rate) + '% per ' + i.period;
const kindLabel = k => k === 'compound' ? 'Compound (monthly)' : 'Simple';
const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

pages.interest = () => start(async () => {
  let loans = [], tot = null, filter = 'all', q = '', cur = null;

  async function reload() {
    const j = await iapi('GET', '/api/interest');
    loans = j.loans || []; tot = j.totals || {};
    paint();
  }
  const match = v => {
    if (filter === 'given' || filter === 'taken') { if (v.direction !== filter) return false; }
    else if (filter === 'open' || filter === 'closed') { if (v.calc.status !== filter) return false; }
    if (q) {
      const hay = [v.name, v.party, v.description, v.phone].join(' ').toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  };
  function rowHtml(v) {
    const given = v.direction === 'given', c = v.calc, closed = c.status === 'closed';
    return `<div class="tx-row" data-iid="${esc(v.id)}">
      <span class="tx-ico" style="background:${given ? 'var(--ok-soft)' : 'var(--red-soft)'};color:${given ? 'var(--ok)' : 'var(--red)'}">${ic(given ? 'upload' : 'download', 'lg')}</span>
      <div class="tx-main"><div class="tx-title">${esc(v.name)}</div>
      <div class="tx-sub">${given ? 'Given to ' : 'Taken from '}${esc(v.party)} · ${esc(whenText(v))}</div></div>
      <span class="tx-amt-wrap"><span class="tx-amt ${given ? 'pos' : 'neg'}">${inr(closed ? v.principal : c.total_due)}</span>
      <small class="tx-st ${closed ? 'ok' : 'part'}">${closed ? 'Settled' : 'incl. ' + inr(c.interest_due) + ' interest'}</small></span>
    </div>`;
  }
  function paint() {
    $('intGet').textContent = inr(tot.receive_total);
    $('intGetSub').textContent = 'Principal ' + inr(tot.receive_principal) + ' + Interest ' + inr(tot.receive_interest);
    $('intGive').textContent = inr(tot.pay_total);
    $('intGiveSub').textContent = 'Principal ' + inr(tot.pay_principal) + ' + Interest ' + inr(tot.pay_interest);
    $('intSub').textContent = loans.length ? plural(loans.length, 'record') + ' · ' + tot.open + ' open' : 'No records yet';
    const list = loans.filter(match);
    $('intChip').textContent = list.length;
    $('intList').innerHTML = list.length ? list.map(rowHtml).join('')
      : emptyState('ill-ledger', loans.length ? 'No matching records' : 'No interest records yet', loans.length ? 'Try a different filter or search.' : 'Tap Add to record money you gave or took.');
  }

  function filesHtml(list) {
    return list.map((a, i) => {
      const kind = kindOf(a);
      return `<button type="button" class="attach-chip" data-ig="${i}" data-url="${esc(a.url)}" data-name="${esc(a.name || 'file')}" data-kind="${kind}">
        ${kind === 'pdf' ? `<span class="file-ico">${ic('file')}</span>` : `<img src="${esc(cldThumb(a.url, 160))}" alt="" onerror="this.onerror=null;this.src='${esc(a.url)}'">`}
        <span class="attach-name">${esc(a.name || 'file')}</span></button>`;
    }).join('');
  }
  function detailHtml(v) {
    const given = v.direction === 'given', c = v.calc, closed = c.status === 'closed', r = v.rate_info;
    const giver = given ? 'You' : v.party, taker = given ? v.party : 'You';
    const sigs = [['sig_giver', 'Giver · ' + giver], ['sig_taker', 'Taker · ' + taker]].filter(s => v[s[0]]);
    const row = (k, val) => `<div class="kv"><span>${k}</span><strong>${val}</strong></div>`;
    return `
    <div class="det-hero">
      <span class="tx-ico" style="background:${given ? 'var(--ok-soft)' : 'var(--red-soft)'};color:${given ? 'var(--ok)' : 'var(--red)'}">${ic(given ? 'upload' : 'download', 'lg')}</span>
      <div class="tx-main"><div class="tx-title">${esc(v.name)}</div><div class="tx-sub">${given ? 'Given to ' : 'Taken from '}${esc(v.party)}</div></div>
      <span class="tx-chip ${closed ? 'paid' : 'unpaid'}">${closed ? 'Settled' : 'Open'}</span>
    </div>
    <div class="det-amts">
      <div class="det-amt"><small>Principal${closed ? '' : ' left'}</small><strong>${inr(closed ? v.principal : c.principal_outstanding)}</strong></div>
      <div class="det-amt"><small>Interest${closed ? '' : ' due'}</small><strong>${inr(closed ? c.interest_total : c.interest_due)}</strong></div>
      <div class="det-amt"><small>${closed ? 'Total paid' : 'Total due'}</small><strong>${inr(closed ? c.total_paid : c.total_due)}</strong></div>
    </div>
    <div class="mini-label">Who &amp; when</div>
    ${row('Money', given ? 'Given by you' : 'Taken by you')}
    ${row('Given by', esc(giver))}
    ${row('Taken by', esc(taker))}
    ${v.phone ? row('Phone', `<a href="tel:${esc(v.phone)}">${esc(v.phone)}</a>`) : ''}
    ${row('Date', esc(shortDay(v.date)))}
    ${v.time ? row('Time', esc(fmt12(v.time))) : ''}
    ${row('Running for', plural(c.days, 'day'))}
    <div class="mini-label">Interest</div>
    ${row('Rate', esc(rateLine(r)) + ' <small style="color:var(--faint)">(' + trimNum(r.yearly_pct) + '% a year)</small>')}
    ${row('Type', kindLabel(r.kind))}
    ${closed ? '' : row('Interest now (per month)', inr(c.interest_per_month))}
    <div class="mini-label">Amounts</div>
    ${row('Original principal', inr(c.principal))}
    ${row('Principal repaid', inr(c.principal_paid))}
    ${row('Principal left', inr(c.principal_outstanding))}
    ${row('Interest so far', inr(c.interest_total))}
    ${row('Interest paid', inr(c.interest_paid))}
    ${row('Interest due', inr(c.interest_due))}
    ${row('Total paid', inr(c.total_paid))}
    ${c.excess > 0 ? row('Paid extra', inr(c.excess)) : ''}
    ${v.description ? `<div class="mini-label">Description</div><p class="int-desc">${esc(v.description)}</p>` : ''}
    ${(v.attachments || []).length ? `<div class="mini-label">Documents &amp; slips (${v.attachments.length})</div><div class="attach-row" id="intFiles">${filesHtml(v.attachments)}</div>` : ''}
    ${sigs.length ? `<div class="mini-label">Signatures</div><div class="sig-view">${sigs.map(([k, label]) => `
      <button type="button" class="sig-card" data-sigv="${k}"><img src="${esc(v[k].url)}" alt="${esc(label)}"><span>${esc(label)}</span></button>`).join('')}</div>` : ''}
    ${(v.payments || []).length ? `<div class="mini-label">Payments (${v.payments.length})</div>${v.payments.map(p => `
      <div class="pay-item">
        <span class="stat-ico green">${ic('wallet')}</span>
        <div class="pi-main"><div style="font-weight:700;font-size:13px">${inr(p.amount)}</div>
        <div style="font-size:11.5px;color:var(--faint)">${esc(whenText(p))}${p.note ? ' · ' + esc(p.note) : ''}</div>
        <div style="font-size:11.5px;color:var(--muted)">Interest ${inr(p.interest_part)} · Principal ${inr(p.principal_part)}${p.excess > 0 ? ' · Extra ' + inr(p.excess) : ''}</div></div>
        <button class="icon-btn plain danger" data-ipdel="${esc(p.id)}" aria-label="Delete payment">${ic('trash', 'sm')}</button>
      </div>`).join('')}` : ''}
    <p class="hint" style="margin-top:12px">Interest is counted by date (1 month = 30 days, 1 year = 365 days). Payments go to interest first, then principal.</p>`;
  }

  function openDetail(id) {
    const v = loans.find(x => x.id === id); if (!v) return;
    cur = v;
    $('intDet').innerHTML = detailHtml(v);
    $('intPayBtn').style.display = v.calc.status === 'closed' ? 'none' : '';
    $('intEditBtn').href = '/interest/add?edit=' + encodeURIComponent(v.id);
    $('intDet').querySelectorAll('[data-ig]').forEach(b => b.onclick = () => openLightbox(b.dataset.url, b.dataset.name, b.dataset.kind));
    $('intDet').querySelectorAll('[data-sigv]').forEach(b => b.onclick = () => openLightbox(v[b.dataset.sigv].url, v[b.dataset.sigv].name || 'Signature', 'img'));
    $('intDet').querySelectorAll('[data-ipdel]').forEach(b => b.onclick = async () => {
      if (!(await confirmBox('Delete payment?', 'This payment will be removed and the interest recalculated.', 'Delete'))) return;
      try { await iapi('DELETE', `/api/interest/${v.id}/payment/${b.dataset.ipdel}`); notify('Payment removed'); await reload(); openDetail(v.id); }
      catch (e) { notify(e.message); }
    });
    openOv($('sheetInt'));
  }

  $('intList').addEventListener('click', e => { const r = e.target.closest('[data-iid]'); if (r) openDetail(r.dataset.iid); });
  $$('[data-ifilter]').forEach(b => b.onclick = () => {
    filter = b.dataset.ifilter;
    $$('[data-ifilter]').forEach(x => x.classList.toggle('on', x === b));
    paint();
  });
  $('intSearch').addEventListener('input', debounce(() => { q = $('intSearch').value.trim().toLowerCase(); paint(); }, 150));

  $('intDelBtn').onclick = async () => {
    if (!cur) return;
    if (!(await confirmBox('Delete this record?', 'Its payments, documents and signatures will also be removed.', 'Delete'))) return;
    try { await iapi('DELETE', '/api/interest/' + cur.id); closeOv($('sheetInt')); notify('Record deleted'); buzz(); await reload(); }
    catch (e) { notify(e.message); }
  };

  /* record a payment */
  $('intPayBtn').onclick = () => {
    if (!cur) return;
    const c = cur.calc;
    $('ipTitle').textContent = cur.direction === 'given' ? 'Received from ' + cur.party : 'Paid to ' + cur.party;
    $('ipPrin').textContent = inr(c.principal_outstanding);
    $('ipInt').textContent = inr(c.interest_due);
    $('ipDue').textContent = inr(c.total_due);
    $('ipAmount').value = ''; $('ipNote').value = ''; $('ipTime').value = '';
    $('ipDate').value = todayKey; $('ipDate').min = cur.date; $('ipDate').max = todayKey;
    closeOv($('sheetInt'));
    openOv($('sheetIntPay'));
  };
  $('ipFull').onclick = () => { if (cur) $('ipAmount').value = cur.calc.total_due; };
  $('ipSave').onclick = async () => {
    if (!cur) return;
    try {
      const j = await iapi('POST', `/api/interest/${cur.id}/payment`, {
        amount: $('ipAmount').value, date: $('ipDate').value, time: $('ipTime').value, note: $('ipNote').value
      });
      closeOv($('sheetIntPay')); notify('Payment recorded'); buzz();
      await reload(); openDetail(j.loan.id);
    } catch (e) { notify(e.message === 'Failed to fetch' ? 'Server unreachable. Nothing saved.' : e.message); }
  };

  $('intSub').textContent = 'Loading…';
  try { await reload(); } catch (e) { $('intSub').textContent = 'Could not load'; notify(e.message); }
});

/* ---------- signature pad: draw with finger / mouse, saved as a PNG upload ---------- */
function sigPad(box) {
  const cv = box.querySelector('canvas'), saved = box.querySelector('.sig-saved'), hint = box.querySelector('.sig-hint');
  const ctx = cv.getContext('2d');
  const dpr = Math.max(1, window.devicePixelRatio || 1);
  const W = Math.round(cv.clientWidth) || 320, H = 150;
  let drawn = false, dirty = false, existing = null, uploaded = null, last = null;
  cv.width = W * dpr; cv.height = H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#0f2a6b';

  const pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * (W / r.width), (e.clientY - r.top) * (H / r.height)]; };
  function showSaved() {
    const show = !!existing && !drawn;
    saved.hidden = !show;
    saved.innerHTML = show ? `<img src="${esc(existing.url)}" alt="Saved signature"><small>Saved signature — sign below to replace it</small>` : '';
    hint.hidden = drawn;
  }
  cv.addEventListener('pointerdown', e => {
    e.preventDefault();
    try { cv.setPointerCapture(e.pointerId); } catch (_) { }
    last = pt(e);
    ctx.beginPath(); ctx.moveTo(last[0], last[1]); ctx.lineTo(last[0] + 0.01, last[1]); ctx.stroke();
    drawn = true; dirty = true; showSaved();
  });
  cv.addEventListener('pointermove', e => {
    if (!last) return;
    const p = pt(e);
    ctx.beginPath(); ctx.moveTo(last[0], last[1]); ctx.lineTo(p[0], p[1]); ctx.stroke();
    last = p;
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => cv.addEventListener(ev, () => { last = null; }));
  box.querySelector('[data-sig-clear]').onclick = () => {
    ctx.clearRect(0, 0, W, H);
    drawn = false; dirty = false; existing = null; uploaded = null;
    showSaved();
  };
  return {
    setExisting: a => { existing = a || null; showSaved(); },
    isDrawn: () => drawn,
    /* the signature to save: a fresh drawing is uploaded once (white background so it reads anywhere) */
    async value(label) {
      if (!drawn) return existing;
      if (uploaded && !dirty) return uploaded;
      const tmp = document.createElement('canvas'); tmp.width = cv.width; tmp.height = cv.height;
      const g = tmp.getContext('2d'); g.fillStyle = '#ffffff'; g.fillRect(0, 0, tmp.width, tmp.height); g.drawImage(cv, 0, 0);
      const blob = await new Promise(res => tmp.toBlob(res, 'image/png'));
      if (!blob) throw new Error('Could not save the signature.');
      const att = await uploadFile(blob, 'signature.png');
      uploaded = Object.assign({}, att, { name: label || 'Signature' });
      dirty = false;
      return uploaded;
    }
  };
}

pages.interestAdd = () => start(async () => {
  const editId = new URLSearchParams(location.search).get('edit');
  let dir = 'given', kind = 'simple', nameTouched = false, token = 0;
  const files = attachWidget($('iaFileList'), $('iaFileInput'), { max: (window.APP && APP.max_interest_files) || 6 });
  $('iaFileDrop').onclick = () => $('iaFileInput').click();
  const sigG = sigPad($('sigGiverBox')), sigT = sigPad($('sigTakerBox'));

  $('iaDate').value = todayKey; $('iaDate').max = todayKey;
  $('iaTime').value = nowTime();            /* auto-taken, but optional and display-only */
  $('iaTimeClear').onclick = () => { $('iaTime').value = ''; };

  function setDir(d) {
    dir = d;
    $$('.int-dir-btn').forEach(b => { const on = b.dataset.dir === d; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); });
    $('iaPartyLbl').textContent = d === 'given' ? 'Given to' : 'Taken from';
    labels();
  }
  function labels() {
    const p = $('iaParty').value.trim() || 'person';
    $('sigGiverLbl').textContent = 'Giver’s signature · ' + (dir === 'given' ? 'You' : p);
    $('sigTakerLbl').textContent = 'Taker’s signature · ' + (dir === 'given' ? p : 'You');
    if (!nameTouched && !editId) $('iaName').value = $('iaParty').value.trim() ? $('iaParty').value.trim() + ' loan' : '';
  }
  $$('.int-dir-btn').forEach(b => b.onclick = () => setDir(b.dataset.dir));
  $('iaParty').addEventListener('input', labels);
  $('iaName').addEventListener('input', () => { nameTouched = true; });

  function setKind(k) {
    kind = k;
    $$('#iaKind .seg-btn').forEach(b => b.classList.toggle('on', b.dataset.kind === k));
    $('iaKindHint').textContent = k === 'compound'
      ? 'Unpaid interest is added to the amount every month, so interest is charged on interest too.'
      : 'Interest is charged only on the principal that is still owed.';
    preview();
  }
  $$('#iaKind .seg-btn').forEach(b => b.onclick = () => setKind(b.dataset.kind));

  /* live auto-calculation */
  async function runPreview() {
    const principal = Number($('iaPrincipal').value);
    const my = ++token;
    if (!(principal > 0)) { $('iaCalc').hidden = true; return; }
    try {
      const j = await iapi('POST', '/api/interest/calc', {
        principal, rate: $('iaRate').value, rate_period: $('iaPeriod').value, interest_type: kind, date: $('iaDate').value
      });
      if (my !== token) return;
      if (!j.valid) { $('iaCalc').hidden = true; return; }
      const c = j.calc, r = c.rate_info;
      $('icPrin').textContent = inr(c.principal);
      $('icIntLbl').textContent = c.days > 0 ? 'Interest so far (' + plural(c.days, 'day') + ')' : 'Interest so far';
      $('icInt').textContent = inr(c.interest_due);
      $('icTot').textContent = inr(c.total_due);
      $('icMonth').textContent = inr(c.principal * r.monthly_pct / 100);
      $('icRate').textContent = trimNum(r.monthly_pct) + '% a month · ' + trimNum(r.yearly_pct) + '% a year';
      $('icOutlook').innerHTML = c.outlook.map(o => `<div><small>After ${o.months === 12 ? '1 year' : plural(o.months, 'month')}</small><b>${inr(o.total)}</b><span>+${inr(o.interest)} interest</span></div>`).join('');
      $('iaCalc').hidden = false;
    } catch (_) { if (my === token) $('iaCalc').hidden = true; }
  }
  const preview = debounce(runPreview, 250);
  ['iaPrincipal', 'iaRate', 'iaPeriod', 'iaDate'].forEach(id => { $(id).addEventListener('input', preview); $(id).addEventListener('change', preview); });

  /* edit mode: load the record and fill the form */
  if (editId) {
    $('iaHead').textContent = 'Edit Interest Record';
    $('iaSaveLbl').textContent = 'Save changes';
    document.title = 'Edit Interest Record';
    try {
      const j = await iapi('GET', '/api/interest');
      const v = (j.loans || []).find(x => x.id === editId);
      if (!v) { notify('Record not found.'); setTimeout(() => { location.href = '/interest'; }, 900); return; }
      nameTouched = true;
      setDir(v.direction);
      $('iaName').value = v.name; $('iaParty').value = v.party; $('iaPhone').value = v.phone || '';
      $('iaDesc').value = v.description || '';
      $('iaPrincipal').value = v.principal; $('iaRate').value = v.rate;
      $('iaPeriod').value = v.rate_period || 'month';
      $('iaDate').value = v.date; $('iaTime').value = v.time || '';
      setKind(v.interest_type || 'simple');
      files.set(v.attachments || []);
      sigG.setExisting(v.sig_giver); sigT.setExisting(v.sig_taker);
      labels();
    } catch (e) { notify(e.message); return; }
  } else { labels(); }

  $('iaSave').onclick = async () => {
    if (files.busy()) return notify('Please wait for the upload to finish.');
    const btn = $('iaSave'); btn.disabled = true;
    try {
      const [g, t] = await Promise.all([sigG.value('Giver signature'), sigT.value('Taker signature')]);
      const body = {
        name: $('iaName').value, direction: dir, party: $('iaParty').value, phone: $('iaPhone').value,
        principal: $('iaPrincipal').value, rate: $('iaRate').value, rate_period: $('iaPeriod').value,
        interest_type: kind, date: $('iaDate').value, time: $('iaTime').value,
        description: $('iaDesc').value, attachments: files.get(), sig_giver: g, sig_taker: t
      };
      if (editId) await iapi('PUT', '/api/interest/' + encodeURIComponent(editId), body);
      else await iapi('POST', '/api/interest', body);
      notify(editId ? 'Record updated' : 'Record saved'); buzz();
      setTimeout(() => { location.href = '/interest'; }, 350);
    } catch (e) {
      btn.disabled = false;
      notify(e.message === 'Failed to fetch' ? 'Server unreachable. Nothing saved.' : e.message);
    }
  };
});

/* ---------------- boot ---------------- */
async function start(fn) {
  bindGlobal();
  try { await fn(); } catch (e) { console.error(e); notify('Something went wrong loading this page.'); }
}

window.MM = { pages, notify, confirm: confirmBox, openOv, closeOv, openLightbox };
})();
