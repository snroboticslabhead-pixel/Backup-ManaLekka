"""Interest ledger maths for ManaLekka.

Rules (kept deliberately simple so anyone can verify them by hand):

* Calculation is **date based only**. The optional time on a record is shown
  for reference but is never used here.
* Rate period "month": 1 month = 30 days, so 2 % / month = 2/30 % per day.
  Rate period "year" : 1 year  = 365 days.
* "simple"   - interest is charged only on the principal still outstanding.
  "compound" - unpaid interest is added to the interest-bearing balance on
  every monthly anniversary of the start date (interest on interest).
* A payment is applied to the interest due first, then to the principal.
  (Interest first is the usual convention for informal lending.)
"""
import calendar
from datetime import date, timedelta

DAYS_IN_MONTH = 30
DAYS_IN_YEAR = 365
EPS = 0.005  # half a paisa: below this a balance counts as zero


def add_months(d, n):
    """d + n calendar months, clamping the day (31 Jan + 1 month = 28/29 Feb)."""
    idx = d.month - 1 + n
    y, m = d.year + idx // 12, idx % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def daily_rate(rate, period):
    """Interest per day as a fraction (e.g. 0.000666 for 2 % per month)."""
    return float(rate) / 100.0 / (DAYS_IN_YEAR if period == "year" else DAYS_IN_MONTH)


def monthly_rate_pct(rate, period):
    return float(rate) if period != "year" else float(rate) / 12.0


def yearly_rate_pct(rate, period):
    return float(rate) * 12.0 if period != "year" else float(rate)


def _r2(x):
    return round(float(x) + 0.0, 2)


def calculate(principal, rate, period, kind, start, payments, as_of):
    """Run the loan day by day from `start` to `as_of`.

    `payments` is a list of dicts with "date" (ISO string or date), "amount"
    and optional "id". Returns a dict of totals plus the split of every
    payment into interest / principal / excess.
    """
    principal = float(principal)
    rd = daily_rate(rate, period)
    compound = kind == "compound"

    def as_date(v):
        return v if isinstance(v, date) else date.fromisoformat(str(v))

    by_day = {}
    ordered = []
    for i, p in enumerate(payments or []):
        d = max(as_date(p.get("date")), start)  # a payment can't predate the loan
        if d > as_of:
            continue
        item = {"id": p.get("id"), "amount": float(p.get("amount") or 0), "date": d, "i": i}
        by_day.setdefault(d, []).append(item)
        ordered.append(item)

    anniversaries = set()
    if compound:
        k = 1
        while True:
            a = add_months(start, k)
            if a > as_of:
                break
            anniversaries.add(a)
            k += 1

    st = {"P": principal, "U": 0.0, "cb": 0.0, "accrued": 0.0, "int_paid": 0.0, "prin_paid": 0.0, "excess": 0.0}
    split = {}

    def apply(day):
        for p in by_day.get(day, []):
            amt = p["amount"]
            ip = min(amt, st["U"])
            st["U"] -= ip
            rest = amt - ip
            pp = min(rest, st["P"])
            st["P"] -= pp
            ex = rest - pp
            st["int_paid"] += ip
            st["prin_paid"] += pp
            st["excess"] += ex
            st["cb"] = min(st["cb"], st["U"])
            split[p["i"]] = (ip, pp, ex)

    apply(start)
    for n in range(1, (as_of - start).days + 1):
        day = start + timedelta(days=n)
        base = st["P"] + st["cb"]
        if base > 0:
            a = base * rd
            st["U"] += a
            st["accrued"] += a
        if day in anniversaries:
            st["cb"] = st["U"]
        apply(day)

    P = 0.0 if st["P"] < EPS else st["P"]
    U = 0.0 if st["U"] < EPS else st["U"]
    pay_rows = {}
    for p in ordered:
        ip, pp, ex = split.get(p["i"], (0.0, 0.0, 0.0))
        pay_rows[p["id"] if p["id"] is not None else p["i"]] = {
            "interest_part": _r2(ip), "principal_part": _r2(pp), "excess": _r2(ex),
        }

    return {
        "principal": _r2(principal),
        "principal_paid": _r2(st["prin_paid"]),
        "principal_outstanding": _r2(P),
        "interest_total": _r2(st["accrued"]),
        "interest_paid": _r2(st["int_paid"]),
        "interest_due": _r2(U),
        "total_due": _r2(P + U),
        "total_paid": _r2(st["int_paid"] + st["prin_paid"] + st["excess"]),
        "excess": _r2(st["excess"]),
        "days": max(0, (as_of - start).days),
        "closed": P == 0.0 and U == 0.0,
        "split": pay_rows,
    }


def rate_summary(rate, period, kind):
    return {
        "rate": float(rate),
        "period": period,
        "kind": kind,
        "monthly_pct": round(monthly_rate_pct(rate, period), 4),
        "yearly_pct": round(yearly_rate_pct(rate, period), 4),
    }


def loan_view(loan, as_of=None):
    """The stored loan plus everything calculated from it, ready for the UI."""
    as_of = as_of or date.today()
    start = date.fromisoformat(loan["date"])
    res = calculate(
        loan["principal"], loan["rate"], loan.get("rate_period", "month"),
        loan.get("interest_type", "simple"), start, loan.get("payments", []), as_of,
    )
    split = res.pop("split")
    out = dict(loan)
    pays = []
    for p in loan.get("payments", []):
        row = dict(p)
        row.update(split.get(p.get("id"), {"interest_part": 0.0, "principal_part": 0.0, "excess": 0.0}))
        pays.append(row)
    pays.sort(key=lambda r: (r.get("date", ""), r.get("time", "") or ""), reverse=True)
    out["payments"] = pays
    res["status"] = "closed" if res.pop("closed") else "open"
    # what the interest is running at right now, on what is still owed
    per_day = res["principal_outstanding"] * daily_rate(loan["rate"], loan.get("rate_period", "month"))
    res["interest_per_day"] = _r2(per_day)
    res["interest_per_month"] = _r2(per_day * DAYS_IN_MONTH)
    out["calc"] = res
    out["rate_info"] = rate_summary(loan["rate"], loan.get("rate_period", "month"), loan.get("interest_type", "simple"))
    return out


def totals(views):
    """Roll-up across loans: what I will receive vs what I must pay."""
    t = {
        "receive_principal": 0.0, "receive_interest": 0.0, "receive_total": 0.0,
        "pay_principal": 0.0, "pay_interest": 0.0, "pay_total": 0.0,
        "open": 0, "closed": 0,
    }
    for v in views:
        c = v["calc"]
        if c["status"] == "closed":
            t["closed"] += 1
            continue
        t["open"] += 1
        side = "receive" if v.get("direction") == "given" else "pay"
        t[side + "_principal"] += c["principal_outstanding"]
        t[side + "_interest"] += c["interest_due"]
        t[side + "_total"] += c["total_due"]
    for k, val in list(t.items()):
        if isinstance(val, float):
            t[k] = _r2(val)
    t["net"] = _r2(t["receive_total"] - t["pay_total"])
    return t


def preview(principal, rate, period, kind, start, as_of=None):
    """Quick what-if used by the add form: no payments, plus 1 / 6 / 12 month outlook."""
    as_of = as_of or date.today()
    now = calculate(principal, rate, period, kind, start, [], max(as_of, start))
    outlook = []
    for months in (1, 6, 12):
        end = add_months(start, months)
        r = calculate(principal, rate, period, kind, start, [], end)
        outlook.append({"months": months, "interest": r["interest_due"], "total": r["total_due"]})
    now.pop("split", None)
    now.pop("closed", None)
    now["outlook"] = outlook
    now["rate_info"] = rate_summary(rate, period, kind)
    return now
