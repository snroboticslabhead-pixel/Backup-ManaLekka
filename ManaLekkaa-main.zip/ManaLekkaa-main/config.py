"""ManaLekka central configuration."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def _env(name, default=""):
    return os.environ.get(name, default).strip()


class Config:
    # ---------- Branding ----------
    APP_NAME = _env("APP_NAME", "ManaLekka")
    APP_TAGLINE = "Daily Milk & Expense Tracker"
    LEDGER_NAME = "KhataBook"
    CURRENCY = "₹"
    CURRENCY_CODE = "INR"
    FILE_PREFIX = APP_NAME.lower()

    # ---------- Secrets / infrastructure ----------
    SECRET_KEY = _env("SECRET_KEY", "f8b9e6a4c2d0e1f3a5b7c9d1e3f5a7b9c1d3e5f7a9b1c3d5e7f9a1b3c5d7e9f1")
    DATABASE_URL = _env(
        "DATABASE_URL",
        "postgresql://neondb_owner:npg_fT7Uw9pEylao@"
        "ep-misty-water-b8dgmobt-pooler.c-14.us-east-1.aws.neon.tech/neondb"
        "?channel_binding=require&sslmode=require",
    )
    DB_TABLE = _env("DB_TABLE", "milkmoo_state")
    ROW_ID = 1

    CLOUDINARY_URL = _env("CLOUDINARY_URL", "cloudinary://168577714673218:eZr3FGWSSV8DpSFoBS9VCUcek1g@x5e8dgql")
    CLOUDINARY_CLOUD_NAME = _env("CLOUDINARY_CLOUD_NAME", "x5e8dgql")
    CLOUDINARY_API_KEY = _env("CLOUDINARY_API_KEY", "168577714673218")
    CLOUDINARY_API_SECRET = _env("CLOUDINARY_API_SECRET", "eZr3FGWSSV8DpSFoBS9VCUcek1g")
    # Kept fixed (not derived from the app name) so renaming the site never
    # moves where new bill photos are stored.
    CLOUDINARY_FOLDER = _env("CLOUDINARY_FOLDER", "dailybill")

    # ---------- Uploads ----------
    # Vercel rejects request bodies over 4.5 MB, so stay under it (the app also shrinks phone photos before upload).
    MAX_UPLOAD_MB = 4
    ALLOWED_UPLOAD_EXTENSIONS = ("jpg", "jpeg", "png", "webp", "gif", "pdf")
    # One invoice document + up to 5 bill photos per entry (6 files total).
    MAX_ATTACHMENTS_PER_EXPENSE = 6
    MAX_IMAGES_PER_EXPENSE = 5
    MAX_INVOICE_PER_EXPENSE = 1

    # Interest ledger: documents / slips per record (signatures are separate, 1 each)
    MAX_INTEREST_ATTACHMENTS = 6
    INTEREST_MAX_PRINCIPAL = 100_000_000
    INTEREST_MAX_RATE = 100  # percent per month / per year

    # ---------- Ledger vocabulary ----------
    ALLOWED_PAYMENT_METHODS = (
        "Cash",
        "UPI",
        "Bank transfer",
        "Cheque",
        "Credit / Udhar",
        "Other",
    )

    EXPENSE_TYPE_META = (
        {"key": "debit", "label": "Expense", "hint": "Daily spend", "icon": "basket", "pill": "Expense · money out", "filter": "Expenses (Debit)"},
        {"key": "purchase", "label": "Purchase", "hint": "Stock / Feed", "icon": "store", "pill": "Purchase · stock / supplies", "filter": "Purchases (Stock / Feed)"},
        {"key": "credit", "label": "Credit", "hint": "Money received", "icon": "download", "pill": "Credit · money in", "filter": "Credits (Income / Received)"},
    )
    EXPENSE_TYPES = tuple(t["key"] for t in EXPENSE_TYPE_META)

    DEFAULT_EXPENSE_CATEGORIES = (
        "Groceries",
        "Cattle Feed / Fodder",
        "Dairy Supplies",
        "Vegetables & Fruits",
        "Household",
        "Transport & Fuel",
        "Utilities & Power",
        "Health & Medical",
        "Labor & Wages",
        "Education",
        "Shopping",
        "Other",
    )
    PROTECTED_CATEGORIES = ("Other",)
    DEFAULT_VENDORS = ("Kisan Feed Center", "General Store", "Dairy Supply Depot", "Local Mandi")

    @classmethod
    def brand(cls):
        return {
            "name": cls.APP_NAME,
            "tagline": cls.APP_TAGLINE,
            "ledger": cls.LEDGER_NAME,
            "currency": cls.CURRENCY,
            "types": list(cls.EXPENSE_TYPE_META),
            "methods": list(cls.ALLOWED_PAYMENT_METHODS),
            "categories": list(cls.DEFAULT_EXPENSE_CATEGORIES),
            "protected_categories": list(cls.PROTECTED_CATEGORIES),
            "vendors": list(cls.DEFAULT_VENDORS),
            "max_upload_mb": cls.MAX_UPLOAD_MB,
            "max_attachments": cls.MAX_ATTACHMENTS_PER_EXPENSE,
            "max_images": cls.MAX_IMAGES_PER_EXPENSE,
            "max_invoice": cls.MAX_INVOICE_PER_EXPENSE,
            "max_interest_files": cls.MAX_INTEREST_ATTACHMENTS,
        }

    @classmethod
    def validate(cls):
        if not cls.DATABASE_URL:
            raise RuntimeError("DATABASE_URL is not set.")
