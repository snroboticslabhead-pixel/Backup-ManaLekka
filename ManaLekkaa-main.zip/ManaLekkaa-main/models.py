import atexit
import json
import logging
import os
import re
import socket
import threading
import time
from contextlib import ExitStack, contextmanager
import urllib.request
import uuid
from datetime import datetime, timezone
from urllib.parse import urlparse

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config

try:  # connection pool (requirements.txt); falls back to one-off connections if missing
    from psycopg_pool import ConnectionPool
except ImportError:  # pragma: no cover
    ConnectionPool = None

try:  # per-request cache lives on flask.g
    from flask import g, has_request_context
except ImportError:  # pragma: no cover
    g = None

    def has_request_context():
        return False

logger = logging.getLogger(__name__)

_TABLE = Config.DB_TABLE
if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", _TABLE):
    raise RuntimeError("DB_TABLE must be a valid identifier.")

_schema_ready = False
_RESOLVED_HOSTADDR = None


def _resolve_via_doh(host):
    """Look up the host's IP over HTTPS (DNS-over-HTTPS) when local DNS fails."""
    lookups = (
        (f"https://1.1.1.1/dns-query?name={host}&type=A", {"accept": "application/dns-json"}),
        (f"https://8.8.8.8/resolve?name={host}&type=A", {}),
    )
    for url, headers in lookups:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.load(resp)
            ips = [a["data"] for a in data.get("Answer", []) if a.get("type") == 1]
            if ips:
                logger.info("Successfully resolved %s via DoH to %s", host, ips[0])
                return ips[0]
        except Exception as err:
            logger.warning("DNS-over-HTTPS lookup via %s failed: %s", url.split("/")[2], err)
    return None


def _get_target_ip(host):
    """Return a cached or newly resolved IP address for the given database host."""
    global _RESOLVED_HOSTADDR
    if _RESOLVED_HOSTADDR:
        return _RESOLVED_HOSTADDR

    # Step 1: Attempt standard local DNS
    try:
        ip = socket.gethostbyname(host)
        _RESOLVED_HOSTADDR = ip
        return ip
    except socket.gaierror:
        logger.warning("Local DNS lookup failed for %s. Attempting DoH fallback.", host)

    # Step 2: Attempt DNS-over-HTTPS fallback
    ip = _resolve_via_doh(host)
    if ip:
        _RESOLVED_HOSTADDR = ip
        return ip

    return None


def _connect():
    """Connect to Neon with persistent IP caching to prevent [Errno 11001] loops."""
    global _RESOLVED_HOSTADDR
    Config.validate()
    host = urlparse(Config.DATABASE_URL).hostname
    last_err = None

    for attempt in range(2):
        extra = {}
        ip = _get_target_ip(host)
        if ip:
            extra["hostaddr"] = ip

        try:
            return psycopg.connect(
                Config.DATABASE_URL,
                row_factory=dict_row,
                connect_timeout=10,
                prepare_threshold=None,
                **extra,
            )
        except psycopg.OperationalError as err:
            last_err = err
            logger.warning("Neon connection failed (attempt %s): %s", attempt + 1, err)
            _RESOLVED_HOSTADDR = None  # Invalidate cached IP and retry
            time.sleep(0.5)

    raise last_err


# ---------------------------------------------------------------------------
# Connection pool
# Opening a brand-new TLS connection to Neon costs hundreds of milliseconds,
# and every page used to open 4-5 of them. The pool keeps connections warm and
# reuses them across requests (and across warm serverless invocations).
# ---------------------------------------------------------------------------
_pool = None
_pool_lock = threading.Lock()


def _get_pool():
    global _pool
    if ConnectionPool is None:
        return None
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                Config.validate()
                kwargs = {"row_factory": dict_row, "connect_timeout": 10, "prepare_threshold": None}
                ip = _get_target_ip(urlparse(Config.DATABASE_URL).hostname)
                if ip:
                    kwargs["hostaddr"] = ip
                pool = ConnectionPool(
                    Config.DATABASE_URL,
                    kwargs=kwargs,
                    min_size=1,
                    max_size=int(os.environ.get("DB_POOL_MAX", "5") or 5),
                    max_idle=240,  # drop connections Neon would close anyway
                    timeout=15,
                    check=ConnectionPool.check_connection,  # silently replaces dead/idle-closed connections
                    open=False,
                )
                pool.open(wait=False)
                _pool = pool
    return _pool


def _reset_pool():
    global _pool, _RESOLVED_HOSTADDR
    with _pool_lock:
        old, _pool = _pool, None
        _RESOLVED_HOSTADDR = None
    if old is not None:
        try:
            old.close(timeout=1)
        except Exception:
            pass


atexit.register(_reset_pool)


@contextmanager
def _db():
    """Yield a connection: pooled when possible, else a one-off connection.
    Commits on success and rolls back on error, exactly like the old
    `with _connect() as conn:` blocks did."""
    stack = ExitStack()
    conn = None
    try:
        pool = _get_pool()
        if pool is not None:
            conn = stack.enter_context(pool.connection())
    except Exception as err:
        logger.warning("Connection pool unavailable (%s); using a direct connection.", err)
        _reset_pool()
        conn = None
    if conn is None:
        conn = stack.enter_context(_connect())
    with stack:
        yield conn


def _ensure_schema(conn):
    global _schema_ready
    if _schema_ready:
        return
    conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {_TABLE} (
            id         INTEGER PRIMARY KEY,
            data       JSONB NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    conn.commit()
    _schema_ready = True


_CACHE_KEY = "_dailybill_user_cache"


def _req_cache():
    """Per-request memo (flask.g): one page view reads the database once, not 2-3 times."""
    if g is not None and has_request_context():
        return g.setdefault(_CACHE_KEY, {})
    return None


def _clear_req_cache():
    if g is not None and has_request_context():
        g.pop(_CACHE_KEY, None)


class DailyBillState:
    DEFAULT_CATEGORIES = list(Config.DEFAULT_EXPENSE_CATEGORIES)

    @staticmethod
    def default_user_state(name="User", email="", phone="", vendor="", address="", quantity=500):
        return {
            "name": name,
            "email": email,
            "phone": phone,
            "vendor": vendor,
            "address": address,
            "quantity": quantity,
            "photo": "",
            "prices": [{"from": "2000-01-01", "price": 60.0}],
            "records": {},
            "payments": [],
            "expenses": [],
            "vendors": list(Config.DEFAULT_VENDORS),
            "expense_categories": list(DailyBillState.DEFAULT_CATEGORIES),
            "shopping": [],
            "interest": [],
        }

    @classmethod
    def default_root_store(cls) -> dict:
        default_uid = "default-user"
        return {
            "users": {
                default_uid: {
                    "id": default_uid,
                    "name": "Dairy User",
                    "email": "demo@milkmoo.local",
                    "password_hash": generate_password_hash("password123"),
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
            },
            "user_data": {default_uid: cls.default_user_state(name="Dairy User", email="demo@milkmoo.local")},
        }

    @classmethod
    def _ensure_user_shape(cls, st: dict) -> dict:
        if not isinstance(st, dict):
            return cls.default_user_state()
        st.setdefault("records", {})
        st.setdefault("payments", [])
        st.setdefault("expenses", [])
        st.setdefault("photo", "")
        if not isinstance(st.get("shopping"), list):
            st["shopping"] = []
        if not isinstance(st.get("interest"), list):
            st["interest"] = []

        cats = st.get("expense_categories")
        if not isinstance(cats, list) or len(cats) == 0:
            st["expense_categories"] = list(cls.DEFAULT_CATEGORIES)
        for protected in Config.PROTECTED_CATEGORIES:
            if not any(str(c).lower() == protected.lower() for c in st["expense_categories"]):
                st["expense_categories"].append(protected)

        if not isinstance(st.get("vendors"), list):
            st["vendors"] = list(Config.DEFAULT_VENDORS)

        for e in st["expenses"]:
            if isinstance(e, dict):
                e.setdefault("type", "debit")
                e.setdefault("payments", [])
                e.setdefault("attachments", [])
                e.setdefault("note", "")
                e.setdefault("vendor", "")
                e.setdefault("category", "Other")
                e.setdefault("description", "")
                e.setdefault("method", "Other")
                e.setdefault("bill_number", "")
                # richer invoice details (older entries keep empty defaults)
                e.setdefault("quantity", "")
                e.setdefault("unit_price", None)
                e.setdefault("tax", 0)
                e.setdefault("discount", 0)
                e.setdefault("due_date", "")
                e.setdefault("invoice", None)
        return st

    @classmethod
    def _normalize(cls, s) -> dict:
        if not isinstance(s, dict) or not s:
            return cls.default_root_store()

        if "users" not in s and "records" in s:
            root = cls.default_root_store()
            uid = "default-user"
            root["user_data"][uid] = cls._ensure_user_shape(s)
            root["users"][uid]["name"] = s.get("name", "User")
            return root

        root = {"users": {}, "user_data": {}}
        if isinstance(s.get("users"), dict):
            root["users"] = s["users"]
        if isinstance(s.get("user_data"), dict):
            root["user_data"] = s["user_data"]
        for u_id in root["user_data"]:
            cls._ensure_user_shape(root["user_data"][u_id])
        return root

    @classmethod
    def _read_row(cls, cur, lock=False):
        sql = f"SELECT data FROM {_TABLE} WHERE id = %s"
        if lock:
            sql += " FOR UPDATE"
        cur.execute(sql, (Config.ROW_ID,))
        row = cur.fetchone()
        return row["data"] if row else None

    @classmethod
    def _seed_if_missing(cls, cur):
        cur.execute(
            f"INSERT INTO {_TABLE} (id, data, updated_at) VALUES (%s, %s, NOW()) "
            "ON CONFLICT (id) DO NOTHING",
            (Config.ROW_ID, Jsonb(cls.default_root_store())),
        )

    @classmethod
    def _write_row(cls, cur, state: dict):
        cur.execute(
            f"UPDATE {_TABLE} SET data = %s, updated_at = NOW() WHERE id = %s",
            (Jsonb(state), Config.ROW_ID),
        )

    @classmethod
    def load(cls) -> dict:
        try:
            with _db() as conn:
                _ensure_schema(conn)
                with conn.cursor() as cur:
                    data = cls._read_row(cur)
                    if data is None:
                        cls._seed_if_missing(cur)
                        conn.commit()
                        data = cls._read_row(cur)
                return cls._normalize(data)
        except Exception as err:
            logger.exception("Database unavailable: %s", err)
            raise

    @classmethod
    def mutate(cls, fn):
        try:
            with _db() as conn:
                _ensure_schema(conn)
                with conn.cursor() as cur:
                    cls._seed_if_missing(cur)
                    data = cls._read_row(cur, lock=True)
                    root = cls._normalize(data)
                    extra = fn(root) or {}
                    cls._write_row(cur, root)
                conn.commit()
                _clear_req_cache()
                return root, extra
        except ValueError:
            raise
        except Exception as err:
            logger.exception("Database write failed: %s", err)
            raise

    @classmethod
    def register_user(cls, name, email, password):
        email_clean = email.lower().strip()
        holder = {}

        def go(root):
            for u in root["users"].values():
                if u.get("email", "").lower().strip() == email_clean:
                    raise ValueError("An account with this email already exists.")
            uid = uuid.uuid4().hex[:12]
            user = {
                "id": uid,
                "name": name.strip(),
                "email": email_clean,
                "password_hash": generate_password_hash(password),
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            root["users"][uid] = user
            root["user_data"][uid] = cls.default_user_state(name=name.strip(), email=email_clean)
            holder["user"] = user

        cls.mutate(go)
        return holder["user"]

    @classmethod
    def authenticate(cls, email, password):
        email_clean = email.lower().strip()
        root = cls.load()
        for u in root.get("users", {}).values():
            if u.get("email", "").lower().strip() == email_clean:
                if check_password_hash(u.get("password_hash", ""), password):
                    return u
                break
        return None

    @classmethod
    def _fetch_bundle(cls, user_id):
        """Read ONLY this user's account + data out of the JSON row.
        (The row holds every user's data; pulling the whole thing on each
        request gets slower as the app grows.) Returns None when the row is
        missing or in the legacy layout so the caller can use the full path."""
        with _db() as conn:
            _ensure_schema(conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT data #> %s::text[] AS u, data #> %s::text[] AS s, (data ? 'users') AS ok "
                    f"FROM {_TABLE} WHERE id = %s",
                    (["users", user_id], ["user_data", user_id], Config.ROW_ID),
                )
                row = cur.fetchone()
        if not row or not row["ok"]:
            return None
        return row["u"], row["s"]

    @classmethod
    def get_user_bundle(cls, user_id):
        """(user, state) for one user, memoised for the rest of this request.
        `state` is None when the user has no data record yet."""
        cache = _req_cache()
        if cache is not None and user_id in cache:
            return cache[user_id]
        try:
            fetched = cls._fetch_bundle(user_id)
        except Exception as err:
            logger.exception("Database unavailable: %s", err)
            raise
        if fetched is None:
            root = cls.load()
            user, st = root.get("users", {}).get(user_id), root.get("user_data", {}).get(user_id)
        else:
            user, st = fetched
        if isinstance(st, dict):
            st = cls._ensure_user_shape(st)
        else:
            st = None
        if cache is not None:
            cache[user_id] = (user, st)
        return user, st

    @classmethod
    def get_user(cls, user_id):
        return cls.get_user_bundle(user_id)[0]

    @classmethod
    def get_user_state(cls, user_id):
        st = cls.get_user_bundle(user_id)[1]
        if st is not None:
            return st

        def go(r):
            if user_id not in r["user_data"]:
                u = r["users"].get(user_id)
                uname = u.get("name", "User") if u else "User"
                uemail = u.get("email", "") if u else ""
                r["user_data"][user_id] = cls.default_user_state(name=uname, email=uemail)

        root, _ = cls.mutate(go)
        return cls._ensure_user_shape(root["user_data"][user_id])

    @classmethod
    def mutate_user_state(cls, user_id, fn):
        holder = {}

        def go(root):
            if user_id not in root["user_data"]:
                u = root["users"].get(user_id)
                uname = u.get("name", "User") if u else "User"
                uemail = u.get("email", "") if u else ""
                root["user_data"][user_id] = cls.default_user_state(name=uname, email=uemail)
            st = cls._ensure_user_shape(root["user_data"][user_id])
            res = fn(st)
            holder["state"] = st
            return res or {}

        _, extra = cls.mutate(go)
        return holder["state"], extra


MilkMooState = DailyBillState

# ---------------------------------------------------------------------------
# File storage in Postgres.
# Used when Cloudinary is not configured or fails. Vercel (serverless) has a
# read-only disk, so files can't be written locally there; the database is
# always available, so uploads never dead-end.
# ---------------------------------------------------------------------------
_FILES_TABLE = f"{_TABLE}_files"
_files_ready = False


def _ensure_files_schema(conn):
    global _files_ready
    if _files_ready:
        return
    conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {_FILES_TABLE} (
            id         TEXT PRIMARY KEY,
            uid        TEXT NOT NULL,
            name       TEXT NOT NULL DEFAULT '',
            mime       TEXT NOT NULL DEFAULT 'application/octet-stream',
            size       INTEGER NOT NULL DEFAULT 0,
            data       BYTEA NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    conn.execute(f"CREATE INDEX IF NOT EXISTS {_FILES_TABLE}_uid_idx ON {_FILES_TABLE} (uid)")
    conn.commit()
    _files_ready = True


def store_file(uid, blob, name, mime):
    """Save a file for one user and return its id."""
    fid = uuid.uuid4().hex
    with _db() as conn:
        _ensure_files_schema(conn)
        conn.execute(
            f"INSERT INTO {_FILES_TABLE} (id, uid, name, mime, size, data) VALUES (%s, %s, %s, %s, %s, %s)",
            (fid, uid, (name or "")[:120], mime, len(blob), blob),
        )
    return fid


def read_file(uid, fid):
    """(bytes, mime, name) for a file owned by `uid`, else None."""
    with _db() as conn:
        _ensure_files_schema(conn)
        row = conn.execute(
            f"SELECT data, mime, name FROM {_FILES_TABLE} WHERE id = %s AND uid = %s", (fid, uid)
        ).fetchone()
    if not row:
        return None
    return bytes(row["data"]), row["mime"], row["name"]


def delete_file(uid, fid):
    with _db() as conn:
        _ensure_files_schema(conn)
        conn.execute(f"DELETE FROM {_FILES_TABLE} WHERE id = %s AND uid = %s", (fid, uid))
