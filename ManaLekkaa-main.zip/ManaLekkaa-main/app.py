import calendar
import csv
import gzip
import io
import os
import re
import uuid
from datetime import date, datetime, timedelta, timezone
from functools import wraps

import cloudinary
import cloudinary.api
import cloudinary.uploader
from flask import (
    Flask,
    Response,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge

from config import Config
from interest import loan_view, preview as interest_preview, totals as interest_totals
from models import DailyBillState, delete_file as db_delete_file, read_file as db_read_file, store_file as db_store_file

app = Flask(__name__)
app.config["SECRET_KEY"] = Config.SECRET_KEY
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["MAX_CONTENT_LENGTH"] = (Config.MAX_UPLOAD_MB + 1) * 1024 * 1024


def _cloudinary_credentials():
    """(cloud_name, api_key, api_secret) from CLOUDINARY_URL or the three separate settings.

    The URL is parsed here on purpose: cloudinary.config(cloudinary_url=...) does not
    read it, which left the SDK without credentials and made every upload fall back."""
    from urllib.parse import unquote, urlparse

    raw = (Config.CLOUDINARY_URL or "").strip().strip("\"'")
    if raw.upper().startswith("CLOUDINARY_URL="):  # pasted with the variable name by mistake
        raw = raw.split("=", 1)[1].strip().strip("\"'")
    if raw.startswith("cloudinary://"):
        u = urlparse(raw)
        if u.hostname and u.username and u.password:
            return u.hostname, unquote(u.username), unquote(u.password)
    return (
        Config.CLOUDINARY_CLOUD_NAME.strip(),
        Config.CLOUDINARY_API_KEY.strip(),
        Config.CLOUDINARY_API_SECRET.strip(),
    )


def cloudinary_ready():
    return all(_cloudinary_credentials())


if cloudinary_ready():
    _cn, _ak, _as = _cloudinary_credentials()
    cloudinary.config(cloud_name=_cn, api_key=_ak, api_secret=_as, secure=True)


# ---------------- Local upload fallback storage ----------------
# Cloudinary stays the first choice; if it is not configured (or the
# upload call fails for any reason) the file is stored on the local
# disk and served back through a login-protected route, so bill photo
# uploads keep working in every environment.
_EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]{2,}")
LOCAL_UPLOAD_DIR = os.environ.get("DAILYBILL_LOCAL_UPLOADS") or os.path.join(app.root_path, "local_uploads")
_SAFE_UID = re.compile(r"[A-Za-z0-9_-]{1,80}")
_SAFE_NAME = re.compile(r"[A-Za-z0-9_.-]{1,120}")


def _local_store(uid, blob, ext, filename):
    folder = os.path.join(LOCAL_UPLOAD_DIR, uid)
    os.makedirs(folder, exist_ok=True)
    fname = uuid.uuid4().hex[:20] + (("." + ext) if ext else "")
    with open(os.path.join(folder, fname), "wb") as fh:
        fh.write(blob)
    rel = uid + "/" + fname
    return {
        "url": f"/api/uploads/local/{rel}",
        "public_id": f"local:{rel}",
        "resource_type": "pdf" if ext == "pdf" else "image",
        "format": (ext or "").lower(),
        "name": (filename or "file")[:60],
        "bytes": len(blob),
    }


def _destroy_local(public_id):
    rel = str(public_id).split(":", 1)[1] if ":" in str(public_id) else ""
    parts = rel.split("/")
    if len(parts) != 2:
        return
    uid, fname = parts
    if not _SAFE_UID.fullmatch(uid) or not _SAFE_NAME.fullmatch(fname) or ".." in fname:
        return
    root = os.path.abspath(LOCAL_UPLOAD_DIR)
    path = os.path.abspath(os.path.join(root, uid, fname))
    if path.startswith(root + os.sep) and os.path.isfile(path):
        try:
            os.remove(path)
        except OSError:
            pass


_SAFE_FID = re.compile(r"[0-9a-f]{32}")
_MIME = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
    "webp": "image/webp", "gif": "image/gif", "pdf": "application/pdf",
}


def _destroy_db(public_id):
    fid = str(public_id).split(":", 1)[1] if ":" in str(public_id) else ""
    uid = session.get("user_id")
    if uid and _SAFE_FID.fullmatch(fid):
        try:
            db_delete_file(uid, fid)
        except Exception:
            app.logger.warning("Could not delete stored file %s", fid)


def _destroy_attachment(public_id, resource_type):
    if not public_id:
        return
    if str(public_id).startswith("db:"):
        _destroy_db(public_id)
        return
    if str(public_id).startswith("local:"):
        _destroy_local(public_id)
        return
    if not cloudinary_ready():
        return
    try:
        rt = resource_type if resource_type in ("image", "raw", "video") else "image"
        cloudinary.uploader.destroy(public_id, resource_type=rt, invalidate=True)
    except Exception:
        app.logger.warning("Cloudinary destroy failed for %s", public_id)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("user_id"):
            if request.path.startswith("/api/"):
                return jsonify(error="Authentication required. Please log in."), 401
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)

    return decorated_function


def get_current_user_id() -> str:
    uid = session.get("user_id")
    if not uid:
        raise ValueError("User is not authenticated.")
    return uid


@app.context_processor
def inject_globals():
    uid = session.get("user_id")
    user = None
    user_photo = ""
    if uid:
        # ONE database read (memoised per request) gives both the account and
        # the saved profile photo, which every template shows in its avatar.
        try:
            user, state = DailyBillState.get_user_bundle(uid)
            if user and state:
                user_photo = str(state.get("photo") or "")
        except Exception:
            app.logger.exception("Could not load user for template")
    return dict(current_user=user, user_photo=user_photo, brand=Config.brand())


# ---------------- Speed: caching + compression ----------------
_GZIP_TYPES = ("text/html", "text/css", "text/javascript", "application/javascript", "application/json", "image/svg+xml")
_static_gz = {}  # (path, mtime, size) -> gzipped bytes


@app.after_request
def speed_headers(resp):
    try:
        if resp.status_code != 200:
            return resp
        is_static = request.path.startswith("/static/")

        # Browser caching for static files. css/js carry ?v=N, so they can be
        # cached for a year and still refresh the moment N is bumped.
        if is_static:
            if request.args.get("v"):
                resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
            else:
                resp.headers["Cache-Control"] = "public, max-age=604800"

        # gzip text responses (HTML / CSS / JS / JSON): ~70-80% smaller.
        mime = (resp.mimetype or "").lower()
        if (
            mime in _GZIP_TYPES
            and "gzip" in request.headers.get("Accept-Encoding", "").lower()
            and not resp.headers.get("Content-Encoding")
            and "attachment" not in resp.headers.get("Content-Disposition", "")
        ):
            if is_static:
                key = (request.path, resp.headers.get("Last-Modified"), resp.headers.get("Content-Length"))
                data = _static_gz.get(key)
                if data is None:
                    resp.direct_passthrough = False
                    data = gzip.compress(resp.get_data(), compresslevel=6)
                    _static_gz[key] = data
            else:
                if resp.direct_passthrough:
                    return resp
                raw = resp.get_data()
                if len(raw) < 1024:
                    return resp
                data = gzip.compress(raw, compresslevel=5)
            resp.direct_passthrough = False
            resp.set_data(data)
            resp.headers["Content-Encoding"] = "gzip"
            resp.headers["Content-Length"] = str(len(data))
            resp.vary.add("Accept-Encoding")
    except Exception:  # never let an optimisation break a response
        app.logger.exception("speed_headers failed")
    return resp


def db_error_text(err):
    """Friendly message; in debug mode also show the real reason so it can be fixed."""
    if app.debug:
        return f"Database unavailable: {type(err).__name__}: {str(err).strip()[:220]}"
    return "Database unavailable. Please try again."


def safe_next(target):
    """Only allow same-site relative redirects (prevents open redirects)."""
    t = str(target or "")
    return t if t.startswith("/") and not t.startswith("//") and "\\" not in t else ""


def body():
    b = request.get_json(silent=True)
    return b if isinstance(b, dict) else {}


def parse_day(v):
    try:
        return date.fromisoformat(str(v))
    except (ValueError, TypeError):
        raise ValueError("Enter a valid date.")


def parse_month(v):
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(v or "")):
        raise ValueError("Month must be YYYY-MM.")
    return str(v)


def money(v, what="amount"):
    try:
        n = round(float(v), 2)
    except (TypeError, ValueError):
        raise ValueError(f"Enter a valid {what}.")
    if not 0 <= n <= 10_000_000:
        raise ValueError(f"Enter a valid {what}.")
    return n


def qty_ml(v):
    try:
        n = int(float(v))
    except (TypeError, ValueError):
        raise ValueError("Enter a valid quantity in ml.")
    if not 50 <= n <= 50000:
        raise ValueError("Quantity must be between 50 ml and 50 L.")
    return n


def sanitize_attachments(raw, limit=None):
    out = []
    if not isinstance(raw, list):
        return out
    limit = limit or Config.MAX_ATTACHMENTS_PER_EXPENSE
    for a in raw[:limit]:
        if not isinstance(a, dict):
            continue
        url = str(a.get("url", "")).strip()
        pid = str(a.get("public_id", "")).strip()
        if not pid:
            continue
        if not (url.startswith("http") or url.startswith("/api/uploads/")):
            continue
        try:
            size = int(a.get("bytes") or 0)
        except (TypeError, ValueError):
            size = 0
        out.append(
            {
                "url": url,
                "public_id": pid,
                "resource_type": str(a.get("resource_type", "image")).strip() or "image",
                "format": str(a.get("format", "")).strip().lower()[:10],
                "name": str(a.get("name", "")).strip()[:60],
                "bytes": size,
            }
        )
    return out


def _entry_details(b):
    """Parse the optional invoice-ish details shared by create/update."""
    quantity = str(b.get("quantity", "")).strip()[:40]

    unit_price = None
    if b.get("unit_price") not in (None, "", 0, "0"):
        unit_price = money(b.get("unit_price"), "unit price")

    tax = 0.0
    if b.get("tax") not in (None, "", 0, "0"):
        tax = money(b.get("tax"), "tax amount")

    discount = 0.0
    if b.get("discount") not in (None, "", 0, "0"):
        discount = money(b.get("discount"), "discount")

    due_date = ""
    if b.get("due_date"):
        due_date = parse_day(b.get("due_date")).isoformat()

    invoice = None
    raw_inv = b.get("invoice")
    if isinstance(raw_inv, list):
        raw_inv = raw_inv[0] if raw_inv else None
    if isinstance(raw_inv, dict) and raw_inv.get("public_id"):
        invoice = sanitize_attachments([raw_inv], limit=1)
        invoice = invoice[0] if invoice else None

    return quantity, unit_price, tax, discount, due_date, invoice


def _grand_total(base, tax, discount):
    """Amount saved on the entry = base + tax - discount (never negative)."""
    grand = round(float(base) + float(tax) - float(discount), 2)
    if grand < 0:
        raise ValueError("Discount cannot be more than the amount plus tax.")
    return grand


def _destroy_removed(old_list, new_list):
    """Best-effort delete of files that were detached from an entry on edit."""
    keep = {str(a.get("public_id")) for a in new_list if a.get("public_id")}
    for a in old_list:
        pid = str(a.get("public_id") or "")
        if pid and pid not in keep:
            _destroy_attachment(pid, a.get("resource_type"))


@app.errorhandler(ValueError)
def bad_request(e):
    return jsonify(error=str(e)), 400


@app.errorhandler(RequestEntityTooLarge)
def too_large(e):
    return jsonify(error=f"File is too large. Max size is {Config.MAX_UPLOAD_MB} MB."), 413


@app.errorhandler(Exception)
def server_error(e):
    wants_page = not request.path.startswith("/api/") and "text/html" in request.headers.get("Accept", "")
    if isinstance(e, HTTPException):
        if wants_page and e.code in (404, 405):
            return render_template("error.html", code=404, title="Page not found",
                                   text="The page you are looking for does not exist or has moved."), 404
        return e
    app.logger.exception("Server error: %s", e)
    if wants_page:
        return render_template("error.html", code=500, title="Something went wrong",
                               text="Please try again in a moment. Nothing was saved."), 500
    return jsonify(error=str(e) if app.debug else "Service error. Nothing saved."), 500


def price_on(s, key):
    price = None
    for p in sorted(s.get("prices", []), key=lambda x: str(x["from"])):
        if price is None or str(p["from"]) <= key:
            price = float(p["price"])
    return price if price is not None else 60.0


def amount_for(s, key, rec):
    if rec.get("status") != "delivered":
        return 0.0
    return round((float(rec.get("quantity") or 0) / 1000) * price_on(s, key), 2)


def rows(s, prefix=""):
    out = []
    for k in sorted(s.get("records", {}), reverse=True):
        if not k.startswith(prefix):
            continue
        r = s["records"][k]
        out.append(
            {
                "date": k,
                "status": r.get("status"),
                "quantity": r.get("quantity") or 0,
                "note": r.get("note", ""),
                "rate": price_on(s, k),
                "amount": amount_for(s, k, r),
            }
        )
    return out


def expense_view(e):
    try:
        amount = round(float(e.get("amount") or 0), 2)
    except (TypeError, ValueError):
        amount = 0.0
    paid = 0.0
    for p in e.get("payments", []):
        try:
            paid += float(p.get("amount") or 0)
        except (TypeError, ValueError):
            pass
    paid = round(paid, 2)
    due = round(max(0.0, amount - paid), 2)
    etype = e.get("type") if e.get("type") in Config.EXPENSE_TYPES else "debit"
    if etype == "credit":
        status = "received"
    else:
        status = "paid" if due <= 0.009 else ("partial" if paid > 0 else "unpaid")

    def _num(key):
        try:
            return round(float(e.get(key) or 0), 2)
        except (TypeError, ValueError):
            return 0.0

    invoice = e.get("invoice") if isinstance(e.get("invoice"), dict) else None
    return {
        "id": e.get("id"),
        "date": e.get("date"),
        "month": e.get("month"),
        "type": etype,
        "category": e.get("category") or "Other",
        "vendor": e.get("vendor", ""),
        "bill_number": e.get("bill_number", ""),
        "description": e.get("description", ""),
        "quantity": str(e.get("quantity") or ""),
        "unit_price": _num("unit_price"),
        "tax": _num("tax"),
        "discount": _num("discount"),
        "due_date": str(e.get("due_date") or ""),
        "invoice": invoice,
        "amount": amount,
        "paid": paid,
        "due": due,
        "status": status,
        "method": e.get("method", "Other"),
        "note": e.get("note", ""),
        "payments": e.get("payments", []),
        "attachments": [a for a in e.get("attachments", []) if isinstance(a, dict)],
    }


def expense_totals(items):
    debit_items = [x for x in items if x["type"] in ("debit", "purchase")]
    credit_items = [x for x in items if x["type"] == "credit"]
    purchases = [x for x in items if x["type"] == "purchase"]

    spent = round(sum(x["amount"] for x in debit_items), 2)
    purchases_total = round(sum(x["amount"] for x in purchases), 2)
    received = round(sum(x["amount"] for x in credit_items), 2)
    paid = round(sum(x["paid"] for x in debit_items), 2)
    due = round(sum(x["due"] for x in debit_items), 2)

    cats = {}
    for x in debit_items:
        cats[x["category"]] = round(cats.get(x["category"], 0) + x["amount"], 2)
    top = sorted(cats.items(), key=lambda kv: kv[1], reverse=True)[:6]

    return {
        "count": len(items),
        "debit_count": len(debit_items),
        "credit_count": len(credit_items),
        "purchase_count": len(purchases),
        "spent": spent,
        "purchases_total": purchases_total,
        "received": received,
        "paid": paid,
        "due": due,
        "top_categories": [{"category": k, "amount": v} for k, v in top],
    }


def summary(s, month):
    y, m = map(int, month.split("-"))
    total_days = calendar.monthrange(y, m)[1]
    t = date.today()
    elapsed = (
        t.day
        if (y, m) == (t.year, t.month)
        else total_days
        if (y, m) < (t.year, t.month)
        else 0
    )

    days = rows(s, month)
    delivered = [d for d in days if d["status"] == "delivered"]
    skipped = [d for d in days if d["status"] == "skipped"]
    ml = sum(d["quantity"] for d in delivered)
    amount = round(sum(d["amount"] for d in delivered), 2)
    pays = sorted(
        [p for p in s.get("payments", []) if p.get("month") == month],
        key=lambda p: (str(p.get("date", "")), str(p.get("id"))),
        reverse=True,
    )
    paid = round(sum(float(p["amount"]) for p in pays), 2)
    marked = len(delivered) + len(skipped)

    weeks = []
    for w in range((total_days + 6) // 7):
        wk = [d for d in days if w * 7 < int(d["date"][-2:]) <= (w + 1) * 7]
        weeks.append(
            {
                "delivered": sum(d["status"] == "delivered" for d in wk),
                "skipped": sum(d["status"] == "skipped" for d in wk),
                "amount": round(sum(d["amount"] for d in wk), 2),
            }
        )

    billed = round(sum(d["amount"] for d in rows(s)), 2)
    paid_all = round(sum(float(p["amount"]) for p in s.get("payments", [])), 2)

    exp = expense_totals([expense_view(e) for e in s.get("expenses", []) if e.get("month") == month])
    exp_all = expense_totals([expense_view(e) for e in s.get("expenses", [])])

    return {
        "month": month,
        "total_days": total_days,
        "elapsed": elapsed,
        "delivered": len(delivered),
        "skipped": len(skipped),
        "pending": max(0, elapsed - marked),
        "ml": ml,
        "litres": round(ml / 1000, 2),
        "avg_ml": round(ml / len(delivered)) if delivered else 0,
        "amount": amount,
        "paid": paid,
        "balance": round(amount - paid, 2),
        "completion": min(100, round(marked / elapsed * 100)) if elapsed else 0,
        "rate": price_on(s, t.isoformat()),
        "weeks": weeks,
        "days": days,
        "payments": pays,
        "expenses": exp,
        "total_spend": round(amount + exp["spent"], 2),
        "total_paid": round(paid + exp["paid"], 2),
        "total_due": round(max(0.0, amount - paid) + exp["due"], 2),
        "overall": {
            "billed": billed,
            "paid": paid_all,
            "due": round(billed - paid_all, 2),
            "exp_spent": exp_all["spent"],
            "exp_paid": exp_all["paid"],
            "exp_due": exp_all["due"],
            "grand_due": round(max(0.0, billed - paid_all) + exp_all["due"], 2),
        },
    }


# ---------------- Auth Endpoints ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not email or not password:
            flash("Please enter both email and password.", "error")
            return render_template("login.html", email=email)

        try:
            user = DailyBillState.authenticate(email, password)
        except Exception as err:
            app.logger.exception("Login failure: %s", err)
            flash(db_error_text(err), "error")
            return render_template("login.html", email=email)

        if not user:
            flash("Invalid email address or password.", "error")
            return render_template("login.html", email=email)

        session.clear()
        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session.permanent = bool(request.form.get("remember"))
        flash(f"Welcome back, {user['name']}!", "success")
        return redirect(safe_next(request.args.get("next")) or url_for("dashboard"))

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm")
        ctx = {"name": name, "email": email}

        def fail(msg):
            flash(msg, "error")
            return render_template("register.html", **ctx)

        if len(name) < 2:
            return fail("Please enter your full name.")
        if not _EMAIL_RE.fullmatch(email):
            return fail("Please enter a valid email address.")
        if len(password) < 6:
            return fail("Password must be at least 6 characters.")
        if confirm is not None and confirm != password:
            return fail("Passwords do not match.")

        try:
            user = DailyBillState.register_user(name, email, password)
        except ValueError as e:
            return fail(str(e))
        except Exception as e:
            app.logger.exception("Registration failure: %s", e)
            return fail(db_error_text(e))

        session.clear()
        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session.permanent = True
        flash(f"Welcome to {Config.APP_NAME}, {user['name']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("register.html")


@app.route("/auth/google")
def google_auth():
    """Google sign-in entry point.

    No OAuth credentials are configured yet, so this only explains that
    (the button on the login / register pages shows the same notice without
    a page load). Wire the real OAuth flow here once GOOGLE_CLIENT_ID and
    GOOGLE_CLIENT_SECRET are available.
    """
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    flash("Google sign-in is coming soon. Please use your email and password.", "info")
    return redirect(url_for("login"))


@app.route("/forgot", methods=["GET", "POST"])
def forgot():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    sent = False
    if request.method == "POST":
        sent = True  # same answer whether or not the account exists
    return render_template("forgot.html", sent=sent, email=request.form.get("email", "").strip())


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for("start"))


# ---------------- Web Pages ----------------
@app.route("/start")
def start():
    """Splash screen — Fresh Milk, Simpler Tracking."""
    if session.get("user_id") and request.args.get("force") != "1":
        return redirect(url_for("dashboard"))
    return render_template("welcome.html")


@app.route("/")
@login_required
def dashboard():
    return render_template("home.html", active="home")


@app.route("/calendar")
@login_required
def calendar_page():
    return render_template("calendar.html")


def _unique_ci(values):
    seen, out = set(), []
    for v in values:
        v = str(v or "").strip()
        if v and v.lower() not in seen:
            seen.add(v.lower())
            out.append(v)
    return out


def _ledger_vocab():
    s = DailyBillState.get_user_state(get_current_user_id())
    items = s.get("expenses", [])
    categories = _unique_ci(list(s.get("expense_categories", [])) + [e.get("category") for e in items])
    vendors = _unique_ci(list(s.get("vendors", [])) + [e.get("vendor") for e in items])
    return (
        categories or list(Config.DEFAULT_EXPENSE_CATEGORIES),
        sorted(vendors, key=str.lower),
    )


@app.route("/khata")
@login_required
def khata():
    return render_template("khata.html", active="khata")


@app.route("/khata/add")
@login_required
def entry_add():
    categories, vendors = _ledger_vocab()
    return render_template("entry_add.html", active="khata", categories=categories, vendors=vendors)


@app.route("/expenses")
@login_required
def expenses():
    """Legacy URL — the KhataBook page now lives at /khata."""
    return redirect(url_for("khata"))


@app.route("/reports")
@login_required
def reports():
    return render_template("reports.html", active="reports")


@app.route("/bill")
@login_required
def bill_page():
    return render_template("bill.html")


@app.route("/payment")
@login_required
def payment_page():
    return render_template("payment.html")


@app.route("/profile")
@login_required
def profile_page():
    return render_template("profile.html", active="profile")


@app.route("/notifications")
@login_required
def notifications_page():
    return render_template("notifications.html", active="notifications")


@app.route("/shopping")
@login_required
def shopping_page():
    return render_template("shopping.html", active="shopping")


@app.route("/interest")
@login_required
def interest_page():
    return render_template("interest.html", active="interest")


@app.route("/interest/add")
@login_required
def interest_add():
    return render_template("interest_add.html", active="interest")


@app.route("/settings")
@login_required
def settings_page():
    # Settings now live on the Profile page
    return redirect(url_for("profile_page"))


# ---------------- Read APIs ----------------
@app.get("/api/state")
@login_required
def get_state():
    uid = get_current_user_id()
    return jsonify(DailyBillState.get_user_state(uid))


@app.get("/api/summary/<month>")
@login_required
def api_summary(month):
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    return jsonify(summary(s, parse_month(month)))


@app.get("/api/history")
@login_required
def api_history():
    uid = get_current_user_id()
    month = request.args.get("month", "")
    if month:
        parse_month(month)
    s = DailyBillState.get_user_state(uid)
    r = rows(s, month)
    d = [x for x in r if x["status"] == "delivered"]
    return jsonify(
        rows=r,
        delivered=len(d),
        litres=round(sum(x["quantity"] for x in d) / 1000, 2),
        amount=round(sum(x["amount"] for x in d), 2),
    )


@app.get("/api/export.csv")
@login_required
def export_csv():
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    buf = io.StringIO()
    w = csv.writer(buf, quoting=csv.QUOTE_ALL)
    w.writerow(["Date", "Status", "Quantity (ml)", "Litres", "Rate (INR/L)", "Amount (INR)", "Notes"])
    for d in reversed(rows(s)):
        w.writerow([d["date"], d["status"], d["quantity"], d["quantity"] / 1000, d["rate"], d["amount"], d["note"]])
    w.writerow([])
    w.writerow(["Payments"])
    w.writerow(["ID", "Date", "For month", "Method", "Amount (INR)", "Note"])
    for p in sorted(s.get("payments", []), key=lambda p: str(p.get("date", ""))):
        w.writerow([p.get("id"), p.get("date"), p.get("month"), p.get("method", ""), p["amount"], p.get("note", "")])
    return Response(
        "\ufeff" + buf.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={Config.FILE_PREFIX}-history.csv"},
    )


# ---------------- KhataBook APIs ----------------
@app.get("/api/expenses")
@login_required
def list_expenses():
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    month = request.args.get("month", "").strip()
    if month:
        parse_month(month)
    category = request.args.get("category", "").strip().lower()
    etype = request.args.get("type", "").strip().lower()
    status = request.args.get("status", "").strip().lower()
    vendor = request.args.get("vendor", "").strip().lower()
    q = request.args.get("q", "").strip().lower()

    items = [expense_view(e) for e in s.get("expenses", [])]
    if month:
        items = [x for x in items if x["month"] == month]
    if category:
        items = [x for x in items if x["category"].lower() == category]
    if etype in Config.EXPENSE_TYPES:
        items = [x for x in items if x["type"] == etype]
    if status in ("paid", "partial", "unpaid", "received"):
        items = [x for x in items if x["status"] == status]
    if vendor:
        items = [x for x in items if x["vendor"].lower() == vendor]
    if q:
        items = [
            x
            for x in items
            if q in " ".join([x["vendor"], x["description"], x["category"], x["note"], x.get("bill_number", "")]).lower()
        ]
    items.sort(key=lambda x: (str(x["date"]), str(x["id"])), reverse=True)
    agg = expense_totals(items)
    return jsonify(items=items, **agg)


@app.post("/api/expense")
@login_required
def create_expense():
    uid = get_current_user_id()
    b = body()
    day = parse_day(b.get("date") or date.today().isoformat())
    etype = b.get("type") if b.get("type") in Config.EXPENSE_TYPES else "debit"

    # Category handling: Support "Other" + custom category
    category = str(b.get("category", "")).strip()[:40] or "Other"
    custom_category = str(b.get("custom_category", "")).strip()[:40]
    if category.lower() in ("other", "") and custom_category:
        category = custom_category

    # Vendor handling: Support "Other" + custom vendor
    vendor = str(b.get("vendor", "")).strip()[:40]
    custom_vendor = str(b.get("custom_vendor", "")).strip()[:40]
    if vendor.lower() in ("other", "") and custom_vendor:
        vendor = custom_vendor

    # Payment method handling: Support "Other" + custom method
    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method

    desc = str(b.get("description", "")).strip()[:140]
    bill_number = str(b.get("bill_number", "")).strip()[:40]
    note = str(b.get("note", "")).strip()[:120]

    quantity, unit_price, tax, discount, due_date, invoice = _entry_details(b)
    base = money(b.get("amount"))
    amount = _grand_total(base, tax, discount)

    paid_now = 0.0
    if etype in ("debit", "purchase") and b.get("paid") not in (None, "", 0, "0"):
        paid_now = money(b.get("paid"))
        if paid_now > amount + 0.009:
            raise ValueError("Paid amount cannot exceed total amount.")

    attachments = sanitize_attachments(b.get("attachments"))
    pay = []
    if paid_now > 0:
        pay.append(
            {
                "id": uuid.uuid4().hex[:10],
                "date": day.isoformat(),
                "amount": paid_now,
                "method": method,
                "note": "Paid at creation",
            }
        )

    exp = {
        "id": uuid.uuid4().hex[:10],
        "date": day.isoformat(),
        "month": day.isoformat()[:7],
        "type": etype,
        "category": category,
        "vendor": vendor,
        "bill_number": bill_number,
        "description": desc,
        "quantity": quantity,
        "unit_price": unit_price,
        "tax": tax,
        "discount": discount,
        "subtotal": base,
        "due_date": due_date,
        "invoice": invoice,
        "amount": amount,
        "method": method,
        "payments": pay,
        "attachments": attachments,
        "note": note,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    def go(s):
        s.setdefault("expenses", []).append(exp)
        # Learn newly typed categories and vendors permanently
        cats = s.setdefault("expense_categories", [])
        if category and not any(c.lower() == category.lower() for c in cats):
            cats.append(category)
        vendors = s.setdefault("vendors", [])
        if vendor and not any(v.lower() == vendor.lower() for v in vendors):
            vendors.append(vendor)

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.put("/api/expense/<eid>")
@login_required
def update_expense(eid):
    uid = get_current_user_id()
    b = body()
    day = parse_day(b.get("date"))
    etype = b.get("type") if b.get("type") in Config.EXPENSE_TYPES else "debit"

    category = str(b.get("category", "")).strip()[:40] or "Other"
    custom_category = str(b.get("custom_category", "")).strip()[:40]
    if category.lower() in ("other", "") and custom_category:
        category = custom_category

    vendor = str(b.get("vendor", "")).strip()[:40]
    custom_vendor = str(b.get("custom_vendor", "")).strip()[:40]
    if vendor.lower() in ("other", "") and custom_vendor:
        vendor = custom_vendor

    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method

    desc = str(b.get("description", "")).strip()[:140]
    bill_number = str(b.get("bill_number", "")).strip()[:40]
    note = str(b.get("note", "")).strip()[:120]

    quantity, unit_price, tax, discount, due_date, invoice = _entry_details(b)
    base = money(b.get("amount"))
    amount = _grand_total(base, tax, discount)
    cleanup = {"files": []}

    def go(s):
        for e in s.get("expenses", []):
            if str(e.get("id")) == str(eid):
                paid_total = 0.0
                for p in e.get("payments", []):
                    try:
                        paid_total += float(p.get("amount") or 0)
                    except (TypeError, ValueError):
                        pass
                if etype in ("debit", "purchase") and paid_total > amount + 0.009:
                    raise ValueError("Recorded payments exceed new amount. Remove a payment first.")

                old_atts = e.get("attachments", []) if isinstance(e.get("attachments"), list) else []
                old_inv = e.get("invoice") if isinstance(e.get("invoice"), dict) else None

                e["date"] = day.isoformat()
                e["month"] = day.isoformat()[:7]
                e["type"] = etype
                e["category"] = category
                e["vendor"] = vendor
                e["bill_number"] = bill_number
                e["description"] = desc
                e["quantity"] = quantity
                e["unit_price"] = unit_price
                e["tax"] = tax
                e["discount"] = discount
                e["subtotal"] = base
                e["due_date"] = due_date
                e["amount"] = amount
                e["method"] = method
                e["note"] = note
                if "attachments" in b:
                    e["attachments"] = sanitize_attachments(b.get("attachments"))
                    cleanup["files"].extend(
                        [(a.get("public_id"), a.get("resource_type")) for a in old_atts if isinstance(a, dict)]
                    )
                if "invoice" in b:
                    e["invoice"] = invoice
                    if old_inv:
                        cleanup["files"].append((old_inv.get("public_id"), old_inv.get("resource_type")))

                cats = s.setdefault("expense_categories", [])
                if category and not any(c.lower() == category.lower() for c in cats):
                    cats.append(category)
                vendors = s.setdefault("vendors", [])
                if vendor and not any(v.lower() == vendor.lower() for v in vendors):
                    vendors.append(vendor)
                return
        raise ValueError("Expense not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)

    # Files that were detached during the edit are removed from storage, but
    # only if they are no longer referenced anywhere in the saved state.
    def _still_used(pid):
        for x in state.get("expenses", []):
            for a in x.get("attachments", []) or []:
                if isinstance(a, dict) and str(a.get("public_id")) == str(pid):
                    return True
            inv = x.get("invoice")
            if isinstance(inv, dict) and str(inv.get("public_id")) == str(pid):
                return True
        return False

    for pid, rt in cleanup["files"]:
        if pid and not _still_used(pid):
            _destroy_attachment(pid, rt)
    return jsonify(state=state, **extra)


@app.delete("/api/expense/<eid>")
@login_required
def delete_expense(eid):
    uid = get_current_user_id()
    holder = {}

    def go(s):
        keep, found = [], False
        for e in s.get("expenses", []):
            if str(e.get("id")) == str(eid):
                found = True
                holder["attachments"] = e.get("attachments", [])
                if isinstance(e.get("invoice"), dict):
                    holder["invoice"] = e["invoice"]
            else:
                keep.append(e)
        if not found:
            raise ValueError("Expense not found.")
        s["expenses"] = keep

    state, extra = DailyBillState.mutate_user_state(uid, go)
    for a in holder.get("attachments", []):
        _destroy_attachment(a.get("public_id"), a.get("resource_type"))
    if holder.get("invoice"):
        _destroy_attachment(holder["invoice"].get("public_id"), holder["invoice"].get("resource_type"))
    return jsonify(state=state, **extra)


@app.post("/api/expense/<eid>/payment")
@login_required
def add_expense_payment(eid):
    uid = get_current_user_id()
    b = body()
    amount = money(b.get("amount"))
    p_date = parse_day(b.get("date") or date.today().isoformat()).isoformat()

    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method

    note = str(b.get("note", "")).strip()[:80]

    def go(s):
        for e in s.get("expenses", []):
            if str(e.get("id")) == str(eid):
                if e.get("type") == "credit":
                    raise ValueError("Credit entries are already received.")
                paid = 0.0
                for p in e.get("payments", []):
                    try:
                        paid += float(p.get("amount") or 0)
                    except (TypeError, ValueError):
                        pass
                due = round(float(e["amount"]) - paid, 2)
                if amount > due + 0.009:
                    raise ValueError(f"Payment exceeds the due balance ({Config.CURRENCY}{due:.2f}).")
                e.setdefault("payments", []).append(
                    {"id": uuid.uuid4().hex[:10], "date": p_date, "amount": amount, "method": method, "note": note}
                )
                return
        raise ValueError("Expense entry not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.put("/api/expense/<eid>/payment/<pid>")
@login_required
def update_expense_payment(eid, pid):
    """Edit a payment recorded against a ledger entry (full CRUD on payments)."""
    uid = get_current_user_id()
    b = body()
    amount = money(b.get("amount"))
    p_date = parse_day(b.get("date")).isoformat()

    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method
    note = str(b.get("note", "")).strip()[:80]

    def go(s):
        for e in s.get("expenses", []):
            if str(e.get("id")) != str(eid):
                continue
            others = 0.0
            for p in e.get("payments", []):
                if str(p.get("id")) == str(pid):
                    continue
                try:
                    others += float(p.get("amount") or 0)
                except (TypeError, ValueError):
                    pass
            if amount + others > float(e.get("amount") or 0) + 0.009:
                raise ValueError("Payments cannot exceed the entry amount.")
            for p in e.get("payments", []):
                if str(p.get("id")) == str(pid):
                    p["amount"] = amount
                    p["date"] = p_date
                    p["method"] = method
                    p["note"] = note
                    return
            raise ValueError("Payment not found.")
        raise ValueError("Expense not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/expense/<eid>/payment/<pid>")
@login_required
def delete_expense_payment(eid, pid):
    uid = get_current_user_id()

    def go(s):
        for e in s.get("expenses", []):
            if str(e.get("id")) == str(eid):
                before = len(e.get("payments", []))
                e["payments"] = [p for p in e.get("payments", []) if str(p.get("id")) != str(pid)]
                if len(e["payments"]) == before:
                    raise ValueError("Payment not found.")
                return
        raise ValueError("Expense not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


# ---------------- Categories & Vendors ----------------
@app.get("/api/expense-categories")
@login_required
def get_expense_categories():
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    return jsonify(categories=s.get("expense_categories", []))


@app.post("/api/expense-categories")
@login_required
def add_expense_category():
    uid = get_current_user_id()
    name = str(body().get("name", "")).strip()[:35]
    if len(name) < 2:
        raise ValueError("Category name must be at least 2 characters.")

    def go(s):
        cats = s.setdefault("expense_categories", [])
        if any(c.lower() == name.lower() for c in cats):
            raise ValueError("This category already exists.")
        if len(cats) >= 50:
            raise ValueError("Up to 50 categories supported.")
        cats.append(name)

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, categories=state.get("expense_categories", []), **extra)


def _delete_category(uid, name):
    name = str(name or "").strip()
    if name.lower() in [c.lower() for c in Config.PROTECTED_CATEGORIES]:
        raise ValueError(f'"{name}" is a built-in category and cannot be removed.')

    def go(s):
        cats = s.get("expense_categories", [])
        left = [c for c in cats if c.lower() != name.lower()]
        if len(left) == len(cats):
            raise ValueError("Category not found.")
        s["expense_categories"] = left

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/expense-categories/<path:name>")
@login_required
def delete_expense_category(name):
    return _delete_category(get_current_user_id(), name)


@app.post("/api/expense-categories/delete")
@login_required
def delete_expense_category_body():
    return _delete_category(get_current_user_id(), body().get("name"))


@app.post("/api/expense-categories/rename")
@login_required
def rename_expense_category():
    uid = get_current_user_id()
    b = body()
    old = str(b.get("old", "")).strip()
    new = str(b.get("new", "")).strip()[:35]
    if len(new) < 2:
        raise ValueError("Category name must be at least 2 characters.")
    if old.lower() in [c.lower() for c in Config.PROTECTED_CATEGORIES]:
        raise ValueError(f'"{old}" is a built-in category and cannot be renamed.')

    def go(s):
        cats = s.setdefault("expense_categories", [])
        idx = next((i for i, c in enumerate(cats) if c.lower() == old.lower()), None)
        if idx is None:
            raise ValueError("Category not found.")
        if new.lower() != old.lower() and any(c.lower() == new.lower() for c in cats):
            raise ValueError("A category with that name already exists.")
        cats[idx] = new
        for e in s.get("expenses", []):
            if str(e.get("category", "")).lower() == old.lower():
                e["category"] = new

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.get("/api/vendors")
@login_required
def list_vendors():
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    vset = set(s.get("vendors", []))
    for e in s.get("expenses", []):
        v = str(e.get("vendor", "")).strip()
        if v:
            vset.add(v)
    return jsonify(vendors=sorted(vset, key=str.lower))


@app.post("/api/vendors")
@login_required
def add_vendor():
    uid = get_current_user_id()
    name = str(body().get("name", "")).strip()[:40]
    if len(name) < 2:
        raise ValueError("Vendor name must be at least 2 characters.")

    def go(s):
        vendors = s.setdefault("vendors", [])
        known = [str(v).lower() for v in vendors] + [str(e.get("vendor", "")).lower() for e in s.get("expenses", [])]
        if name.lower() in known:
            raise ValueError("This vendor already exists.")
        if len(vendors) >= 200:
            raise ValueError("Up to 200 vendors supported.")
        vendors.append(name)

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.post("/api/vendors/delete")
@login_required
def delete_vendor():
    uid = get_current_user_id()
    name = str(body().get("name", "")).strip()

    def go(s):
        if any(str(e.get("vendor", "")).lower() == name.lower() for e in s.get("expenses", [])):
            raise ValueError("This vendor has ledger entries and cannot be removed.")
        vendors = s.get("vendors", [])
        left = [v for v in vendors if str(v).lower() != name.lower()]
        if len(left) == len(vendors):
            raise ValueError("Vendor not found.")
        s["vendors"] = left

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.post("/api/vendors/rename")
@login_required
def rename_vendor():
    """Rename a vendor everywhere (saved list + all ledger entries)."""
    uid = get_current_user_id()
    b = body()
    old = str(b.get("old", "")).strip()
    new = str(b.get("new", "")).strip()[:40]
    if len(new) < 2:
        raise ValueError("Vendor name must be at least 2 characters.")
    if old.lower() == new.lower():
        return jsonify(state=DailyBillState.get_user_state(uid))

    def go(s):
        vendors = s.get("vendors", [])
        in_list = any(str(v).lower() == old.lower() for v in vendors)
        used = any(str(e.get("vendor", "")).lower() == old.lower() for e in s.get("expenses", []))
        if not in_list and not used:
            raise ValueError("Vendor not found.")
        if any(str(v).lower() == new.lower() for v in vendors):
            raise ValueError("A vendor with that name already exists.")
        s["vendors"] = [new if str(v).lower() == old.lower() else v for v in vendors]
        for e in s.get("expenses", []):
            if str(e.get("vendor", "")).lower() == old.lower():
                e["vendor"] = new

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.post("/api/vendors/settle")
@login_required
def settle_vendor():
    """Pay a vendor's pending udhar; the amount is applied to the oldest dues first."""
    uid = get_current_user_id()
    b = body()
    name = str(b.get("vendor", "")).strip()
    if not name:
        raise ValueError("Choose a vendor.")
    amount = money(b.get("amount"))
    if amount <= 0:
        raise ValueError("Enter an amount greater than zero.")
    p_date = parse_day(b.get("date") or date.today().isoformat()).isoformat()
    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method
    note = str(b.get("note", "")).strip()[:80] or "Vendor settlement"

    def go(s):
        due_entries = []
        for e in s.get("expenses", []):
            if str(e.get("vendor", "")).lower() != name.lower() or e.get("type") == "credit":
                continue
            view = expense_view(e)
            if view["due"] > 0.009:
                due_entries.append((str(e.get("date", "")), e, view["due"]))
        total_due = round(sum(x[2] for x in due_entries), 2)
        if not due_entries:
            raise ValueError("This vendor has no pending dues.")
        if amount > total_due + 0.009:
            raise ValueError(f"Amount exceeds the pending dues ({Config.CURRENCY}{total_due:.2f}).")
        left = amount
        applied = 0
        for _, e, due in sorted(due_entries, key=lambda x: x[0]):
            if left <= 0.009:
                break
            part = round(min(left, due), 2)
            e.setdefault("payments", []).append(
                {"id": uuid.uuid4().hex[:10], "date": p_date, "amount": part, "method": method, "note": note}
            )
            left = round(left - part, 2)
            applied += 1
        return {"applied_to": applied}

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


# ---------------- Uploads ----------------
@app.post("/api/upload")
@login_required
def upload_file():
    f = request.files.get("file")
    if not f or not f.filename:
        raise ValueError("Choose a bill photo or PDF to upload.")
    filename = f.filename or "file"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in Config.ALLOWED_UPLOAD_EXTENSIONS:
        raise ValueError("Only JPG, PNG, WEBP, GIF or PDF files are allowed.")
    blob = f.read()
    if not blob:
        raise ValueError("The selected file is empty.")
    if len(blob) > Config.MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError(f"File exceeds max size {Config.MAX_UPLOAD_MB} MB.")

    uid = get_current_user_id()

    # Cloudinary first — but never a dead end: any problem (not configured,
    # bad credentials, DNS/network failure) falls back to local storage so
    # the user's bill photo upload always succeeds.
    cloud_error = "" if cloudinary_ready() else "Cloudinary is not configured"
    if cloudinary_ready():
        public_id = f"{Config.CLOUDINARY_FOLDER}/{uid}/{uuid.uuid4().hex[:20]}"
        try:
            res = cloudinary.uploader.upload(
                io.BytesIO(blob), public_id=public_id, resource_type="auto", filename=filename
            )
            return jsonify(
                storage="cloud",
                attachment={
                    "url": res.get("secure_url"),
                    "public_id": res.get("public_id"),
                    "resource_type": res.get("resource_type", "image"),
                    "format": (res.get("format") or ext or "").lower(),
                    "name": filename[:60],
                    "bytes": int(res.get("bytes") or len(blob)),
                },
            )
        except Exception as err:
            app.logger.exception("Cloudinary upload failed (%s) — storing in the database instead", err)
            cloud_error = f"{type(err).__name__}: {str(err)[:200]}"

    # Database storage: works on Vercel and every other host.
    try:
        fid = db_store_file(uid, blob, filename, _MIME.get(ext, "application/octet-stream"))
        return jsonify(
            storage="database",
            cloud_error=cloud_error,
            attachment={
                "url": f"/api/uploads/db/{fid}",
                "public_id": f"db:{fid}",
                "resource_type": "raw" if ext == "pdf" else "image",
                "format": ext,
                "name": filename[:60],
                "bytes": len(blob),
            },
        )
    except Exception as err:
        app.logger.exception("Database file storage failed (%s)", err)

    # Last resort for local development only.
    try:
        return jsonify(storage="local", attachment=_local_store(uid, blob, ext, filename))
    except OSError as err:
        app.logger.exception("Local file storage failed (%s)", err)
        return jsonify(error="Could not store the file. Please try again in a moment."), 503


@app.get("/api/storage-check")
@login_required
def storage_check():
    """Open this URL while signed in to see why files are (or are not) reaching Cloudinary."""
    cfg = cloudinary.config()
    info = {
        "configured": cloudinary_ready(),
        "cloud_name": getattr(cfg, "cloud_name", None),
        "api_key_ends_with": (str(getattr(cfg, "api_key", "") or "")[-4:] or None),
        "folder": Config.CLOUDINARY_FOLDER,
    }
    if not info["configured"]:
        return jsonify(ok=False, reason="No Cloudinary credentials found in the environment.", **info)
    try:
        cloudinary.api.ping()
        return jsonify(ok=True, reason="Cloudinary accepted the credentials.", **info)
    except Exception as err:
        return jsonify(ok=False, reason=f"{type(err).__name__}: {str(err)[:300]}", **info)


@app.get("/api/uploads/db/<fid>")
@login_required
def serve_db_upload(fid):
    """Serve a database-stored attachment — only to its owner."""
    if not _SAFE_FID.fullmatch(fid):
        return jsonify(error="Not found."), 404
    found = db_read_file(get_current_user_id(), fid)
    if not found:
        return jsonify(error="Not found."), 404
    blob, mime, name = found
    resp = Response(blob, mimetype=mime)
    resp.headers["Content-Disposition"] = 'inline; filename="%s"' % re.sub(r"[^A-Za-z0-9_.-]", "_", name or "file")
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Cache-Control"] = "private, max-age=86400"
    return resp


@app.get("/api/uploads/local/<uid>/<fname>")
@login_required
def serve_local_upload(uid, fname):
    """Serve a locally stored bill attachment — only to its owner."""
    if uid != get_current_user_id() or ".." in uid or ".." in fname:
        return jsonify(error="Not found."), 404
    if not _SAFE_UID.fullmatch(uid) or not _SAFE_NAME.fullmatch(fname):
        return jsonify(error="Not found."), 404
    ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
    if ext not in Config.ALLOWED_UPLOAD_EXTENSIONS:
        return jsonify(error="Not found."), 404
    folder = os.path.join(os.path.abspath(LOCAL_UPLOAD_DIR), uid)
    if not os.path.isdir(folder):
        return jsonify(error="Not found."), 404
    return send_from_directory(folder, fname, download_name=fname)


@app.delete("/api/upload")
@login_required
def delete_file():
    b = body()
    pid = str(b.get("public_id", "")).strip()
    if not pid:
        raise ValueError("Missing attachment identifier.")
    _destroy_attachment(pid, b.get("resource_type"))
    return jsonify(ok=True)


@app.get("/api/expenses/export.csv")
@login_required
def export_expenses_csv():
    uid = get_current_user_id()
    s = DailyBillState.get_user_state(uid)
    month = request.args.get("month", "").strip()
    if month:
        parse_month(month)
    category = request.args.get("category", "").strip().lower()
    etype = request.args.get("type", "").strip().lower()

    items = [expense_view(e) for e in s.get("expenses", [])]
    if month:
        items = [x for x in items if x["month"] == month]
    if category:
        items = [x for x in items if x["category"].lower() == category]
    if etype in Config.EXPENSE_TYPES:
        items = [x for x in items if x["type"] == etype]
    items.sort(key=lambda x: (str(x["date"]), str(x["id"])))

    buf = io.StringIO()
    w = csv.writer(buf, quoting=csv.QUOTE_ALL)
    w.writerow(["Date", "Type", "Category", "Vendor", "Bill No", "Description", "Qty", "Unit Price (INR)", "Tax (INR)", "Discount (INR)", "Amount (INR)", "Paid (INR)", "Due (INR)", "Due Date", "Status", "Method", "Note"])
    for x in items:
        w.writerow([
            x["date"], x["type"], x["category"], x["vendor"], x["bill_number"], x["description"],
            x.get("quantity", ""), x.get("unit_price") or "", x.get("tax") or "", x.get("discount") or "",
            x["amount"], x["paid"], x["due"], x.get("due_date", ""), x["status"], x["method"], x["note"],
        ])
    return Response(
        "\ufeff" + buf.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={Config.FILE_PREFIX}-ledger.csv"},
    )


# ---------------- Milk Daily & Price Records ----------------
@app.put("/api/profile")
@login_required
def put_profile():
    uid = get_current_user_id()
    b = body()

    def go(s):
        s["name"] = str(b.get("name", "")).strip()[:30] or session.get("user_name", "User")
        s["phone"] = str(b.get("phone", "")).strip()[:20]
        s["vendor"] = str(b.get("vendor", "")).strip()[:40]
        s["address"] = str(b.get("address", "")).strip()[:120]
        s["quantity"] = qty_ml(b.get("quantity", s.get("quantity", 500)))
        # Profile photo: the client sends a small square JPEG data URL
        # (auto-resized to 256px, ~10-30 KB) or a remote image URL.
        # An empty value removes the photo (avatar falls back to initials).
        # NOTE: the key must be PRESENT in the request to touch the photo —
        # a normal name/phone/address edit from any device keeps the saved
        # picture instead of silently wiping it.
        if "photo" in b:
            p = str(b.get("photo") or "").strip()
            if p.startswith("data:image/") and len(p) <= 300_000:
                s["photo"] = p
            elif p.startswith(("http://", "https://")):
                s["photo"] = p[:600]
            else:
                s["photo"] = ""

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.put("/api/record")
@login_required
def put_record():
    uid = get_current_user_id()
    b = body()
    day = parse_day(b.get("date"))
    if day > date.today():
        raise ValueError("Future dates cannot be recorded.")
    status = b.get("status")
    if status not in ("delivered", "skipped"):
        raise ValueError("Status must be delivered or skipped.")
    qty = qty_ml(b.get("quantity")) if status == "delivered" else 0
    note = str(b.get("note", "")).strip()[:120]

    def go(s):
        s["records"][day.isoformat()] = {
            "status": status,
            "quantity": qty,
            "note": note,
        }
        # Remember the last-used quantity as the default so it stays
        # selected everywhere (bulk fill, settings) until changed again.
        if status == "delivered":
            s["quantity"] = qty

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/record/<day>")
@login_required
def delete_record(day):
    uid = get_current_user_id()
    key = parse_day(day).isoformat()
    state, extra = DailyBillState.mutate_user_state(uid, lambda s: s["records"].pop(key, None))
    return jsonify(state=state, **extra)


@app.post("/api/records/fill")
@login_required
def fill_month():
    uid = get_current_user_id()
    b = body()
    month, qty = parse_month(b.get("month")), qty_ml(b.get("quantity"))

    def go(s):
        y, m = map(int, month.split("-"))
        n = 0
        for d in range(1, calendar.monthrange(y, m)[1] + 1):
            day = date(y, m, d)
            if day > date.today():
                break
            if day.isoformat() not in s["records"]:
                s["records"][day.isoformat()] = {
                    "status": "delivered",
                    "quantity": qty,
                    "note": "",
                }
                n += 1
        return {"count": n}

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.post("/api/payment")
@login_required
def add_payment():
    uid = get_current_user_id()
    b = body()
    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method

    pay = {
        "id": uuid.uuid4().hex[:10],
        "month": parse_month(b.get("month")),
        "date": parse_day(b.get("date") or date.today().isoformat()).isoformat(),
        "amount": money(b.get("amount")),
        "method": method,
        "note": str(b.get("note", "")).strip()[:80],
    }
    state, extra = DailyBillState.mutate_user_state(uid, lambda s: s["payments"].append(pay))
    return jsonify(state=state, **extra)


@app.put("/api/payment/<pid>")
@login_required
def update_payment(pid):
    uid = get_current_user_id()
    b = body()
    method = b.get("method") if b.get("method") in Config.ALLOWED_PAYMENT_METHODS else "Other"
    custom_method = str(b.get("custom_method", "")).strip()[:30]
    if method.lower() == "other" and custom_method:
        method = custom_method

    amt = money(b.get("amount"))
    p_date = parse_day(b.get("date")).isoformat()
    p_month = parse_month(b.get("month"))
    note = str(b.get("note", "")).strip()[:80]

    def go(s):
        for p in s.get("payments", []):
            if str(p.get("id")) == str(pid):
                p["amount"] = amt
                p["date"] = p_date
                p["month"] = p_month
                p["method"] = method
                p["note"] = note
                break
        else:
            raise ValueError("Payment not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/payment/<pid>")
@login_required
def delete_payment(pid):
    uid = get_current_user_id()

    def go(s):
        n = len(s.get("payments", []))
        s["payments"] = [p for p in s.get("payments", []) if str(p.get("id")) != str(pid)]
        if len(s["payments"]) == n:
            raise ValueError("Payment not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.put("/api/price")
@login_required
def put_price():
    uid = get_current_user_id()
    b = body()
    price = money(b.get("price"), "price per litre")
    frm = parse_day(b.get("from") or date.today().isoformat()).isoformat()

    def go(s):
        for p in s.get("prices", []):
            if str(p["from"]) == frm:
                p["price"] = price
                break
        else:
            s.setdefault("prices", []).append({"from": frm, "price": price})
        s["prices"].sort(key=lambda p: str(p["from"]))

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/price/<frm>")
@login_required
def delete_price(frm):
    uid = get_current_user_id()

    def go(s):
        left = [p for p in s.get("prices", []) if str(p["from"]) != str(frm)]
        if not left:
            raise ValueError("Keep at least one price.")
        s["prices"] = left

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


# ---------------- Shopping list ----------------
SHOP_MAX_ITEMS = 300


def _shop_price(v):
    try:
        n = round(float(v), 2)
    except (TypeError, ValueError):
        return 0.0
    if n < 0 or n > 10_000_000:
        raise ValueError("Enter a valid price.")
    return n


@app.post("/api/shopping")
@login_required
def add_shopping_item():
    uid = get_current_user_id()
    b = body()
    name = str(b.get("name", "")).strip()[:60]
    if not name:
        raise ValueError("Enter the item name.")
    qty = str(b.get("qty", "")).strip()[:20]
    price = _shop_price(b.get("price") or 0)

    def go(s):
        items = s.setdefault("shopping", [])
        if len(items) >= SHOP_MAX_ITEMS:
            raise ValueError("Your list is full. Clear the bought items first.")
        for it in items:
            if not it.get("done") and str(it.get("name", "")).lower() == name.lower():
                raise ValueError("This item is already on your list.")
        items.append({
            "id": uuid.uuid4().hex[:10],
            "name": name,
            "qty": qty,
            "price": price,
            "done": False,
            "added": date.today().isoformat(),
        })

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.put("/api/shopping/<iid>")
@login_required
def update_shopping_item(iid):
    uid = get_current_user_id()
    b = body()

    def go(s):
        for it in s.setdefault("shopping", []):
            if it.get("id") != iid:
                continue
            if "name" in b:
                nm = str(b.get("name", "")).strip()[:60]
                if not nm:
                    raise ValueError("Enter the item name.")
                it["name"] = nm
            if "qty" in b:
                it["qty"] = str(b.get("qty", "")).strip()[:20]
            if "price" in b:
                it["price"] = _shop_price(b.get("price") or 0)
            if "done" in b:
                it["done"] = bool(b.get("done"))
                it["done_on"] = date.today().isoformat() if it["done"] else ""
            return
        raise ValueError("Item not found.")

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.delete("/api/shopping/<iid>")
@login_required
def delete_shopping_item(iid):
    uid = get_current_user_id()

    def go(s):
        s["shopping"] = [it for it in s.get("shopping", []) if it.get("id") != iid]

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


@app.post("/api/shopping/clear-done")
@login_required
def clear_done_shopping():
    uid = get_current_user_id()

    def go(s):
        s["shopping"] = [it for it in s.get("shopping", []) if not it.get("done")]

    state, extra = DailyBillState.mutate_user_state(uid, go)
    return jsonify(state=state, **extra)


# ---------------- Interest ledger (money given / taken with interest) ----------------
INTEREST_MAX_RECORDS = 500
_TIME_RE = re.compile(r"([01]\d|2[0-3]):[0-5]\d")
_INTEREST_MIN_DATE = date(1990, 1, 1)


def _client_today():
    """The user's own 'today'. Servers often run on UTC, which is a day behind
    India for the first hours of the morning, so trust the browser's date when
    it is within a day of the server's."""
    raw = request.args.get("today") or body().get("today")
    try:
        d = date.fromisoformat(str(raw))
        if abs((d - date.today()).days) <= 1:
            return d
    except (TypeError, ValueError):
        pass
    return date.today()


def _positive(v, what, top):
    try:
        n = round(float(v), 2)
    except (TypeError, ValueError):
        raise ValueError(f"Enter a valid {what}.")
    if not 0 < n <= top:
        raise ValueError(f"Enter a valid {what}.")
    return n


def _interest_core(b, today):
    """Validate the fields the calculation depends on."""
    principal = _positive(b.get("principal"), "principal amount", Config.INTEREST_MAX_PRINCIPAL)
    try:
        rate = round(float(b.get("rate") if b.get("rate") not in (None, "") else 0), 4)
    except (TypeError, ValueError):
        raise ValueError("Enter a valid interest rate.")
    if not 0 <= rate <= Config.INTEREST_MAX_RATE:
        raise ValueError(f"Interest rate must be between 0 and {Config.INTEREST_MAX_RATE}%.")
    period = str(b.get("rate_period") or "month").lower()
    if period not in ("month", "year"):
        raise ValueError("Choose whether the rate is per month or per year.")
    kind = str(b.get("interest_type") or "simple").lower()
    if kind not in ("simple", "compound"):
        raise ValueError("Choose simple or compound interest.")
    start = parse_day(b.get("date") or today.isoformat())
    if start < _INTEREST_MIN_DATE:
        raise ValueError("That date is too far in the past.")
    if start > today:
        raise ValueError("The date can't be in the future.")
    return principal, rate, period, kind, start


def _single_file(raw):
    """One optional file (a signature): sanitized dict or None."""
    if isinstance(raw, list):
        raw = raw[0] if raw else None
    if isinstance(raw, dict) and raw.get("public_id"):
        out = sanitize_attachments([raw], limit=1)
        return out[0] if out else None
    return None


def _interest_fields(b, today):
    principal, rate, period, kind, start = _interest_core(b, today)
    name = str(b.get("name", "")).strip()[:60]
    party = str(b.get("party", "")).strip()[:60]
    if not name:
        raise ValueError("Give this record a name so you can find it later.")
    if not party:
        raise ValueError("Enter the name of the person who gave / took the money.")
    direction = str(b.get("direction", "")).lower()
    if direction not in ("given", "taken"):
        raise ValueError("Choose whether you gave or took the money.")
    time_s = str(b.get("time", "") or "").strip()
    if time_s and not _TIME_RE.fullmatch(time_s):
        raise ValueError("Enter a valid time.")
    return {
        "name": name,
        "direction": direction,
        "party": party,
        "phone": str(b.get("phone", "")).strip()[:20],
        "principal": principal,
        "rate": rate,
        "rate_period": period,
        "interest_type": kind,
        "date": start.isoformat(),
        "time": time_s,  # display only, never used in the calculation
        "description": str(b.get("description", "")).strip()[:300],
        "attachments": sanitize_attachments(b.get("attachments"), limit=Config.MAX_INTEREST_ATTACHMENTS),
        "sig_giver": _single_file(b.get("sig_giver")),
        "sig_taker": _single_file(b.get("sig_taker")),
    }


def _find_loan(s, lid):
    for it in s.get("interest", []):
        if str(it.get("id")) == str(lid):
            return it
    raise ValueError("Record not found.")


def _loan_files(loan):
    files = list(loan.get("attachments") or [])
    for k in ("sig_giver", "sig_taker"):
        if isinstance(loan.get(k), dict):
            files.append(loan[k])
    return files


def _sorted_views(items, today):
    views = [loan_view(it, today) for it in items]
    views.sort(key=lambda v: (v.get("date", ""), v.get("created", "")), reverse=True)
    return views


@app.get("/api/interest")
@login_required
def list_interest():
    uid = get_current_user_id()
    today = _client_today()
    s = DailyBillState.get_user_state(uid)
    views = _sorted_views(s.get("interest", []), today)
    return jsonify(loans=views, totals=interest_totals(views))


@app.post("/api/interest/calc")
@login_required
def interest_calc():
    """Live 'what will it cost' preview for the add form (nothing is saved)."""
    today = _client_today()
    try:
        principal, rate, period, kind, start = _interest_core(body(), today)
    except ValueError:
        return jsonify(valid=False)
    return jsonify(valid=True, calc=interest_preview(principal, rate, period, kind, start, today))


@app.post("/api/interest")
@login_required
def create_interest():
    uid = get_current_user_id()
    today = _client_today()
    fields = _interest_fields(body(), today)
    holder = {}

    def go(s):
        items = s.setdefault("interest", [])
        if len(items) >= INTEREST_MAX_RECORDS:
            raise ValueError("You have reached the limit of saved interest records.")
        rec = dict(fields)
        rec.update({
            "id": uuid.uuid4().hex[:10],
            "payments": [],
            "created": datetime.now(timezone.utc).isoformat(),
        })
        items.append(rec)
        holder["rec"] = rec

    DailyBillState.mutate_user_state(uid, go)
    return jsonify(ok=True, loan=loan_view(holder["rec"], today))


@app.put("/api/interest/<lid>")
@login_required
def update_interest(lid):
    uid = get_current_user_id()
    today = _client_today()
    fields = _interest_fields(body(), today)
    holder = {}

    def go(s):
        rec = _find_loan(s, lid)
        first_pay = min((p.get("date", "") for p in rec.get("payments", [])), default="")
        if first_pay and fields["date"] > first_pay:
            raise ValueError("The date can't be after a payment already recorded on it (%s)." % first_pay)
        holder["old"] = _loan_files(rec)
        rec.update(fields)
        holder["rec"] = rec
        holder["new"] = _loan_files(rec)

    DailyBillState.mutate_user_state(uid, go)
    _destroy_removed(holder["old"], holder["new"])
    return jsonify(ok=True, loan=loan_view(holder["rec"], today))


@app.delete("/api/interest/<lid>")
@login_required
def delete_interest(lid):
    uid = get_current_user_id()
    holder = {}

    def go(s):
        rec = _find_loan(s, lid)
        holder["files"] = _loan_files(rec)
        s["interest"] = [it for it in s["interest"] if it is not rec]

    DailyBillState.mutate_user_state(uid, go)
    for a in holder.get("files", []):
        _destroy_attachment(a.get("public_id"), a.get("resource_type"))
    return jsonify(ok=True)


@app.post("/api/interest/<lid>/payment")
@login_required
def add_interest_payment(lid):
    uid = get_current_user_id()
    today = _client_today()
    b = body()
    amount = _positive(b.get("amount"), "amount", Config.INTEREST_MAX_PRINCIPAL * 2)
    pay_day = parse_day(b.get("date") or today.isoformat())
    time_s = str(b.get("time", "") or "").strip()
    if time_s and not _TIME_RE.fullmatch(time_s):
        raise ValueError("Enter a valid time.")
    note = str(b.get("note", "")).strip()[:80]
    holder = {}

    def go(s):
        rec = _find_loan(s, lid)
        start = date.fromisoformat(rec["date"])
        if pay_day > today:
            raise ValueError("The payment date can't be in the future.")
        if pay_day < start:
            raise ValueError("The payment can't be earlier than the loan date.")
        earlier = [p for p in rec.get("payments", []) if p.get("date", "") <= pay_day.isoformat()]
        due = loan_view(dict(rec, payments=earlier), pay_day)["calc"]["total_due"]
        if due <= 0.009:
            raise ValueError("Nothing is due on this record - it is already settled.")
        if amount > due + 0.01:
            raise ValueError(f"That is more than the amount due on that date ({Config.CURRENCY}{due:,.2f}).")
        rec.setdefault("payments", []).append({
            "id": uuid.uuid4().hex[:8],
            "amount": amount,
            "date": pay_day.isoformat(),
            "time": time_s,
            "note": note,
        })
        holder["rec"] = rec

    DailyBillState.mutate_user_state(uid, go)
    return jsonify(ok=True, loan=loan_view(holder["rec"], today))


@app.delete("/api/interest/<lid>/payment/<pid>")
@login_required
def delete_interest_payment(lid, pid):
    uid = get_current_user_id()
    today = _client_today()
    holder = {}

    def go(s):
        rec = _find_loan(s, lid)
        before = len(rec.get("payments", []))
        rec["payments"] = [p for p in rec.get("payments", []) if str(p.get("id")) != str(pid)]
        if len(rec["payments"]) == before:
            raise ValueError("Payment not found.")
        holder["rec"] = rec

    DailyBillState.mutate_user_state(uid, go)
    return jsonify(ok=True, loan=loan_view(holder["rec"], today))


@app.post("/api/reset")
@login_required
def reset():
    uid = get_current_user_id()
    u = DailyBillState.get_user(uid)
    uname = u.get("name", "User") if u else "User"
    uemail = u.get("email", "") if u else ""
    state, extra = DailyBillState.mutate_user_state(
        uid, lambda s: s.clear() or s.update(DailyBillState.default_user_state(name=uname, email=uemail))
    )
    return jsonify(state=state, **extra)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
