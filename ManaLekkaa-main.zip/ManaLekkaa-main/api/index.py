"""Vercel serverless entry point for ManaLekka.

Exposes the Flask app defined at the project root (app.py) to Vercel's Python runtime.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import app  # noqa: E402

app.debug = False
application = app

if __name__ == "__main__":
    app.run()
