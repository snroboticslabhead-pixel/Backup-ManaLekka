"""Run `python check_db.py` to verify connection and DoH resolution."""
import time
import psycopg
from config import Config
from models import _connect

print("Connecting to Neon host:", Config.DATABASE_URL.split("@")[-1])
start = time.perf_counter()

try:
    with _connect() as conn:
        elapsed = (time.perf_counter() - start) * 1000
        row = conn.execute("SELECT version()").fetchone()
        version_str = row.get("version") if isinstance(row, dict) else row[0]
        print(f"Connected OK in {elapsed:.1f}ms.")
        print("Server:", str(version_str)[:60])
        print("psycopg:", psycopg.__version__, "| libpq:", psycopg.pq.version())
except Exception as e:
    print("FAILED:", type(e).__name__, "-", e)
    print("psycopg:", psycopg.__version__, "| libpq:", psycopg.pq.version())