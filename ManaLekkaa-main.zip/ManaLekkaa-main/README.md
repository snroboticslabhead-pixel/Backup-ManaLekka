# ManaLekka

Flask + Neon PostgreSQL + Cloudinary, deployable on Vercel.

Mobile-first KhataBook UI: fresh green milk theme with a bottom navigation
(Home · Khata · Reports · Profile) and separate pages for every screen:

| Route | Page |
|---|---|
| `/start` | Splash screen — "Fresh Milk, Simpler Tracking" |
| `/login`, `/register` | Login / Register (tabbed, with Google button + password strength meter) |
| `/forgot` | Forgot password |
| `/auth/google` | Google sign-in entry point (shows a "coming soon" notice until OAuth credentials are added) |
| `/` | Home — greeting, stats, mark today's delivery, this month's bill |
| `/calendar` | Delivery Calendar — month grid + mark any day + milk bill card |
| `/khata` | KhataBook — All / Expenses / Purchases / Credit / Milk chips |
| `/khata/add` | Add New Entry (expense / purchase / credit) |
| `/reports` | Reports — monthly totals, weekly litres chart, delivery summary |
| `/bill` | Monthly Milk Bill — totals, bill details, payments |
| `/profile` | Profile — account rows, milk price, quick stats |
| `/settings` | Settings — notifications, language, ledger data, logout |
| `/interest` | Interest ledger — money given / taken, totals, filters, tap a record for full details |
| `/interest/add` | Add / edit an interest record (`?edit=<id>`) |

## Run locally
    pip install -r requirements.txt
    cp .env.example .env      # fill in DATABASE_URL, SECRET_KEY, CLOUDINARY_URL
    python app.py             # http://127.0.0.1:5000

## Change something in ONE place
| What | Where |
|---|---|
| App name, ledger name, currency | `config.py` (`APP_NAME`, `LEDGER_NAME`, `CURRENCY`) |
| Categories, payment methods, entry types, default vendors | `config.py` |
| Colours, components (light theme only) | `static/css/app.css` |
| Page behaviour (all pages) | `static/js/app.js` (`MM.pages.*`) |
| Page layout / structure | `templates/*.html` |

Templates and browser code read these through `brand` / `window.APP`, so nothing else needs editing.

Put your logo at `static/images/logo.png` (shown as-is in the sidebar) and your illustrations in `static/images/` (`image1.png`, `image2.png`,
`image3.png`, `image3-1.png`, `splash image.png`).

## Speed notes
- `models.py` keeps a **connection pool** to Neon (no new TLS handshake per request) and reads only the signed-in
  user's slice of the JSON row, memoised once per request. Set `DB_POOL_MAX` to change the pool size (default 5).
- `app.py` adds gzip + browser caching for static files (`?v=N` on css/js = cache a year; bump N when you edit them).
- Hero images are resized WebP (`image1.webp`, `image2.webp`, `image3-1.webp`, `splash.webp`). The original PNGs are
  kept only as source files; edit those and re-export if you change the artwork.

## Interest ledger
Record money you **gave** or **took**, with a name, the other person, principal, rate, date (auto-filled to today)
and an optional time. Optional extras: description, documents / slips (photos or PDF) and a digital signature for
the giver and the taker (drawn on screen, saved as an image).

How it is calculated (`interest.py` — the only place the maths lives):
- By **date only**. The time is shown on the record but never used.
- Rate per **month**: 1 month = 30 days. Rate per **year**: 1 year = 365 days.
- **Simple**: interest only on the principal still owed. **Compound**: unpaid interest is added to the balance
  every monthly anniversary of the start date.
- Each payment pays the **interest first**, then the principal. A payment can't be more than what is due.

Limits (`config.py`): `MAX_INTEREST_ATTACHMENTS`, `INTEREST_MAX_PRINCIPAL`, `INTEREST_MAX_RATE`.

## Deploy on Vercel
`vercel.json` routes every URL to the Flask app in `api/index.py`, keeping the original path so Flask's own routes (/login, /register, /api/...) match. Without it Vercel shows `404 NOT_FOUND`.
In the Vercel project settings, set **Root Directory** to the folder that contains `vercel.json` and `app.py`,
and add `SECRET_KEY`, `DATABASE_URL` and `CLOUDINARY_URL` under Environment Variables.
Vercel's disk is read-only, so bill photos must go to Cloudinary (the local-disk fallback only works when running locally).
